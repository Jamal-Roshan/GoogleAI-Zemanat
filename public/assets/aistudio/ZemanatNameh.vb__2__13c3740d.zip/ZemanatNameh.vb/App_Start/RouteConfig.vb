﻿Imports System.Web.Routing
Imports Microsoft.AspNet.FriendlyUrls
Public NotInheritable Class RouteConfig
    Public Shared Sub RegisterRoutes(routes As RouteCollection)
        Dim settings = New FriendlyUrlSettings()
        settings.AutoRedirectMode = RedirectMode.Off
        routes.EnableFriendlyUrls(settings)

        routes.MapPageRoute("signin", "signin", "~/login.aspx")
        routes.MapPageRoute("signout", "signout", "~/logout.aspx")

        routes.MapPageRoute("home", "home", "~/Users/Default.aspx")
        routes.MapPageRoute("zemanatnameh", "zemanatnameh", "~/Users/sodurZemanatnameh.aspx")
        routes.MapPageRoute("govahie", "govahie", "~/Users/sodurGovahie.aspx")
        routes.MapPageRoute("viewItems", "viewItems", "~/Users/Viewgovahies.aspx")
        routes.MapPageRoute("Print", "print", "~/Users/PrintGovahie.aspx")
        routes.MapPageRoute("ChangeUserPassword", "changeuserpassword", "~/Users/ChangeUsersPassword.aspx")
        routes.MapPageRoute("printlist", "printlist", "~/Users/PrintActiveList.aspx")


        routes.MapPageRoute("modir", "modir", "~/Modiran/Default.aspx")
        routes.MapPageRoute("block", "block", "~/Modiran/blockuser.aspx")
        routes.MapPageRoute("resetuserpass", "resetuserpass", "~/Modiran/ResetUserPassword.aspx")
        routes.MapPageRoute("list", "list", "~/Modiran/UsersList.aspx")
        routes.MapPageRoute("govahi", "govahi", "~/Modiran/Govahies.aspx")
        routes.MapPageRoute("Estelam", "Estelam", "~/Modiran/SodurEstelam.aspx")
        routes.MapPageRoute("ViewEstelam", "ViewEstelam", "~/Modiran/viewEstelamha.aspx")
        routes.MapPageRoute("estelamreport", "estelamreport", "~/Modiran/Gozaresh_Estelam.aspx")
        routes.MapPageRoute("upload", "upload", "~/Modiran/UploadpersonnelInformation.aspx")
        routes.MapPageRoute("changemodirpassword", "changemodirpassword", "~/Modiran/ChangeModiranPassword.aspx")
        routes.MapPageRoute("new", "new", "~/Modiran/newgovahie.aspx")
        routes.MapPageRoute("modirprint", "modirprint", "~/Modiran/modiranprint.aspx")
        routes.MapPageRoute("modirprintactivelist", "modirprintactivelist", "~/Modiran/ModiranPrintActiveList.aspx")
        routes.MapPageRoute("eslah", "eslah", "~/Modiran/NameCorrection.aspx")


        routes.MapPageRoute("admin", "admin", "~/Administrator/Default.aspx")
        routes.MapPageRoute("setting", "setting", "~/Administrator/Settings.aspx")
        routes.MapPageRoute("addadmin", "addadmin", "~/Administrator/AddAdministrator.aspx")
        routes.MapPageRoute("deladmin", "deladmin", "~/Administrator/deleteadmin.aspx")
        routes.MapPageRoute("resetadminpass", "resetadminpass", "~/Administrator/resetadminpassword.aspx")
        routes.MapPageRoute("verror", "verror", "~/Administrator/ViewError.aspx")
        routes.MapPageRoute("changeadminpassword", "changeadminpassword", "~/Administrator/ChangeAdministratorsPassword.aspx")
        routes.MapPageRoute("init", "init", "~/Administrator/initial.aspx")


        routes.MapPageRoute(routeUrl:="updating", routeName:="updating", physicalFile:="~/Update.aspx")
        routes.MapPageRoute(routeName:="error404", routeUrl:="PageNotFound", physicalFile:="~/error404.aspx")


    End Sub


End Class
