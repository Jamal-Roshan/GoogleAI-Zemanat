﻿<%@ Page Title="تنظیم پارامتر های سیستم" Language="vb" AutoEventWireup="false" MasterPageFile="~/Administrator/AdministratorMasterPage.Master" CodeBehind="Settings.aspx.vb"
    Inherits="ZemanatNameh.vb.Settings" ClientIDMode="Static" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style type="text/css">
        .form-control {
            position: relative;
            font-size: 16px;
            height: auto;
            padding: 10px;
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
            margin-bottom: 4px;
            border-bottom-left-radius: 0;
            border-bottom-right-radius: 0;
            /*width:60%;*/
        }

            .form-control:focus {
                z-index: 2;
            }

        .title-label {
            font-size: 16px;
            padding: 10px;
            margin-bottom: 4px;
        }

        .right {
            text-align: right;
            direction: rtl;
        }

        .left {
            text-align: left;
            direction: ltr;
        }
    </style>


    <script type="text/javascript">
        function Comma(Num) {
            Num += '';
            Num = Num.replace(',', ''); Num = Num.replace(',', ''); Num = Num.replace(',', '');
            Num = Num.replace(',', ''); Num = Num.replace(',', ''); Num = Num.replace(',', '');
            x = Num.split('.');
            x1 = x[0];
            x2 = x.length > 1 ? '.' + x[1] : '';
            var rgx = /(\d+)(\d{3})/;
            while (rgx.test(x1))
                x1 = x1.replace(rgx, '$1' + ',' + '$2');
            return x1 + x2;
        }
        function isNumber(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class=" container">
        <div class="row" id="Dashbord" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">
            <div class="pnl panel-info">
                <div class="panel-heading text-center">
                    تنظیم پارامتر های سیستم
                </div>
                <asp:Panel runat="server" ID="pnlmsg" Visible="false" BackColor="LightYellow" ForeColor="Red" CssClass="text-center">
                    <asp:Label Text="" ID="lblmsg" runat="server" />
                </asp:Panel>
                <div class="panel-body">

                    <asp:PlaceHolder runat="server" ID="placeholdersetting" />

                </div>
                <div class="panel-footer text-center">
                    <asp:Button Text="ثبت تغییرات" runat="server" ID="btnsabt" CssClass=" btn btn-default" />
                </div>

            </div>
        </div>
    </div>
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">
</asp:Content>
