﻿Imports System.Data
Imports System.Data.SqlClient
Imports Telerik.Web.UI


Public Class ViewError
    Inherits System.Web.UI.Page
    Public utill As New Utility()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        SqlDataSource_for_grid.ConnectionString = utill.Connectionstring
        Try
            RadGridError.DataBind()
        Catch ex As Exception
            utill.RegisterError(ex.Message, Me.Page.Title, System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try

    End Sub

    Protected Sub btn_Truncate_Table_Click(sender As Object, e As EventArgs) Handles btn_Truncate_Table.Click
        Dim strsqlcommand As String = "Truncate TABLE [Error_Table]"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strsqlcommand, connection)
                    command.CommandType = CommandType.Text
                    connection.Open()
                    command.ExecuteNonQuery()
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, Me.Page.Title, System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        SqlDataSource_for_grid.ConnectionString = utill.Connectionstring
        Try
            RadGridError.DataBind()
        Catch ex As Exception
            utill.RegisterError(ex.Message, Me.Page.Title, System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
    End Sub

    Protected Sub RadGridError_ItemDataBound(sender As Object, e As Telerik.Web.UI.GridItemEventArgs) Handles RadGridError.ItemDataBound
        If (TypeOf e.Item Is GridDataItem AndAlso e.Item.OwnerTableView.DataSourceID = "SqlDataSource_for_grid") Then
            ' AndAlso e.Item.OwnerTableView.DataSource = "Sqldr"
            Dim lbl As Label = CType(e.Item.FindControl("Grid_RowNumber_Label"), Label)
            lbl.Text = utill.En2Fa(((e.Item.OwnerTableView.CurrentPageIndex * e.Item.OwnerTableView.PageSize) + (e.Item.ItemIndex + 1)).ToString())
        End If
    End Sub
End Class