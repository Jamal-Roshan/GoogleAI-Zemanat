﻿<%@ Page Title="مشاهده لیست خطاها" Language="vb" AutoEventWireup="false" MasterPageFile="~/Administrator/AdministratorMasterPage.Master" CodeBehind="ViewError.aspx.vb" Inherits="ZemanatNameh.vb.ViewError"
    EnableEventValidation="false"  %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style type="text/css">
        .cellstyle{
            direction:ltr;
            text-align:justify !important;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class=" container">
        <div class="row" id="Dashbord" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">
            <div class="pnl panel-info">
                <div class="panel-heading text-center">
                    مشاهده لیست خطاها
                </div>
                <asp:Panel runat="server" ID="pnlmsg" Visible="false" BackColor="LightYellow" ForeColor="Red" CssClass="text-center">
                    <asp:Label Text="" ID="lblmsg" runat="server" />
                </asp:Panel>
                <div class="panel-body">
                    <telerik:RadGrid ID="RadGridError" runat="server" AllowPaging="True" CssClass="table-responsive" AllowSorting="True" AutoGenerateColumns="False"
                        BorderStyle="Solid"
                        PageSize="100" Skin="Outlook" Font-Names="yekan" DataSourceID="SqlDataSource_for_grid" ShowGroupPanel="True">
                        <GroupingSettings CollapseAllTooltip="Collapse all groups"></GroupingSettings>

                        <ClientSettings EnableRowHoverStyle="true" EnableAlternatingItems="true" AllowDragToGroup="True">
                        </ClientSettings>
                        <GroupPanel Text="برای گروه بندی عنوان ستون را به اینجا بکشید">
                        </GroupPanel>
                        <MasterTableView CssClass="table-responsive" DataSourceID="SqlDataSource_for_grid">
                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                <HeaderStyle Font-Bold="true" Width="20px" />
                            </RowIndicatorColumn>
                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                <HeaderStyle Font-Bold="true" Width="20px" />
                            </ExpandCollapseColumn>
                            <EditFormSettings>
                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                </EditColumn>
                            </EditFormSettings>
                            <Columns>
                                 <telerik:GridTemplateColumn AllowFiltering="false" Groupable="False" HeaderText="ردیف" ReadOnly="True" UniqueName="radif">
                                    <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Width="10px" Font-Names="yekan" VerticalAlign="Middle" />
                                    <ItemTemplate>
                                        <center>
                                            <asp:Label ID="Grid_RowNumber_Label" runat="server"  Width="10px" />
                                        </center>
                                    </ItemTemplate>
                                    <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true"
                                        Width="30px" />
                                    <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="Center" Width="10px" Font-Names="yekan" VerticalAlign="Middle" />
                                </telerik:GridTemplateColumn>

                                <telerik:GridBoundColumn DataField="Pagename" FilterControlAltText="Filter pagename column" ReadOnly="True" UniqueName="pagename" HeaderText="نام صفحه">
                                    <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" />
                                    <ItemStyle Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                                </telerik:GridBoundColumn>
                                 <telerik:GridBoundColumn DataField="MethodName" FilterControlAltText="Filter column column" HeaderText="نام متد" ReadOnly="True" UniqueName="column">
                                     <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" />
                                     <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Left" VerticalAlign="Middle" />
                                 </telerik:GridBoundColumn>
                                 <telerik:GridTemplateColumn DataField="DateofError" Groupable="false" FilterControlAltText="Filter TemplateColumn column" HeaderText="تارخ بروز خطا" ReadOnly="True" UniqueName="TemplateColumn">
                                     <ItemTemplate>
                                        <center>
                                            <asp:Label  runat="server"  text='<%# Utill.DateToString(Eval("dateoferror")) %>' />
                                        </center>
                                    </ItemTemplate>
                                     <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" />
                                     <ItemStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" />
                                 </telerik:GridTemplateColumn>
                                 <telerik:GridBoundColumn DataField="ErrorMessage" FilterControlAltText="Filter column1 column" HeaderText="پیغام خطا" ReadOnly="True" UniqueName="column1">
                                     <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" />
                                     <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Left" VerticalAlign="Middle" />
                                 </telerik:GridBoundColumn>
                            </Columns>
                        </MasterTableView>
                        <PagerStyle FirstPageToolTip="اولین صفحه"
                            Font-Strikeout="False" HorizontalAlign="Center" LastPageToolTip="آخرین صفحه"
                            NextPagesToolTip="صفحه بعد" NextPageToolTip="صفحه بعد" PageSizeLabelText="تعداد سطر های هر صفحه:"
                            PrevPagesToolTip="صفحه قبل" PrevPageToolTip="صفحه قبل" />
                        <FilterMenu EnableImageSprites="False">
                        </FilterMenu>
                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                        </HeaderContextMenu>
                    </telerik:RadGrid>
                </div>
                <div class="panel-footer text-center">
                    <asp:Button Text="حذف تمامی خطاها" runat="server" ID="btn_Truncate_Table" CssClass=" btn btn-default" />
                </div>

            </div>
        </div>
    </div>
    <asp:SqlDataSource id="SqlDataSource_for_grid" runat="server" SelectCommandType="Text" SelectCommand="SELECT  [RowID],[ErrorMessage],[PageName],[MethodName],[DateofError]  FROM [Error_Table] Order by [DateofError] desc" />
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">
</asp:Content>
