﻿Imports Telerik.Web.UI
Imports System.Data
Imports System.Data.SqlClient
Public Class AddAdministrator
    Inherits System.Web.UI.Page
    Dim utill As New Utility()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        SqlDataSource_for_grid.ConnectionString = utill.Connectionstring
        Try
            TRadGrid.DataBind()
        Catch ex As Exception
            utill.RegisterError(ex.Message, Me.Page.Title, System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
    End Sub
    Protected Sub TRadGrid_ItemDataBound(sender As Object, e As Telerik.Web.UI.GridItemEventArgs) Handles TRadGrid.ItemDataBound
        If (TypeOf e.Item Is GridDataItem AndAlso e.Item.OwnerTableView.DataSourceID = "SqlDataSource_for_grid") Then
            ' AndAlso e.Item.OwnerTableView.DataSource = "Sqldr"
            Dim lbl As Label = CType(e.Item.FindControl("Grid_RowNumber_Label"), Label)
            lbl.Text = utill.En2Fa(((e.Item.OwnerTableView.CurrentPageIndex * e.Item.OwnerTableView.PageSize) + (e.Item.ItemIndex + 1)).ToString())
        End If

    End Sub

    Protected Sub btnregister_Click(sender As Object, e As EventArgs) Handles btnregister.Click
        If Page.IsValid Then
            Try
                Dim strsqlinsert = "INSERT INTO [Administrators] ([Code],[Firstname],[LastName],[Password],[Role])  VALUES  (@Code,@Firstname,@LastName,@Password,@Role)"
                Using connection As New SqlConnection(utill.Connectionstring)
                    Using command As New SqlCommand(strsqlinsert, connection)
                        command.CommandType = CommandType.Text
                        command.Parameters.Clear()
                        Dim strRole As String = ""
                        For Each item As ListItem In chkrole.Items
                            If item.Selected Then
                                strRole += item.Value + ","
                            End If
                        Next
                        strRole = strRole.Substring(0, strRole.LastIndexOf(","))

                        command.Parameters.AddWithValue("@Code", utill.Fa2En(txtcode.Text.Trim.ToLower))
                        command.Parameters.AddWithValue("@Firstname", txtfirstname.Text.Trim)
                        command.Parameters.AddWithValue("@LastName", txtlastname.Text.Trim)
                        command.Parameters.AddWithValue("@Password", BCrypt.Net.BCrypt.HashPassword(utill.Fa2En(txtcode.Text.Trim.ToLower), 4))
                        command.Parameters.AddWithValue("@Role", utill.Encrypt(strRole, utill.Fa2En(txtcode.Text.Trim.ToLower)))
                        connection.Open()
                        command.ExecuteNonQuery()
                    End Using
                End Using
            Catch ex As Exception
                If ex.Message.Contains("duplicate key") Then
                    lblmsg.Text = "مدیر با این نام کاربری قبلاً ثبت شده است"
                Else
                    lblmsg.Text = "در ثبت اطلاعات خطا رخ داده است"
                    utill.RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                End If
                Return
            End Try
            SqlDataSource_for_grid.ConnectionString = utill.Connectionstring
            Try
                TRadGrid.DataBind()
            Catch ex As Exception
                utill.RegisterError(ex.Message, Me.Page.Title, System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            End Try
            lblmsg.Text = "حساب کاربری مدیر ایجاد شد" + "<br/>" + "رمز کاربر ایجاد شده نام کاربری وارد شده است"
            txtcode.Text = ""
            txtfirstname.Text = ""
            txtlastname.Text = ""
            chkrole.Items.Item(1).Selected = False


        End If
    End Sub
    Public Function getfarsirole(ByVal encrole As String, code As String) As String
        Dim decrole As String = utill.Decrypt(encrole, code)
        Dim Roles() As String = decrole.Split(","c)
        Dim returnvalue As String = [String].Empty
        For Each role As String In Roles
            If role = "Modir" Then
                returnvalue = "مدیر"
            End If
            If role = "Administrator" Then
                returnvalue += "," & "مدیر ارشد"
            End If
        Next
        Return returnvalue
    End Function
End Class