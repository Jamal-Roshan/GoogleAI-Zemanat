﻿<%@ Page Title="صفحه اصلی مدیر ارشد سیستم" Language="vb" AutoEventWireup="false" MasterPageFile="~/Administrator/AdministratorMasterPage.Master" CodeBehind="Default.aspx.vb" Inherits="ZemanatNameh.vb._Default2" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style type="text/css">
        .pics
        {
            width: 30%; 
            margin: 0 auto;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class=" container">
        <div class="row" id="Dashbord" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; padding-top: 8px; background-color: whitesmoke">
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 text-center ">
                <div class="panel">
                    <div class="panel-body">
                        <a href="./setting">
                            <img alt="تنظیم پارامترهای سیستم" class="img-responsive pics" src="./Administrator/Images/Dashboard/Param.png" />
                            <div class="text-center">تنظیم پارامترهای سیستم</div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 text-center ">
                <div class="panel">
                    <div class="panel-body">
                        <a href="./addadmin">
                            <img alt="ثبت کاربر مدیر جدید" class="img-responsive pics " src="./Administrator/Images/Dashboard/Add_User.png" />
                            <div class="text-center">ثبت کاربر مدیر جدید</div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 text-center ">
                <div class="panel">
                    <div class="panel-body">
                        <a href="./deladmin">
                            <img alt="حذف کاربر مدیر" class="img-responsive pics"  src="./Administrator/Images/Dashboard/Delete_User.png" />
                            <div class="text-center">حذف کاربر مدیر</div>
                        </a>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 text-center ">
                <div class="panel">
                    <div class="panel-body">
                        <a href="./resetadminpass">
                            <img alt="ریست رمز مدیران" class="img-responsive pics"  src="./Administrator/Images/Dashboard/Reset_Password.png" />
                            <div class="text-center">ریست رمز مدیران</div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 text-center ">
                <div class="panel">
                    <div class="panel-body">
                        <a href="./verror">
                            <img alt="مشاهده لیست خطاها" class="img-responsive pics"  src="./Administrator/Images/Dashboard/virus.png" />
                            <div class="text-center">مشاهده لیست خطاها</div>
                        </a>
                    </div>
                </div>
            </div>
            
        </div>
        <div class="row" id="Status" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="padding-top: 10px">
                <div class="panel panel-primary">
                    <div class="panel-heading text-center" style="padding: 10px; margin: 0px">
                        <h1 style="font-size: 1.1em; padding: 0px; margin: 0px">وضعیت جاری سایت</h1>
                    </div>
                    <div class="panel-body" style="padding: 10px 20px 10px 20px">
                        <label>وضعیت جاری سایت: </label>
                        <asp:Label Text="" ForeColor="green" runat="server" ID="lblstatus" />
                        <p />
                        <div class="text-center">
                            <asp:Button Text="تغییر وضعیت" runat="server" ID="btnchangestatus" CssClass="btn btn-primary" OnClick="btnchangestatus_Click" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">
</asp:Content>
