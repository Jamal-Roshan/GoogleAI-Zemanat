﻿<%@ Page Title="مقدار دهی اولیه" Language="vb" AutoEventWireup="false" MasterPageFile="~/Administrator/AdministratorMasterPage.Master" CodeBehind="initial.aspx.vb" Inherits="ZemanatNameh.vb.init" %>

<%@ Register Assembly="Stimulsoft.Report.Web" Namespace="Stimulsoft.Report.Web" TagPrefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class=" container">
        <div class="row" id="Dashbord" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; padding-top: 8px; background-color: whitesmoke;">
            <div style="width: 80%; margin: 0 auto">
                <asp:Panel runat="server" ID="pnlmsg" Visible="false" Style="background-color: lightyellow; padding: 5px" class=" text-center" ClientIDMode="Static">
                    <asp:Label Text="" ID="lblmsg" runat="server" ForeColor="red" ClientIDMode="Static" />
                </asp:Panel>
                <br />
                <br />
                <div class="row">
                    <div class="col-lg-6">
                        <asp:Button Text="معتبر سازی گواهی ها برای همه ی کاربران" runat="server" ID="btnvalidationforall" CssClass="btn btn-default" Width="300px" CausesValidation="false"
                            OnClientClick="document.getElementById('pnlmsg').style.display='none'" />
                    </div>
                    <div class="col-lg-6">
                        <asp:Button Text="معتبر سازی تعداد گواهی فعال برای همه ی کاربران" runat="server" ID="btnvalidatenumberofgovahieforall" CssClass="btn btn-default" Width="300px" CausesValidation="false"
                            OnClientClick="document.getElementById('pnlmsg').style.display='none'" />
                    </div>
                    <br />
                    <br />
                    <br />
                    <br />
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-lg-6">
                                <asp:TextBox runat="server" ID="txtconfirm" ValidationGroup="delgovahies" CssClass="form-control"
                                    OnClientClick="document.getElementById('pnlmsg').style.display='none'" />
                                <asp:RequiredFieldValidator Text=" type OK for delete" ControlToValidate="txtconfirm" runat="server" ValidationGroup="delgovahies" ForeColor="red"/>
                            </div>
                            <div class="col-lg-6">
                                <asp:Button Text="حذف گواهی های تسویه شده" runat="server" ID="btndeletetasviyeh" CssClass="btn btn-danger" Width="300px" CausesValidation="true" ValidationGroup="delgovahies"
                                    OnClientClick="document.getElementById('pnlmsg').style.display='none'" />
                            </div>
                        </div>
                    </div>

                </div>
                <br />
                <br />
                <div class="row" style="border: 1px solid black; padding-top: 20px; margin-bottom: 5px">
                    <div class="col-lg-6">
                        <asp:Button Text="معتبر سازی تعداد گواهی فعال برای یک فرد" runat="server" ID="btnvalidatenumberofgovahiebycode" CssClass="btn btn-default" Width="300px" CausesValidation="true" ValidationGroup="g1"
                            OnClientClick="document.getElementById('pnlmsg').style.display='none'" />
                    </div>
                    <div class="col-lg-6">
                        <asp:Button Text="معتبر سازی  گواهی ها برای یک فرد" runat="server" ID="btnvalidategovahiebycode" CssClass="btn btn-default" Width="300px" CausesValidation="true" ValidationGroup="g1"
                            OnClientClick="document.getElementById('pnlmsg').style.display='none'" />
                    </div>
                    <div class="col-lg-4">
                        <br />
                        <label for="txtcode">شماره پرسنلی</label>
                        <asp:TextBox runat="server" Text="" ID="txtcode" CssClass="form-control"
                            OnClientClick="document.getElementById('pnlmsg').style.display='none'" />
                        <asp:RequiredFieldValidator Text="شماره پرسنلی را وارد کنید" ControlToValidate="txtcode" runat="server" ValidationGroup="g1" ForeColor="red" />
                    </div>


                </div>
                <div class="row" style="border: 1px solid black; padding-top: 20px; margin-bottom: 5px; padding-bottom: 10px">
                    <p style="text-align: center; background-color: yellow; color: red; padding: 5px;">حذف کاربران غیر فعال و گواهی های آنها تا یک تاریخ خاص</p>
                    <div class="">

                        <div class="col-lg-4">
                            <label for="txtdate">حذف تا تاریخ (روز-ماه-سال) - YYYY/MM/DD</label>
                        </div>
                        <div class="col-lg-3">
                            <asp:TextBox runat="server" Text="" ID="txtdate" Style="direction: ltr"
                                OnClientClick="document.getElementById('pnlmsg').style.display='none'" />
                            <asp:RequiredFieldValidator Text="تاریخ را وارد کنید" ControlToValidate="txtdate" runat="server" ValidationGroup="deluser" ForeColor="red" />
                        </div>

                        <div class="col-lg-5">
                            <asp:Button Text=" حذف کاربران غیر فعال و گواهی های آنها تا یک تاریخ خاص" runat="server" ID="btndelete" CssClass="btn btn-default" CausesValidation="true" ValidationGroup="deluser"
                                OnClientClick="document.getElementById('pnlmsg').style.display='none'" />
                            
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>
    <asp:Label Text="" ID="ss" runat="server" />

</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">
</asp:Content>
