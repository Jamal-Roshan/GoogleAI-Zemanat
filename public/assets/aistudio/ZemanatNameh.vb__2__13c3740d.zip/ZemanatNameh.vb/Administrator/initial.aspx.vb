﻿Imports System.Data.SqlClient
Public Class init
    Inherits System.Web.UI.Page
    Public utill As New Utility
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnvalidationforall_Click(sender As Object, e As EventArgs) Handles btnvalidationforall.Click
        utill.Set_RowValidationCode_For_All_Rows_In_Govaheis_Table()
        utill.Set_Number_Of_Active_Govahie_For_ALL_Users()
        pnlmsg.Visible = True
        lblmsg.Text = "انجام شد"
    End Sub

    Protected Sub btnvalidatenumberofgovahieforall_Click(sender As Object, e As EventArgs) Handles btnvalidatenumberofgovahieforall.Click
        utill.Set_Number_Of_Active_Govahie_For_ALL_Users()
        pnlmsg.Visible = True
        lblmsg.Text = "انجام شد"
    End Sub

    Protected Sub btnvalidatenumberofgovahiebycode_Click(sender As Object, e As EventArgs) Handles btnvalidatenumberofgovahiebycode.Click
        If Me.Page.IsValid Then
            utill.Set_Number_Of_Active_Govahie_By_Code(utill.Fa2En(txtcode.Text.Trim))
            pnlmsg.Visible = True
            lblmsg.Text = "انجام شد"
        End If
    End Sub

    Protected Sub btnvalidategovahiebycode_Click(sender As Object, e As EventArgs) Handles btnvalidategovahiebycode.Click
        If Me.Page.IsValid Then
            utill.Set_RowValidationCode_For_Govaheis_Table_By_Code(utill.Fa2En(txtcode.Text.Trim))
            pnlmsg.Visible = True
            lblmsg.Text = "انجام شد"
        End If
    End Sub

    Protected Sub btndeletetasviyeh_Click(sender As Object, e As EventArgs) Handles btndeletetasviyeh.Click
        If Me.Page.IsValid Then
            If txtconfirm.Text.Trim.ToUpper = "OK" Then
                Dim strdelete = "DELETE FROM [Govahies]  WHERE StateId <> 1"
                Try
                    Using conn As New SqlConnection(utill.Connectionstring)
                        Using sqlcommand As New SqlCommand(strdelete, conn)
                            sqlcommand.CommandType = CommandType.Text
                            conn.Open()
                            sqlcommand.ExecuteNonQuery()
                        End Using
                    End Using
                Catch ex As Exception
                    Throw
                End Try
            End If
            txtcode.Text = ""
        pnlmsg.Visible = True
            lblmsg.Text = "انجام شد"
        End If
    End Sub

    Public Function Convert_Shamsi_Date_String_To_Miladi_Date_String(ByVal [date] As String) As String

        Dim year As Integer = Integer.Parse([date].Substring(0, 4))

        Dim month As Integer = Integer.Parse([date].Substring(5, 2))

        Dim day As Integer = Integer.Parse([date].Substring(8, 2))

        Dim p As New System.Globalization.PersianCalendar()

        Dim dt As DateTime = p.ToDateTime(year, month, day, 0, 0, 0, 0)
        Dim stryear As String = ""
        Dim strmonth As String = ""
        Dim strday As String = ""

        stryear = dt.Year.ToString

        If dt.Month < 10 Then
            strmonth = "0" & dt.Month.ToString
        Else
            strmonth = dt.Month.ToString
        End If

        If dt.Day < 10 Then
            strday = "0" & dt.Day.ToString
        Else
            strday = dt.Day.ToString
        End If



        Dim miladidate As String = stryear & "-" & strmonth & "-" & strday

        Return miladidate

    End Function

    Protected Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        If Me.Page.IsValid Then

            Dim strmiladidate As String = Convert_Shamsi_Date_String_To_Miladi_Date_String(txtdate.Text.Trim)

            Dim strcode As String = ""
            Dim strsql As String = "Select [code]  FROM [Users_table] where (( Cast('" & strmiladidate & "' as datetime) >= [OperationDate])   AND (ISACTIVE=0))"
            Dim counter As Long = 0
            Try
                Using conn As New SqlConnection(utill.Connectionstring)
                    Using sqlcommand As New SqlCommand(strsql, conn)
                        sqlcommand.CommandType = CommandType.Text
                        conn.Open()
                        Using reader As SqlDataReader = sqlcommand.ExecuteReader()
                            If reader.HasRows Then
                                Do While reader.Read
                                    strcode = strcode + "'" + reader.Item("code").ToString + "',"
                                    counter += 1
                                Loop
                            End If

                        End Using
                    End Using
                End Using
            Catch ex As Exception
                Throw
            End Try

            If strcode.Length > 0 Then
                strcode = strcode.Substring(0, strcode.LastIndexOf(","c))
                strsql = "DELETE FROM [Users_table] WHERE [CODE] IN ( " & strcode & " )"
                Try
                    Using conn As New SqlConnection(utill.Connectionstring)
                        Using sqlcommand As New SqlCommand(strsql, conn)
                            sqlcommand.CommandType = CommandType.Text
                            conn.Open()
                            sqlcommand.ExecuteNonQuery()
                        End Using
                    End Using
                Catch ex As Exception
                    Throw
                End Try


                strsql = "DELETE FROM [Govahies] WHERE [CODE] IN ( " & strcode & " )"
                Try
                    Using conn As New SqlConnection(utill.Connectionstring)
                        Using sqlcommand As New SqlCommand(strsql, conn)
                            sqlcommand.CommandType = CommandType.Text
                            conn.Open()
                            sqlcommand.ExecuteNonQuery()
                        End Using
                    End Using
                Catch ex As Exception
                    Throw
                End Try

            End If
            pnlmsg.Visible = True
            lblmsg.Text = "انجام شد" & "<br/><br/>" & "تعداد پرسنل حذف شده: " & counter.ToString
            txtdate.Text = ""
        End If
    End Sub
End Class