﻿<%@ Page Title="حذف کاربر مدیر" Language="vb" AutoEventWireup="false" MasterPageFile="~/Administrator/AdministratorMasterPage.Master" CodeBehind="deleteadmin.aspx.vb" Inherits="ZemanatNameh.vb.deleteadmin" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style type="text/css">
        .panel {
            margin-bottom: 10px;
            border-color: rgba(128, 120, 128, 0.53);
        }

        .panel-body {
            background-color: rgba(222, 217, 217, 0.5);
        }

        .RightAndLeftPadding {
            padding-right: 5px;
            padding-left: 5px;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class=" container">
        <div class="row" id="main" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">
            <div style="margin: 0 auto; width: 50%">
                <div class="panel  panel-danger  ">
                    <div class="panel-heading text-center" style="padding: 10px; margin: 0px">
                        <h1 style="font-size: 1.2em; padding: 0px; margin: 0px">حذف حساب کاربری</h1>
                    </div>
                    <div class="panel-body" style="padding: 10px 20px 10px 20px">
                        <div style="width: 90%; margin: 0 auto; text-align: right; padding: 0px 10px 0px 10px; margin-bottom: 5px; margin-top: 5px; line-height: 25px">
                            <asp:Label runat="server" Text="" ForeColor="Red" ID="lblmsg" />

                            <asp:ValidationSummary runat="server" ForeColor="red" BackColor="LightYellow" />
                        </div>
                        <div class="form-group">
                            <label for="txtusername">نام کاربری</label>
                            <asp:RequiredFieldValidator SetFocusOnError="true" ErrorMessage="نام کاربری را وارد کنید" Text="*" ControlToValidate="txtusername" runat="server" ForeColor="Red" Display="Static" />
                            <asp:TextBox runat="server" ID="txtusername" CssClass="form-control" placeholder="نام کاربری" />
                        </div>
                        <div class="form-group text-center">
                            <asp:Button Text="حذف حساب کاربری" runat="server" CssClass="btn btn-default" ID="btnenter" OnClientClick="return confirmDelete();" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">
    <script type="text/javascript">
        function confirmDelete() {
            var ret_confirm = confirm("آیا برای حذف این حساب کاربری اطمینان دارید");
            if (ret_confirm == true) {
                checkclick = "true";
                return true;
            }
            else {
                return false;
            }
        }
    </script>
</asp:Content>
