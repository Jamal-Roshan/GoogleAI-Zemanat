﻿Public Class deleteadmin
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnenter_Click(sender As Object, e As EventArgs) Handles btnenter.Click
        If Page.IsValid Then
            Dim utill As New Utility
            lblmsg.Text = ""
            If utill.Fa2En(txtusername.Text.Trim.ToLower) = utill.Fa2En(HttpContext.Current.User.Identity.Name.Trim.ToLower) Then
                lblmsg.Text = "در حال حاضر شما با این نام کاربری وارد سایت شده اید و نمی توانید آن را حذف کنید"
                Exit Sub
            End If
            Dim Adminmem As New AdminMembership()
            Dim result As Integer = Adminmem.DeleteAdmin(utill.Fa2En(txtusername.Text.Trim))
            Select Case result
                Case -2
                    lblmsg.Text = "در حذف حساب کاربری خطا به وجود آمده است"
                Case -1
                    lblmsg.Text = "در یافتن حساب کاربری خطا به وجود آمده است"
                Case 0
                    lblmsg.Text = "حساب کاربری با این نام کاربری وجود ندارد"
                Case 1
                    lblmsg.Text = "حساب کاربری با موفقیت حذف شد"
            End Select
        End If
    End Sub
End Class