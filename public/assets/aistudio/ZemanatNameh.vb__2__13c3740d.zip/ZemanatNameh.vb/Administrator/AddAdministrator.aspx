﻿<%@ Page Title="ثبت کاربر مدیر جدید" Language="vb" AutoEventWireup="false" MasterPageFile="~/Administrator/AdministratorMasterPage.Master" CodeBehind="AddAdministrator.aspx.vb" Inherits="ZemanatNameh.vb.AddAdministrator" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style type="text/css">
        .panel {
            margin-bottom: 10px;
            border-color: rgba(128, 120, 128, 0.53);
        }

        .panel-body {
            background-color: rgba(222, 217, 217, 0.5);
        }

        .RightAndLeftPadding {
            padding-right: 5px;
            padding-left: 5px;
        }

        td {
            padding: 5px;
        }

        th {
            padding: 5px;
            text-align: center !important;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class=" container">
        <div class="row" id="main" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">
            <div style="margin: 0 auto; width: 40%">
                <div class="panel  panel-info panel-group  " style="">
                    <div class="panel-heading text-center" style="padding: 10px; margin: 0px">
                        <h1 style="font-size: 1.2em; padding: 0px; margin: 0px">ایجاد کاربر مدیر سایت</h1>
                    </div>
                    <div class="panel-body" style="padding: 10px 20px 10px 20px;">
                        <div style=" margin: 0 auto; text-align: right; padding: 0px 10px 0px 10px; margin-bottom: 5px; margin-top: 5px; line-height: 25px">
                            <asp:Label runat="server" Text="" ForeColor="Red" ID="lblmsg" CssClass="text-center" />
                            <asp:ValidationSummary runat="server" ForeColor="red" BackColor="LightYellow" />
                        </div>
                        <div class="form-group" style="">
                            <label for="txtcode">نام کاربری</label>
                            <asp:RequiredFieldValidator SetFocusOnError="true" ErrorMessage="نام کاربری را وارد کنید" Text="*" ControlToValidate="txtcode" runat="server" ForeColor="Red" Display="Static" />
                            <asp:TextBox runat="server" ID="txtcode" CssClass="form-control" placeholder="نام کاربری"
                                onfocus="document.getElementById('MainContent_lblmsg').style.display='none'" />
                        </div>

                        <div class="form-group" style="">
                            <label for="txtfirstname">نام </label>
                            <asp:RequiredFieldValidator SetFocusOnError="true" ErrorMessage="نام  را وارد کنید" Text="*" ControlToValidate="txtfirstname" runat="server" ForeColor="Red" Display="Static" />
                            <asp:TextBox runat="server" ID="txtfirstname" CssClass="form-control" placeholder="نام"
                                onfocus="document.getElementById('MainContent_lblmsg').style.display='none'" />
                        </div>
                        <div class="form-group" style="">
                            <label for="txtlastname">نام خانوادگی</label>
                            <asp:RequiredFieldValidator SetFocusOnError="true" ErrorMessage="نام خانوادگی را وارد کنید" Text="*" ControlToValidate="txtlastname" runat="server" ForeColor="Red" Display="Static" />
                            <asp:TextBox runat="server" ID="txtlastname" CssClass="form-control" placeholder="نام خانوادگی"
                                onfocus="document.getElementById('MainContent_lblmsg').style.display='none'" />
                        </div>

                        
                        <div class="form-group">
                            <label for="role">نقش</label>
                            <asp:CheckBoxList runat="server" ID="chkrole" RepeatDirection="Horizontal">
                                <asp:ListItem Text="&nbsp; مدیر " Selected="True" Enabled="false" Value="Modir" />
                                <asp:ListItem Text="&nbsp; مدیر ارشد " Value="Administrator" />
                            </asp:CheckBoxList>
                        </div>
                        <br />
                        <div class="form-group text-center">
                            <asp:Button Text="ایجاد مدیر جدید" runat="server" CssClass="btn btn-default" ID="btnregister" />

                        </div>
                    </div>

                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading text-center" style="padding: 10px; margin: 0px">
                    <h1 style="font-size: 1.2em; padding: 0px; margin: 0px">فهرست کاربران موجود</h1>
                </div>
                <div class="panel-body" style="padding: 10px 20px 10px 20px;">
                    <telerik:RadGrid ID="TRadGrid" runat="server" AllowPaging="True" CssClass="table-responsive" AllowSorting="True" AutoGenerateColumns="False"
                        BorderStyle="Solid"
                        PageSize="20" Skin="Outlook" Font-Names="yekan" DataSourceID="SqlDataSource_for_grid">
                        <GroupingSettings CollapseAllTooltip="Collapse all groups"></GroupingSettings>

                        <ClientSettings EnableRowHoverStyle="true" EnableAlternatingItems="true">
                        </ClientSettings>
                        <GroupPanel Text="برای گروه بندی عنوان ستون را به اینجا بکشید">
                        </GroupPanel>
                        <MasterTableView CssClass="table-responsive" DataSourceID="SqlDataSource_for_grid">
                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                <HeaderStyle Font-Bold="true" Width="20px" />
                            </RowIndicatorColumn>
                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                <HeaderStyle Font-Bold="true" Width="20px" />
                            </ExpandCollapseColumn>
                            <EditFormSettings>
                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                </EditColumn>
                            </EditFormSettings>
                            <Columns>
                                <telerik:GridTemplateColumn AllowFiltering="false" Groupable="False" HeaderText="ردیف" ReadOnly="True" UniqueName="radif">
                                    <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Width="10px" Font-Names="yekan" VerticalAlign="Middle" />
                                    <ItemTemplate>
                                        <center>
                                            <asp:Label ID="Grid_RowNumber_Label" runat="server"  Width="10px" />
                                        </center>
                                    </ItemTemplate>
                                    <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true"
                                        Width="30px" />
                                    <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="Center" Width="10px" Font-Names="yekan" VerticalAlign="Middle" />
                                </telerik:GridTemplateColumn>

                                <telerik:GridBoundColumn DataField="code" FilterControlAltText="Filter pagename column" ReadOnly="True" UniqueName="pagename" HeaderText="نام کاربری" Groupable="False">
                                    <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="150px" />
                                    <ItemStyle Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" Width="150px" />
                                </telerik:GridBoundColumn>
                                <telerik:GridBoundColumn DataField="Firstname" FilterControlAltText="Filter column column" HeaderText="نام" ReadOnly="True" UniqueName="column">
                                    <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" />
                                    <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                                </telerik:GridBoundColumn>
                                <telerik:GridBoundColumn DataField="Lastname" FilterControlAltText="Filter column1 column" HeaderText="نام خانوادگی" ReadOnly="True" UniqueName="column1">
                                    <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" />
                                    <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                                </telerik:GridBoundColumn>
                                <telerik:GridTemplateColumn DataField="role" Groupable="false" FilterControlAltText="Filter TemplateColumn column" HeaderText="نقش" ReadOnly="True" UniqueName="TemplateColumn">
                                    <ItemTemplate>
                                        <center>
                                            <asp:label text='<%# getfarsirole(Eval("role"), Eval("code")) %>' runat="server" />
                                        </center>
                                    </ItemTemplate>
                                    <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" />
                                    <ItemStyle Font-Names="yekan" VerticalAlign="Middle"  HorizontalAlign="Right"/>
                                </telerik:GridTemplateColumn>
                            </Columns>
                        </MasterTableView>
                        <PagerStyle FirstPageToolTip="اولین صفحه"
                            Font-Strikeout="False" HorizontalAlign="Center" LastPageToolTip="آخرین صفحه"
                            NextPagesToolTip="صفحه بعد" NextPageToolTip="صفحه بعد" PageSizeLabelText="تعداد سطر های هر صفحه:"
                            PrevPagesToolTip="صفحه قبل" PrevPageToolTip="صفحه قبل" />
                        <FilterMenu EnableImageSprites="False">
                        </FilterMenu>
                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                        </HeaderContextMenu>
                    </telerik:RadGrid>
                </div>
            </div>
        </div>
    </div>
    <asp:SqlDataSource ID="SqlDataSource_for_grid" runat="server" SelectCommandType="Text" SelectCommand="SELECT [Code],[Firstname],[LastName],[Password],[Role] FROM [Administrators]" />
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">
</asp:Content>
