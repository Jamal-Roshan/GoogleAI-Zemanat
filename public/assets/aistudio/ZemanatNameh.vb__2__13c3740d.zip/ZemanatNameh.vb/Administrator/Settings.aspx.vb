﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization

Public Class Settings
    Inherits System.Web.UI.Page
    Private utill As New Utility()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        initsettings()

    End Sub
    Protected Sub initsettings()
        Dim strselect As String = "SELECT  [Name],[Value],[TypeName],[Comment],[Align],[MaxLength] FROM [AppSettings] ORDER BY [SORT]"
        Dim setname As String
        Dim setvalue As String
        Dim settypename As String
        Dim setcomment As String
        Dim textboxid As String
        Dim MaxLength As Integer = 0

        Try
            Using connection As New SqlConnection(utill.connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()

                        While reader.Read()
                            setname = reader("Name").ToString()
                            setvalue = reader("Value").ToString()
                            settypename = reader("TypeName").ToString()
                            setcomment = reader("Comment").ToString()
                            MaxLength = CType(reader("MaxLength"), Integer)
                            textboxid = setname & "_" & settypename

                            Dim lblsetting As New Label()
                            lblsetting.Text = setcomment
                            lblsetting.ID = "lbl" & setname

                            Dim txtsetting As New TextBox()
                            txtsetting.Text = setvalue
                            txtsetting.ClientIDMode = ClientIDMode.Static
                            txtsetting.ID = textboxid
                            If MaxLength > 0 Then
                                txtsetting.MaxLength = MaxLength
                            End If


                            txtsetting.Attributes.Add("class", "form-control " & reader("Align").ToString())
                            If txtsetting.ID.ToUpper.Contains("NUMBER") Then
                                txtsetting.Attributes.Add("onkeyup", "javascript:this.value=Comma(this.value);")
                                txtsetting.Attributes.Add("onkeypress", "return isNumber(event)")
                            End If

                            Dim rqvalid As New RequiredFieldValidator()
                            rqvalid.ClientIDMode = ClientIDMode.Static
                            rqvalid.ErrorMessage = "مقدار " + setcomment + " را وارد کنید"
                            rqvalid.ForeColor = Drawing.Color.Red
                            rqvalid.SetFocusOnError = True
                            rqvalid.Display = ValidatorDisplay.Dynamic
                            rqvalid.SetFocusOnError = True
                            rqvalid.ControlToValidate = txtsetting.ID

                            Dim pnlrow As New Panel()
                            pnlrow.Attributes.Add("class", "row")

                            Dim firstcol As New Panel()
                            firstcol.Attributes.Add("Class", "col-lg-2 title-label")
                            firstcol.Controls.Add(lblsetting)

                            Dim secondcol As New Panel()
                            secondcol.Attributes.Add("Class", "col-lg-7")
                            secondcol.Controls.Add(txtsetting)
                            secondcol.ID = setname


                            Dim therdcol As New Panel()
                            therdcol.Attributes.Add("Class", "col-lg-3")
                            therdcol.Controls.Add(rqvalid)

                            pnlrow.Controls.Add(firstcol)
                            pnlrow.Controls.Add(secondcol)
                            pnlrow.Controls.Add(therdcol)

                            placeholdersetting.Controls.Add(pnlrow)

                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, Me.Page.Title, System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        Finally
        End Try

    End Sub

    Protected Sub btnsabt_Click(sender As Object, e As EventArgs) Handles btnsabt.Click
        Dim strupdate As String = "UPDATE [AppSettings] SET [Value] = @Value WHERE [Name]=@Name"
        Dim childa As Control
        Dim childb As Control
        Try
            For Each ctrl As Control In placeholdersetting.Controls
                For Each childa In ctrl.Controls
                    For Each childb In childa.Controls
                        If childb.GetType().ToString() = "System.Web.UI.WebControls.TextBox" Then
                            Dim textBox As TextBox = TryCast(childb, TextBox)
                            Dim textboxID As String = textBox.ID.ToUpper
                            Dim textboxtext As String = textBox.Text
                            If textboxID.Contains("NUMBER") Then
                                textboxtext = utill.Fa2En(textboxtext.Replace(",", ""))
                            End If
                            Using connection As New SqlConnection(utill.Connectionstring)
                                Using command As New SqlCommand(strupdate, connection)
                                    command.CommandType = CommandType.Text
                                    command.Parameters.Clear()
                                    command.Parameters.AddWithValue("@Value", Trim(textboxtext))
                                    command.Parameters.AddWithValue("@Name", textboxID.Substring(0, textboxID.IndexOf("_")))
                                    connection.Open()
                                    command.ExecuteNonQuery()
                                    connection.Close()
                                End Using
                            End Using
                        End If
                    Next
                Next
            Next
        Catch ex As Exception
            pnlmsg.Visible = True
            lblmsg.Text = "در ثبت اطلاعات خطا رخ داده است"
            utill.RegisterError(ex.Message, Me.Page.Title, System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return
        Finally
        End Try
        pnlmsg.Visible = True
        lblmsg.Text = "اطلاعات با موفقیت ثبت شد"
    End Sub
End Class