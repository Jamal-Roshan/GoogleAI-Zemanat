﻿Public Class resetadminpassword
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnenter_Click(sender As Object, e As EventArgs) Handles btnenter.Click
        If Page.IsValid Then
            lblmsg.Text = ""
            Dim utill As New Utility()
            If utill.Fa2En(txtusername.Text.Trim.ToLower) = utill.Fa2En(HttpContext.Current.User.Identity.Name.Trim.ToLower) Then
                lblmsg.Text = "در حال حاضر شما با این نام کاربری وارد سایت شده اید و نمی توانید رمز آن را ریست کنید" & "<br/>" & "برای تغییر رمز از منوی تغییر کلمه عبور اقدام نمایید"
                Exit Sub
            End If
            Dim Adminmem As New AdminMembership()
            Dim result As Integer = Adminmem.ResetAdminPassword(utill.Fa2En(txtusername.Text.Trim.ToLower))
            Select Case result
                Case -2
                    lblmsg.Text = "در ریست رمز خطا به وجود آمده است"
                Case -1
                    lblmsg.Text = "در یافتن حساب کاربری خطا به وجود آمده است"
                Case 0
                    lblmsg.Text = "حساب کاربری با این نام کاربری وجود ندارد"
                Case 1
                    lblmsg.Text = "رمز نام کاربری وارد شده با موفقیت ریست شد" & "<br/>" & "رمز جدید برابر با نام کاربری وارد شده است"
            End Select
        End If
    End Sub
End Class