﻿<%@ Page Language="vb" AutoEventWireup="false" CodeBehind="Login.aspx.vb" Inherits="ZemanatNameh.vb.Login" UnobtrusiveValidationMode="None" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />

    <link href="Content/bootstrap.css" rel="stylesheet" />
    <link href="Content/bootstrap-theme.min.css" rel="stylesheet" />
    <link href="Content/font-awesome.min.css" rel="stylesheet" />
    <link href="Content/Main.css" rel="stylesheet" />

    <script src="Scripts/jquery-2.2.0.min.js" type="text/javascript"></script>
    <script src="Scripts/bootstrap.js"></script>
    <script src="Scripts/jquery.mobile.customized.min.js"></script>
    <script src="Scripts/jquery.easing.1.3.js"></script>
    <script src="Scripts/persianumber.min.js"></script>
    <script src="Scripts/floatlabels.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        body, html {
            height: 100%;
            background-repeat: no-repeat;
            /*background-image: linear-gradient(rgb(19, 81, 164), rgb(128, 134, 251));*/
        }

        .form-signin {
            max-width: 330px;
            padding: 15px;
            margin: 0 auto;
        }

            .form-signin .form-signin-heading, .form-signin .checkbox {
                margin-bottom: 10px;
            }

            .form-signin .checkbox {
                font-weight: normal;
            }

            .form-signin .form-control {
                position: relative;
                font-size: 16px;
                height: auto;
                padding: 10px;
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
            }

                .form-signin .form-control:focus {
                    z-index: 2;
                }

            .form-signin input[type="text"] {
                margin-bottom: 4px;
                border-bottom-left-radius: 0;
                border-bottom-right-radius: 0;
            }

            .form-signin input[type="password"] {
                margin-bottom: 10px;
                border-top-left-radius: 0;
                border-top-right-radius: 0;
            }

        .account-wall {
            margin-top: 20px;
            padding: 40px 0px 20px 0px;
            background-color: #f7f7f7;
            -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
            -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
            box-shadow: 0px 0px 2px 2px rgba(0, 0, 0, 0.3);
        }

        .login-title {
            color: #555;
            font-size: 18px;
            font-weight: 400;
            display: block;
        }



        .need-help {
            margin-top: 10px;
        }

        .new-account {
            display: block;
            margin-top: 10px;
        }

        .errormessage {
            padding-bottom: 10px;
            display: block;
            text-align: center;
        }

        #captcha_ctl00 {
            color: red;
            padding-bottom: 5px;
            display: block;
            text-align: center;
            font-size: 14px;
        }

        .rcCaptchaAudioLink {
            background-image: url('Images/audio_but.png');
            background-repeat: no-repeat;
            height: 30px;
            font-size:.8em;
            display:block;
            width:120px;
                   }
        #btnRefreshImage
        {
            background: url('Images/audio_but.p') ;
             background-repeat: no-repeat;
            /*width: 25px;
            height: 25px;*/
        }
 
        .rcRefreshImage
        {
            text-indent:-9999px;
        }
        #captcha_SpamProtectorPanel{
             margin-bottom:0px;
             padding-bottom:0px;
        }
    </style>
    <script type="text/javascript">
        function InvalidMsg(textbox, msg) {

            if (textbox.value === '') {
                textbox.setCustomValidity(msg);
            }

            else {
                textbox.setCustomValidity('');
            }
            return true;
        }
    </script>
    <script type="text/javascript">

       <%-- function RefreshImage() {
            var captcha = $find("<%=captcha.ClientID %>");
            document.location = $get(captcha.get_id() + "_CaptchaLinkButton").href;
        }--%>

    </script>
    <script type="text/javascript">
        $(document).ready(function () {
            $("#captcha_CaptchaTextBox").attr("required", "required");
            $("#captcha_CaptchaTextBox").attr("placeholder", "کد امنیتی");
            $("#captcha_CaptchaTextBox").attr("oninvalid","InvalidMsg(this,'کد امنیتی را وارد  کنید');");
            $("#captcha_CaptchaTextBox").attr("oninput", "InvalidMsg(this,'کد امنیتی را وارد  کنید');");
            $("#captcha_CaptchaLinkButton").attr("tabindex", "-1"); 
            $("#captcha_CaptchaAudioCodeUP").attr("tabindex", "-1");

        });
    </script>
</head>
<body>
   
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-4 col-md-offset-4">
                <h1 class="text-center login-title">
                    <asp:Label ID="orgtitle" Text="" runat="server" />
                </h1>
                <h5 class="text-center " style="color: dodgerblue">سامانه صدور گواهی حقوقی و ضمانت نامه بانکی</h5>
                <div class="account-wall">
                    <div class="text-center"><span style="font-size: xx-large" class="fa fa-user-circle" aria-hidden="true"></span></div>

                    <form class="form-signin" runat="server" >

                        <asp:Label ID="lblerrormessage" ForeColor="Red" runat="server" Text="اطلاعات ورودی معتبر نیست" CssClass="errormessage" Visible="false"></asp:Label>
                        <asp:RequiredFieldValidator ErrorMessage="*" ControlToValidate="txtprsid" runat="server" ForeColor="Red" />
                        <input type="text" class="form-control" id="txtprsid" name="txtprsid" runat="server" placeholder="شماره پرسنلی" required="required" autofocus="autofocus"
                            oninvalid="InvalidMsg(this,'شماره پرسنلی را وارد کنید');" oninput="InvalidMsg(this,'شماره پرسنلی را وارد کنید');" />
                        <asp:RequiredFieldValidator ErrorMessage="*" ControlToValidate="txtpassword" runat="server" ForeColor="Red" />
                        <input type="password" class="form-control" id="txtpassword" name="txtpassword" runat="server" placeholder="کلمه عبور" required="required"
                            oninvalid="InvalidMsg(this,'کلمه عبور را وارد کنید');" oninput="InvalidMsg(this,'کلمه عبور را وارد کنید');" />

                        <asp:ScriptManager runat="server" />


                        <div class="form-control text-center" style="display: block; text-align: center !important; margin-bottom: 10px;">
                           <%-- <telerik:RadCaptcha ID="captcha" runat="server" ErrorMessage="کد امنیتی صحیح نیست" CaptchaTextBoxLabel=""
                                ToolTip="کد امنیتی" CaptchaImage-TextLength="5" CaptchaImage-TextColor="Blue" CaptchaImage-ImageCssClass="img img-responsive  center-block"
                                TextBoxDecoration-CssClass=" form-control text-center" TextBoxDecoration-ToolTip="کد امنیتی بالا را در اینجا بازنویسی کنید" 
                                 
                                CaptchaImage-TextChars="Letters" CaptchaImage-EnableCaptchaAudio="True"
                                CaptchaAudioLinkButtonText="شنیدن کد امنیتی" EnableRefreshImage="true">
                            </telerik:RadCaptcha>
                            
                            <img src="Images/reload.png" onclick="RefreshImage(); return false;" width="30"  class=" img-responsive img-thumbnail " alt="کد امنیتی جدید"
                                style="margin-top:-225px; margin-right:200px" title="کد امنیتی جدید"  />
                           --%>
                        </div>
                        <asp:Button ID="btnsignin" Text="ورود" runat="server" CssClass="btn btn-lg btn-primary btn-block" type="submit" />
                        

                    </form>
                    <p style="padding-left:10px; padding-right:15px; padding-top:0px; padding-bottom:0px; margin:0 auto; width:80% ">
                            برای مشاهده و استفاده بهتر از این سامانه از مرورگر
                        <a href="https://www.google.com/chrome/browser/" target="_blank">Google Chrome </a>
                        یا مرورگر
                         <a href="http://www.opera.com/download/" target="_blank">Opera </a>
                         استفاده کنید
                        </p>
                </div>
            </div>
        </div>
        
    </div>
</body>
</html>