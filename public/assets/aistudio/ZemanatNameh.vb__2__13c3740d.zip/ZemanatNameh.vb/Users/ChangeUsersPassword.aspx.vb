﻿Public Class ChangeUserPassword
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnregister_Click(sender As Object, e As EventArgs) Handles btnregister.Click
        If Page.IsValid Then
            Dim utill As New Utility()
            Dim Usermem As New UserMembership()
            Dim Password_hash As String = ""
            Password_hash = BCrypt.Net.BCrypt.HashPassword(txtpassword.Text, 4)
            Dim result As Integer = Usermem.ChangeUserPassword(HttpContext.Current.User.Identity.Name, txtoldpassword.Text, txtpassword.Text)
            Select Case result
                Case 0
                    lblmsg.Text = "کلمه عبور وارد شده با کلمه عبور ذخیره شده یکسان نیست"
                Case 1
                    lblmsg.Text = "کلمه عبور شما با موفقیت تغییر یافت"
                Case 2
                    lblmsg.Text = "در عملیات تغییر کلمه عبور خطا به وجود آمده است"
            End Select
        End If
    End Sub
End Class