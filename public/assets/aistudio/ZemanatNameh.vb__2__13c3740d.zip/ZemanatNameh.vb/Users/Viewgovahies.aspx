﻿<%@ Page Title="مشاهده موارد صادر شده" Language="vb" AutoEventWireup="false" MasterPageFile="~/Users/MasterPage.Master" CodeBehind="Viewgovahies.aspx.vb" Inherits="ZemanatNameh.vb.Viewgovahies" %>



<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">

    <script type="text/javascript">
        function isNumber(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }

        function confirmPrint() {
            var xCounter = 0;
            if (chk_Array_IDs !== null) {

                for (i = 0; i < chk_Array_IDs.length; i++) {
                    var ref_chk = document.getElementById(chk_Array_IDs[i]);
                    if (ref_chk !== null)
                        if (ref_chk.checked === true)
                            ++xCounter;
                }
                if (xCounter === 0) {
                    alert("هیچ گواهی و یا ضمانت نامه ای انتخاب نشده است ");
                    return false;
                }
                else {
                    var ret_confirm = confirm("آیا برای چاپ مجدد اطمینان دارید؟");
                    if (ret_confirm === true) {
                        checkclick = "true";
                        return true;
                    }
                    else
                        return false;
                }
            }
        }

    </script>
   
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
   

    <telerik:radscriptmanager ID="RadScriptManager1" runat="server">
        <Scripts>
            <asp:ScriptReference Assembly="Telerik.Web.UI" Name="Telerik.Web.UI.Common.Core.js" />
            <asp:ScriptReference Assembly="Telerik.Web.UI" Name="Telerik.Web.UI.Common.jQuery.js" />
            <asp:ScriptReference Assembly="Telerik.Web.UI" Name="Telerik.Web.UI.Common.jQueryInclude.js" />
        </Scripts>
    </telerik:radscriptmanager>

    <div class=" container">
        <div class="row" id="Dashbord" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">

            <div>
                <asp:ImageButton ImageUrl="../Images/excel.png" ID="btnExportToexcel" runat="server" ToolTip="ارسال لیست به فایل اکسل" Height="35px" Visible="false" Style="margin-right: 5px;" ClientIDMode="Static" />
                <asp:ImageButton ImageUrl="../Images/printer.png" ID="btnprint" runat="server" ToolTip="چاپ مجدد گواهی های تسویه نشده و صادر شده در ماه جاری" Height="35px" Visible="false" Style="margin-right: 5px;" OnClientClick="return confirmPrint();" ClientIDMode="Static" />
                <asp:ImageButton ImageUrl="../Images/PrintList.png" ID="ImageButton_Print_List" runat="server" ToolTip="چاپ گزارش گواهی های تسویه نشده" Height="35px" Visible="false" Style="margin-right: 5px;" ClientIDMode="Static" />

                <link href="../Content/tooltip/tooltip.css" rel="stylesheet" />
               
                <script src="./Scripts/tooltip/tooltip.js"></script>
                <script type="text/javascript">
                    $('#btnExportToexcel,#btnprint,#ImageButton_Print_List').tooltip({

                        // 'left', 'right', 'below' or 'above'
                        direction: "below",

                        // in ms
                        delay: 50                         

                    });

                </script>


            </div>

            <asp:Panel ID="pnlgrid" runat="server" CssClass="panel-body" Style="padding: 5px">
                <asp:Panel runat="server" ID="pnlmsg" BackColor="LightYellow" Style="padding: 8px" Visible="false">
                    <p>
                        <asp:Label Text="" ID="lblmessage" runat="server" ForeColor="Red" />

                    </p>
                </asp:Panel>
                
                
              

                <telerik:RadGrid ID="RadGrid1" runat="server" AllowPaging="True" CssClass="table-responsive" AllowSorting="True" AutoGenerateColumns="False" PageSize="50"
                    BorderStyle="Solid" Skin="Outlook" Font-Names="yekan" MasterTableView-NoMasterRecordsText="هیچ اطلاعاتی برای نمایش موجود نیست" GroupingSettings-GroupSplitDisplayFormat="نمایش {0} از {1} " PagerStyle-PageSizeLabelText="اندازه صفحه" PagerStyle-NextPageToolTip="صفحه بعد" PagerStyle-NextPagesToolTip="صفحه بعد" PagerStyle-LastPageToolTip="آخرین صفحه" PagerStyle-FirstPageToolTip="اولین صفحه" PagerStyle-GoToPageButtonToolTip="برو به صفحه">
                    <GroupingSettings CollapseAllTooltip="Collapse all groups"></GroupingSettings>
                    <ClientSettings EnableRowHoverStyle="true" EnableAlternatingItems="true" Selecting-AllowRowSelect="true">
                        <Selecting AllowRowSelect="True" />
                    </ClientSettings>
                    <ExportSettings Pdf-AllowPrinting="true" Pdf-PaperSize="A4" IgnorePaging="true" OpenInNewWindow="true">
                        <Pdf PageHeight="210mm" PageWidth="297mm" DefaultFontFamily="B Nazanin" PageTopMargin="15mm" PageLeftMargin="15mm" PageRightMargin="15mm"
                            BorderStyle="Medium" BorderType="AllBorders" BorderColor="Black">
                        </Pdf>
                        <Word Format="Docx" />
                    </ExportSettings>
                    <MasterTableView CssClass="table-responsive" DataKeyNames="RowID,GovahiTypeID,StateId,DateOfCreate">
                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                            <HeaderStyle Font-Bold="true" Width="20px" />
                        </RowIndicatorColumn>
                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                            <HeaderStyle Font-Bold="true" Width="20px" />
                        </ExpandCollapseColumn>
                        <EditFormSettings>
                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                            </EditColumn>
                        </EditFormSettings>
                        <Columns>
                            <telerik:GridClientSelectColumn Reorderable="False" UniqueName="chkRow">
                                <HeaderStyle Width="30px"></HeaderStyle>
                            </telerik:GridClientSelectColumn>

                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="False" HeaderText="ردیف" ReadOnly="True" UniqueName="radif" AllowSorting="true">
                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Width="10px" Font-Names="yekan" VerticalAlign="Middle" />
                                <ItemTemplate>
                                    <asp:Label ID="Grid_RowNumber_Label" runat="server" />
                                </ItemTemplate>
                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="40px" />
                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="Center" Width="10px" Font-Names="yekan" VerticalAlign="Middle" />
                            </telerik:GridTemplateColumn>

                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="شماره گواهی" ReadOnly="True" DataField="Shomareh" UniqueName="Shomareh" AllowSorting="true" SortExpression="Shomareh">
                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                <ItemTemplate>
                                    <asp:Label ID="lblshomarehgovahei" runat="server" Text='<%# (Eval("Shomareh")) %>'></asp:Label>
                                </ItemTemplate>
                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="60px" />
                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="center" Font-Names="yekan" VerticalAlign="Middle" />
                            </telerik:GridTemplateColumn>

                            <telerik:GridBoundColumn DataField="BankFullname" HeaderText="نام بانک" ReadOnly="True" UniqueName="BankFullname" Groupable="true" AllowSorting="true" AllowFiltering="False">
                                <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="150px" Font-Bold="true" />
                                <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                            </telerik:GridBoundColumn>

                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="مبلغ ضمانت" ReadOnly="True" DataField="LoanAmount"
                                UniqueName="LoanAmount" AllowSorting="true" SortExpression="LoanAmount">
                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                <ItemTemplate>
                                    <asp:Label ID="lblLoanAmount" runat="server" Text='<%# (DataBinder.Eval(Container.DataItem, "LoanAmount", "{0:##,###}"))%>'></asp:Label>
                                </ItemTemplate>
                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="70px" />
                                <ItemStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" HorizontalAlign="left" Font-Names="yekan" VerticalAlign="Middle" />
                            </telerik:GridTemplateColumn>

                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="خالص دریافتی" ReadOnly="True" DataField="MablaghKhalesDaryafti"
                                UniqueName="MablaghKhalesDaryafti" AllowSorting="true" SortExpression="MablaghKhalesDaryafti">
                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                <ItemTemplate>
                                    <asp:Label runat="server" Text='<%# (DataBinder.Eval(Container.DataItem, "MablaghKhalesDaryafti", "{0:#,###,###}"))%>'></asp:Label>
                                </ItemTemplate>
                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="70px" />
                                <ItemStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" HorizontalAlign="left" Font-Names="yekan" VerticalAlign="Middle" />
                            </telerik:GridTemplateColumn>

                            <telerik:GridBoundColumn DataField="LoanOwner_FirstName" HeaderText="نام وام گیرنده" ReadOnly="True" UniqueName="LoanOwner_FirstName" Groupable="false" AllowSorting="true" AllowFiltering="False">
                                <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="80px" Font-Bold="true" />
                                <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                            </telerik:GridBoundColumn>

                            <telerik:GridBoundColumn DataField="LoanOwner_LastName" HeaderText="نام خانوادگی وام گیرنده" ReadOnly="True" UniqueName="LoanOwner_LastName" Groupable="false" AllowSorting="true" AllowFiltering="False">
                                <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="100px" Font-Bold="true" />
                                <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                            </telerik:GridBoundColumn>
                            <telerik:GridBoundColumn DataField="LoanOwner_FatherName" HeaderText="نام پدر وام گیرنده" ReadOnly="True" UniqueName="LoanOwner_FatherName" Groupable="false" AllowSorting="true" AllowFiltering="False">
                                <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="80px" Font-Bold="true" />
                                <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                            </telerik:GridBoundColumn>

                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="نوع گواهی" ReadOnly="True" DataType="System.Int16"
                                DataField="GovahiTypeID" UniqueName="GovahiTypeID" AllowSorting="true" SortExpression="GovahiTypeID">
                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                <ItemTemplate>
                                    <asp:Label runat="server" Text='<%# utill.GetGovahiType(Eval("GovahiTypeID")) %>'></asp:Label>
                                </ItemTemplate>
                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="70px" />
                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="right" Font-Names="yekan" VerticalAlign="Middle" />
                            </telerik:GridTemplateColumn>

                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="وضعیت گواهی" ReadOnly="True" DataField="StateId" UniqueName="StateId" AllowSorting="true" SortExpression="StateId">
                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                <ItemTemplate>
                                    <asp:Label runat="server" Text='<%# utill.GetGovahiStatus(Eval("StateId")) %>' ForeColor='<%# getcolor(Eval("StateId")) %>'></asp:Label>
                                </ItemTemplate>
                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="70px" />
                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="center" Font-Names="yekan" VerticalAlign="Middle" />
                            </telerik:GridTemplateColumn>

                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="تاریخ تبت" ReadOnly="True" DataField="DateOfCreate" UniqueName="DateOfCreate" AllowSorting="true" SortExpression="DateOfCreate">
                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                <ItemTemplate>
                                    <asp:Label ID="lblDateOfCreate" runat="server" Text='<%# utill.En2Fa(utill.DateToString(Eval("DateOfCreate"))) %>'></asp:Label>
                                </ItemTemplate>
                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="70px" />
                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="center" Font-Names="yekan" VerticalAlign="Middle" />
                            </telerik:GridTemplateColumn>

                        </Columns>
                    </MasterTableView>
                    <PagerStyle FirstPageToolTip="اولین صفحه"
                        Font-Strikeout="False" HorizontalAlign="Center" LastPageToolTip="آخرین صفحه"
                        NextPagesToolTip="صفحه بعد" NextPageToolTip="صفحه بعد" PageSizeLabelText="تعداد سطر های هر صفحه:"
                        PrevPagesToolTip="صفحه قبل" PrevPageToolTip="صفحه قبل" />
                    <FilterMenu EnableImageSprites="False">
                    </FilterMenu>
                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                    </HeaderContextMenu>
                </telerik:RadGrid>
                <div class="row" style="padding-bottom: 5px; padding-top: 5px;">
                    <div class="col-lg-2 col-md-12 col-sm-12 col-xs-12 text-center">
                        <asp:Label Text="" ID="lblNumberOfActiveGovahie" runat="server" ForeColor="DarkBlue" />
                    </div>
                    <div class="col-lg-2 col-md-12 col-sm-12 col-xs-12 text-center">
                        <asp:Label Text="" ID="lblNumberOfActiveZemanatnameh" runat="server" ForeColor="DarkBlue" />
                    </div>
                    <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 text-center">
                        <asp:Label Text="" ID="lblactive" runat="server" ForeColor="DarkBlue" Font-Size=".93em" />
                    </div>
                    <div class="col-lg-2 col-md-12 col-sm-12 col-xs-12 text-center">
                        <asp:Label Text="" ID="lblTasviyeh" runat="server" ForeColor="DarkBlue" />
                    </div>
                    <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 text-center">
                        <asp:Label Text="" ID="lbltotal" runat="server" ForeColor="DarkBlue" />
                    </div>
                </div>

            </asp:Panel>
        </div>
    </div>

    <telerik:radajaxmanager ID="RadAjaxManager1" runat="server">
        <ClientEvents OnResponseEnd="TraceNodes(document);" />
        <AjaxSettings>
            <telerik:AjaxSetting AjaxControlID="RadGrid1">
                <UpdatedControls>
                    <telerik:AjaxUpdatedControl ControlID="pnlgrid" LoadingPanelID="RadAjaxLoadingPanel1"></telerik:AjaxUpdatedControl>
                </UpdatedControls>
            </telerik:AjaxSetting>
        </AjaxSettings>
    </telerik:radajaxmanager>
    <telerik:radajaxloadingpanel ID="RadAjaxLoadingPanel1" runat="server" BackgroundPosition="Top"></telerik:radajaxloadingpanel>
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">
    <script>
        String.prototype.toPersianDigit = function (a) {
            return this.replace(/\d+/g, function (digit) {
                var enDigitArr = [], peDigitArr = [];
                for (var i = 0; i < digit.length; i++) {
                    enDigitArr.push(digit.charCodeAt(i));
                }
                for (var j = 0; j < enDigitArr.length; j++) {
                    peDigitArr.push(String.fromCharCode(enDigitArr[j] + ((!!a && a === true) ? 1584 : 1728)));
                }
                return peDigitArr.join('');
            });
        };

        function TraceNodes(Node) {
            if (Node.nodeType === 3 && Node.parentNode.localName !== "style" && Node.parentNode.localName !== "script")  //TextNode
                Node.nodeValue = Node.nodeValue.toPersianDigit();
            else
                for (var i = 0; i < Node.childNodes.length; i++)
                    TraceNodes(Node.childNodes[i]);
        }

        TraceNodes(document);
    </script>
</asp:Content>
