﻿<%@ Page Title="صدور گواهی حقوقی" Language="vb" AutoEventWireup="false" MasterPageFile="~/Users/MasterPage.Master" CodeBehind="sodurGovahie.aspx.vb" Inherits="ZemanatNameh.vb.sodurGovahie" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style type="text/css">
        .titletd {
            /*  width: 250px;*/
        }

        .ui-corner-all {
            font-family: Yekan;
        }

        .myrow {
            padding-bottom: 5px !important;
            padding-top: 8px !important;
            background-color: lightyellow;
            margin-bottom: 5px;
            vertical-align: middle;
        }

        .ui-autocomplete {
            height: 350px;
            overflow: scroll;
        }
    </style>


    <script src="./Scripts/jQueryUI.1.10.3.min.js"></script>
    <link href="Content/jquery-ui.css" rel="stylesheet" />

    <script type="text/javascript">
        $(function () {
            $("#txtbankname").autocomplete({
                source: function (request, response) {
                    var param = { bankname: $('#txtbankname').val() };
                    $.ajax({
                        //sodurZemanatnameh.aspx
                        url: "./users/sodurZemanatnameh.aspx/GetBankname",
                        data: JSON.stringify(param),
                        dataType: "json",
                        type: "POST",
                        contentType: "application/json; charset=utf-8",
                        dataFilter: function (data) { return data; },
                        success: function (data) {
                            response($.map(data.d, function (item) {
                                return {
                                    value: item
                                }
                            }))
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            var err = eval("(" + XMLHttpRequest.responseText + ")");
                            alert(err.Message)
                            // console.log("Ajax Error!");  
                        }
                    });
                },
                minLength: 2 //This is the Char length of inputTextBox  
            });
        });
        function InvalidMsg(textbox, msg) {

            if (textbox.value === '') {
                textbox.setCustomValidity(msg);
            }

            else {
                textbox.setCustomValidity('');
            }
            return true;
        }
        function clearform() {
            $('input:text').val('');
            $('#txtbankname').focus();
            document.getElementById('mablaghfarsiRial').innerHTML = '';
            document.getElementById('mablaghfarsiToman').innerHTML = '';
        }
        function Comma(Num) {
            Num += '';
            Num = Num.replace(',', ''); Num = Num.replace(',', ''); Num = Num.replace(',', '');
            Num = Num.replace(',', ''); Num = Num.replace(',', ''); Num = Num.replace(',', '');
            x = Num.split('.');
            x1 = x[0];
            x2 = x.length > 1 ? '.' + x[1] : '';
            var rgx = /(\d+)(\d{3})/;
            while (rgx.test(x1))
                x1 = x1.replace(rgx, '$1' + ',' + '$2');
            return x1 + x2;
        }
        function isNumber(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }
    </script>
    <script>
        function confirmGO() {
            var ret_confirm = confirm("آیا از صحت اطلاعات وارد شده اطمینان دارید؟");
            if (ret_confirm === true) {
                checkclick = "true";
                return true;
            }
            else
                return false;
        }
    </script>
    <script src="./Scripts/jquery.farsiInput.js"></script>
    <script type="text/javascript">
        $(function () {
            $("#txtbankname").farsiInput();
        });
    </script>
    <script src="./Scripts/wordifyfa.js"></script>
    <script type="text/javascript">
        function mablaghbehoorof() {
            var m = document.getElementById('txtmablaghvam').value.replace(',', '');
            m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', '');
            m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', '');
            document.getElementById('mablaghfarsiRial').innerHTML = wordifyRials(m);
            if (wordifyRials(m) === 'undefined ریال') {
                document.getElementById('mablaghfarsiRial').innerHTML='صفر ریال'
            }
            document.getElementById('mablaghfarsiToman').innerHTML = wordifyRialsInTomans(m);
        }

    </script>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <asp:ScriptManager runat="server" />
    <asp:Panel runat="server" ID="cont" CssClass=" container" DefaultButton="btnContinue">
        <div class="row" id="Dashbord" style="direction: rtl; border: 1px solid lightgray; margin: 1px 6px 0px 6px; background-color: whitesmoke">
            <div class=" panel panel-primary" style="margin-bottom: 0px !important; padding-bottom: 0px !important;">
                <div class=" panel-heading">
                    <div class="panel-title text-center">
                        صدور گواهی حقوقی
                    </div>

                </div>
                <div class="panel-body " style="margin: 0 auto; width: 70%">
                    <asp:Panel runat="server" ID="pnlmsg" CssClass="row text-center" Visible="false" BackColor="LightYellow">
                        <asp:Label Text="" ID="lblmsg" ForeColor="Red" runat="server" />

                    </asp:Panel>
                    <br />

                    <div class="row myrow">
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <label for="txtbankname">نام و شعبه بانک /موسسه مالی:</label>
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                            <asp:TextBox runat="server" ID="txtbankname" MaxLength="230" ClientIDMode="Static" CssClass=" form-control" required="required" autofocus="autofocus"
                                oninvalid="InvalidMsg(this,'نام کامل بانک یا موسسه مالی را وارد کنید');"
                                oninput="InvalidMsg(this,'نام کامل بانک یا موسسه مالی را وارد کنید');" />
                        </div>
                    </div>
                    <div class="row myrow">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            حداکثر مبلغ مجاز شما جهت ضمانت نامه :
                            <asp:Label Text="" runat="server" ID="lblmaxloan" ForeColor="Blue" Font-Bold="true" />
                        </div>
                        <br />
                        <br />
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <label for="txtmablaghvam">مبلغ وام (ریال):</label>
                        </div>

                        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                            <asp:TextBox runat="server" ID="txtmablaghvam" MaxLength="18" ClientIDMode="Static" CssClass=" form-control" required="required" autofocus="autofocus"
                                oninvalid="InvalidMsg(this,'مبلغ وام را وارد کنید');"
                                oninput="InvalidMsg(this,'مبلغ وام را وارد کنید');"
                                onkeyup="javascript:this.value=Comma(this.value);mablaghbehoorof()"
                                onkeypress="return isNumber(event)"
                                Font-Bold="true" Font-Size="16px" />
                            <div>
                                <label id="mablaghfarsiToman" style="color: royalblue"></label>
                            </div>
                            <div>
                                <label id="mablaghfarsiRial" style="color: green"></label>
                            </div>


                        </div>
                    </div>

                </div>
                <div class=" panel-footer text-center">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 text-center">
                            <asp:Button Text="ثبت و چاپ" runat="server" CssClass="btn btn-primary " ID="btnContinue" OnClientClick="return confirmGO();" />
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 text-center">
                            <input type="button" name="btnclear" value="پاک کردن فرم" class="btn btn-primary" onclick="return clearform();" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </asp:Panel>


</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">
</asp:Content>
