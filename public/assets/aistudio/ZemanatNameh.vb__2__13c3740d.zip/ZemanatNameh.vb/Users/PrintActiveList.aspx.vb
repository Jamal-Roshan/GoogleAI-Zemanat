﻿Imports System.Data.SqlClient
Imports Stimulsoft.Report
Public Class PrintActiveList
    Inherits System.Web.UI.Page
    Private utill As New Utility
    Private vahed As String = " ریال "
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim strselect As String = "SELECT Users_table.Code, Govahies.RowID, Govahies.Shomareh, Govahies.BankFullname, Govahies.LoanAmount, Govahies.LoanOwner_FirstName, Govahies.LoanOwner_LastName, " _
                        & "  Govahies.LoanOwner_FatherName, Govahies.DateOfCreate, Vaziyat_Eshteghal.Title As Eshteghal, EmployeeTypes.Title As Estekhdam, Users_table.Firstname, Users_table.Lastname, 'PersianDate' AS PersianDate, " _
                        & "  Users_table.Fathername, Users_table.NationalID, Govahistatus.Title AS VAziyatGovahie, GovahiTypes.Id, GovahiTypes.Title AS GovahieType FROM Users_table INNER JOIN  Govahies ON Users_table.Code = Govahies.Code INNER JOIN " _
                        & "  Vaziyat_Eshteghal ON Users_table.EshteghalID = Vaziyat_Eshteghal.EshteghalID INNER JOIN  EmployeeTypes ON Users_table.EstekhdamID = EmployeeTypes.Type_ID INNER JOIN  Govahistatus ON Govahies.StateId = Govahistatus.Status_ID INNER JOIN " _
                        & "  GovahiTypes ON Govahies.GovahiTypeID = GovahiTypes.Id WHERE  (Govahies.StateId = 1) AND (Users_table.Code = @Code) ORDER BY Govahies.DateOfCreate DESC "


        ' Dim sum As Double = 0

        Dim dt As New DataTable()

        Using connection As New SqlConnection(utill.Connectionstring)
            Using command As New SqlCommand(strselect, connection)
                command.CommandType = CommandType.Text
                command.Parameters.Clear()
                command.Parameters.AddWithValue("@Code", HttpContext.Current.User.Identity.Name)
                Using sda As New SqlDataAdapter(command)

                    Try
                        dt.Clear()
                        sda.Fill(dt)
                        For Each datarow As DataRow In dt.Rows
                            Dim RowID As Long = CType(datarow.Item("RowID"), Long)
                            Dim row() As DataRow
                            row = dt.Select("ROWID=" & RowID)
                            row(0)("PersianDate") = utill.GetPersianDate(CType(datarow.Item("DateOfCreate"), Date))
                        Next
                    Catch ex As Exception
                        dt.Clear()
                        lblmessage.Text = "در عملیت چاپ گزارش خطا رخ داده است.لطفا دوباره سعی کنید."
                        pnlmsg2.Visible = False
                        pnlmsg.Visible = True
                        Exit Sub
                    End Try

                    'Try
                    '    sum = CType(dt.Compute("sum(LoanAmount)", "StateId=1"), Long)
                    'Catch ex As Exception
                    '    Server.ClearError()
                    '    sum = 0
                    'End Try

                End Using
            End Using
        End Using



        Dim code As String = HttpContext.Current.User.Identity.Name
        Dim NationalID As String = utill.Get_NationalID_By_Code(code)
        Dim Firstname As String = utill.Get_Firstname_By_Code(code)
        Dim Lastname As String = utill.Get_Lastname_By_Code(code)
        Dim orgtitle As String = utill.Get_Application_Settings(AppSettings.orgtitle.ToString).Trim & " - واحد " & utill.Get_Application_Settings(AppSettings.orgunittitle.ToString).Trim
        Dim Eshteghal As String = utill.Get_EshteghalType_By_EshteghalID(utill.Get_EshteghalID_By_Code(code)).Trim
        Dim Estekhdam As String = utill.Get_EstekhdamType_By_EstekhdamID(utill.Get_EstekhdamID_By_Code(code))
        Dim MablaghKhales As Long = utill.Get_Khalesdaryafti_By_Code(code)

        Dim serverlocation As String = HttpContext.Current.Server.MapPath(String.Empty)
        Dim myreport As New StiReport()
        myreport.Load(serverlocation + "\reports\ActiveList.mrt")
        myreport.Dictionary.Variables.Clear()

        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "orgtitle", orgtitle))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "firstname", Firstname))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "lastname", Lastname))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "prscode", code))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "nidcode", NationalID))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "eshteghal", Eshteghal))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "estekhdam", Estekhdam))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "printdate", utill.GetPersianDate(Today)))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "mablaghkhales", MablaghKhales))

        myreport.RegData(dt)
        myreport.Compile()
        myreport.Dictionary.Synchronize()
        myreport.Render(True)
        StiWebViewer1.Report = myreport

        dt.Clear()


    End Sub

End Class