﻿Imports System.Data.SqlClient
Public Class MaterPage
    Inherits System.Web.UI.MasterPage
    Private Utill As New Utility()
    Private usermember As New UserMembership()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Utill.IsUpdating Then
            Response.Redirect("./Updating", True)
        End If
        Session.Add("returl", "home")
        lbluserfullname.Text = usermember.GetUserFullname(HttpContext.Current.User.Identity.Name)
        Using sqlCon As New SqlConnection(Utill.connectionstring)
            Dim sqlSelectstring As String = "SELECT [Value] FROM [AppSettings]  where [name]='orgtitle' or [name]='urladdress' order by [name]"
            Using selectCommand As New SqlCommand(sqlSelectstring, sqlCon)
                selectCommand.CommandType = CommandType.Text
                Try
                    sqlCon.Open()
                    Using sqldr As SqlDataReader = selectCommand.ExecuteReader()
                        If sqldr.HasRows Then
                            sqldr.Read()
                            urladdress.Text = sqldr.Item("value").ToString()
                            urladdress1.Text = urladdress.Text
                            sqldr.Read()
                            urladdress.NavigateUrl = sqldr.Item("value").ToString()
                            urladdress1.NavigateUrl = urladdress.NavigateUrl
                        End If
                    End Using
                Catch ex As Exception
                    Utill.RegisterError(ex.Message, "MasterPage", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                End Try
            End Using
        End Using
    End Sub

End Class