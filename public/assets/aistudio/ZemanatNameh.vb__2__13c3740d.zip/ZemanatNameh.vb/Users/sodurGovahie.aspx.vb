﻿Imports System.Web.Services
Imports NumberToWordsLib
Imports System.Data.SqlClient
Public Class sodurGovahie
    Inherits System.Web.UI.Page
    Private Utill As New Utility
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim vahed As String = " ریال "
        Dim code As String = HttpContext.Current.User.Identity.Name
        utill.Is_User_Data_Correct(code)
        utill.Is_Govahie_Data_Correct(code)
        If utill.IsBlockedUser(code) Then
            Response.Redirect("./home", True)
        End If
        If Not Utill.AllowedToGetGovahie_For_User(code) Then
            Response.Redirect("./home", True)
        End If
        If Not Utill.ActiveUser(code) Then
            Response.Redirect("./home", True)
        End If

        Dim maxzemanat As Long = utill.Get_Khalesdaryafti_By_Code(Code:=code) * CType(utill.Get_Application_Settings(AppSettings.zarib.ToString), Long)
        Dim Sum_Of_Active_Govahies_And_Zemanatnameh As Long = utill.Get_Sum_Of_Active_Govahies_And_Zemanatnameh_By_Code(code)
        Dim mablaghmojaz As Long = maxzemanat - Sum_Of_Active_Govahies_And_Zemanatnameh
        lblmaxloan.Text = utill.En2Fa(mablaghmojaz.ToString("#,##0")) + " " + "(" + mablaghmojaz.NumberToText(Language.Persian) + " ) " + vahed

    End Sub

    Protected Sub btnContinue_Click(sender As Object, e As EventArgs) Handles btnContinue.Click
        Dim code As String = HttpContext.Current.User.Identity.Name
        Dim maxzemanat As Long = utill.Get_Khalesdaryafti_By_Code(Code:=code) * CType(utill.Get_Application_Settings(AppSettings.zarib.ToString), Long)
        Dim Sum_Of_Active_Govahies_And_Zemanatnameh As Long = utill.Get_Sum_Of_Active_Govahies_And_Zemanatnameh_By_Code(code)
        Dim mablaghmojaz As Long = maxzemanat - Sum_Of_Active_Govahies_And_Zemanatnameh
        Dim MablaghVam As Long = 0
        Dim blnerror As Boolean = False
        Try
            MablaghVam = CType(txtmablaghvam.Text.Replace(",", "").Trim, Long)
        Catch ex As Exception
            blnerror = True
        End Try
        If blnerror Then
            lblmsg.Text = "مبلغ وارد شده صحیح نیست"
            pnlmsg.Visible = True
            txtmablaghvam.Focus()
            Exit Sub
        Else
            lblmsg.Text = ""
            pnlmsg.Visible = False
        End If
        If MablaghVam > mablaghmojaz Then
            lblmsg.Text = "مبلغ وارد شده بیشتر از مبلغ مجاز شما است"
            pnlmsg.Visible = True
            txtmablaghvam.Focus()
            Exit Sub
        Else
            lblmsg.Text = ""
            pnlmsg.Visible = False
        End If
        If txtbankname.Text.Trim.Length > txtbankname.MaxLength Then
            txtbankname.Text = txtbankname.Text.Substring(0, txtbankname.MaxLength)
        End If

        If txtmablaghvam.Text.Trim.Length > txtmablaghvam.MaxLength Then
            txtmablaghvam.Text = txtmablaghvam.Text.Substring(0, txtmablaghvam.MaxLength)
        End If

        If txtbankname.Text.Trim.Length = 0 OrElse txtmablaghvam.Text.Replace(",", "").Trim.Length = 0 Then
            lblmsg.Text = "مقادیر وارد شده صحیح نیستند"
            pnlmsg.Visible = True
            txtbankname.Focus()
            Exit Sub
        Else
            lblmsg.Text = ""
            pnlmsg.Visible = False
        End If
        Dim rowid As String = ""
        If Not InsertNewRecord(rowid) Then
            lblmsg.Text = "در ثبت اطلاعات شما خطای رخ داده است لطفا دوباره سعی کنید"
            pnlmsg.Visible = True
            txtmablaghvam.Focus()
            Exit Sub
        Else
            lblmsg.Text = ""
            pnlmsg.Visible = False
        End If
        Session.Add("Typeid", 1)
        Session.Add("Rowid", rowid)

        Response.Redirect("./print", True)

    End Sub

    Private Function InsertNewRecord(ByRef rowid As String) As Boolean
        Dim ReturnValue As Boolean = False
        Dim code As String = HttpContext.Current.User.Identity.Name
        Dim insertstring As String = "INSERT INTO [Govahies] ([Shomareh], [code], [GovahiTypeID], [BankFullname], [LoanAmount], [MablaghKhalesDaryafti],[StateId],[Sader_Konandeh])" _
                & " VALUES (@Shomareh,@Code,@GovahiTypeID,@BankFullname,@LoanAmount,@MablaghKhalesDaryafti,/*StateId=*/ 1,@Sader_Konandeh)"
        Dim shomareh As Long = utill.Get_Latest_Shomareh() + 1
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(insertstring, connection)
                    command.CommandType = CommandType.Text
                    connection.Open()
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Shomareh", shomareh)
                    command.Parameters.AddWithValue("@Code", code)
                    command.Parameters.AddWithValue("@GovahiTypeID", 1)
                    command.Parameters.AddWithValue("@BankFullname", txtbankname.Text.Trim)
                    command.Parameters.AddWithValue("@LoanAmount", CType(txtmablaghvam.Text.Replace(",", "").Trim, Long))
                    command.Parameters.AddWithValue("@MablaghKhalesDaryafti", Utill.Get_Khalesdaryafti_By_Code(code))
                    command.Parameters.AddWithValue("@Sader_Konandeh", Utill.Get_Fullname_By_Code(code))
                    command.ExecuteNonQuery()
                End Using
            End Using
            ReturnValue = True
        Catch ex As Exception
            utill.RegisterError(ex.Message, "صدرو گواهی حقوقی - درج گواهی حقوقی", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            ReturnValue = False
        End Try
        If ReturnValue = True Then
            rowid = utill.Get_Last_Saved_RowID_By_Code(code)
            utill.Set_Shomareh(shomareh:=shomareh)
            utill.Set_RowValidationCode_For_Govaheis_Table_By_RowID(rowid)
            utill.Set_Number_Of_Active_Govahie_By_Code(code)
        End If
        Return ReturnValue
    End Function


    <WebMethod()>
    Public Shared Function GetBankname(bankname As String) As List(Of String)
        Dim listbankname As New List(Of String)()
        listbankname.Clear()
        ' bankname = bankname.Replace("ي", "ی")
        Dim sqlSelectstring As String = String.Format("Select [BankFullName] FROM [Banks] WHERE [BankFullName] Like N'%{0}%'", bankname)
        Try
            Dim utill As New Utility
            Using connection As New SqlConnection(Utill.Connectionstring)
                Using command As New SqlCommand(sqlSelectstring, connection)
                    command.CommandType = CommandType.Text
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        While reader.Read()
                            listbankname.Add(reader("Bankfullname").ToString)
                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception

        End Try
        Return listbankname
    End Function

End Class