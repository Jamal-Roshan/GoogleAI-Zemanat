﻿Imports System.Data.SqlClient
Imports System.Drawing
Imports System.IO
Imports NumberToWordsLib
Imports QRCoder
Imports Stimulsoft.Report
Public Class PrintGovahie
    Inherits System.Web.UI.Page
    Private utill As New Utility
    Private vahed As String = " ریال "
    Private Const signFilename = "\reports\blank.png"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim typeid As Integer = 0
        Dim rowid As Long = 0
        Dim code As String = HttpContext.Current.User.Identity.Name
        If Session("Typeid") Is Nothing OrElse Session("Rowid") Is Nothing Then
            Response.Redirect("./home", True)
        End If
        typeid = CType(Session("Typeid"), Integer)
        rowid = CType(Session("Rowid"), Long)
        If typeid = 0 OrElse rowid = 0 OrElse code.Length = 0 Then
            Response.Redirect("./home", True)
        End If

        Select Case typeid
            Case 1
                Me.Page.Title = "چاپ گواهی حقوقی"
                If Not preparingGovahie(typeid, rowid) Then
                    lblmessage.Text = "در عملیت چاپ گواهی حقوقی خطا رخ داده است.لطفا از قسمت مشاهده موارد صادر شده نسبت به چاپ دوباره اقدام نمایید."
                    pnlmsg2.Visible = False
                    Exit Sub
                End If

            Case 2
                Me.Page.Title = "چاپ ضمانت نامه بانکی"
                If Not preparingZemanatnameh(typeid, rowid) Then
                    lblmessage.Text = "در عملیت چاپ ضمانت نامه بانکی خطا رخ داده است.لطفا از قسمت مشاهده موارد صادر شده نسبت به چاپ دوباره اقدام نمایید."
                    pnlmsg2.Visible = False
                    Exit Sub
                End If
        End Select
        pnlmsg2.Visible = True
        lblmessage.Text = "کاربر گرامی" + "<br/>" + "این گواهی تنها با مهر و امضاء اداره معتبر خواهد بود.لذا بعد از چاپ  با در دست داشتن این گواهی و کارت شناسایی معتبر (کارت پرسنلی ، کارت ملی) شخصاً به امور مالی اداره مراجعه فرمایید."
    End Sub

    Private Function preparingGovahie(ByVal TypeId As Integer, ByVal RowID As Long) As Boolean
        Dim ReturnValue As Boolean = False
        Dim strSQLSelect As String = "SELECT Users_table.NationalID,  Users_table.Firstname,  Users_table.Lastname,  Users_table.Fathername,  Govahies.Shomareh, Users_table.WorkPlace, " _
                                & " Govahies.BankFullname, Govahies.LoanAmount,  Govahies.MablaghKhalesDaryafti,Govahies.DateOfCreate FROM  Users_table " _
                                & " INNER JOIN Govahies ON  Users_table.Code =  Govahies.Code  WHERE ((Govahies.[RowID]=@RowID) AND (Users_table.Code=@Code))"

        Dim code As String = HttpContext.Current.User.Identity.Name
        Dim NationalID As String = ""
        Dim Firstname As String = ""
        Dim Lastname As String = ""
        Dim Fathername As String = ""
        Dim Shomareh As String = ""
        Dim WorkPlace As String = ""
        Dim BankFullname As String = ""
        Dim LoanAmount As Long = 0
        Dim MablaghKhalesDaryafti As Long = 0
        Dim DateOfCreate As Date
        Dim MablaghvambeHoruf As String = ""
        Dim MablaghKhalesbehoruf As String = ""
        Dim orgtitle As String = utill.Get_Application_Settings(AppSettings.orgtitle.ToString).Trim
        Dim orgphone As String = " تلفن " & utill.Get_Application_Settings(AppSettings.orgphone.ToString).Trim
        Dim orgfax As String = " فکس " & utill.Get_Application_Settings(AppSettings.orgfax.ToString).Trim
        Dim orgaddress As String = utill.Get_Application_Settings(AppSettings.orgaddress.ToString).Trim
        Dim malicode As String = utill.Get_Application_Settings(AppSettings.malicode.ToString).Trim
        Dim signerpost As String = utill.Get_Application_Settings(AppSettings.signerpost.ToString).Trim
        Dim signername As String = utill.Get_Application_Settings(AppSettings.signername.ToString).Trim
        Dim title As String = ""
        Dim GenderPrefix As String = utill.Get_GenderID_Prefix_Title_By_GenderID(utill.Get_GenderId_By_Code(code), title).Trim
        Dim Eshteghal As String = utill.Get_EshteghalType_By_EshteghalID(utill.Get_EshteghalID_By_Code(code)).Trim
        Dim Estekhdam As String = utill.Get_EstekhdamType_By_EstekhdamID(utill.Get_EstekhdamID_By_Code(code))
        Dim Karmand As String = Estekhdam & " و " & Eshteghal
        orgaddress = orgaddress & " " & orgphone & " " & orgfax

        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using selectCommand As New SqlCommand(strSQLSelect, connection)
                    selectCommand.CommandType = CommandType.Text
                    selectCommand.Parameters.Clear()
                    selectCommand.Parameters.AddWithValue("@Code", code)
                    selectCommand.Parameters.AddWithValue("@RowID", RowID)
                    connection.Open()
                    Using sqldr As SqlDataReader = selectCommand.ExecuteReader()
                        If sqldr.HasRows Then
                            sqldr.Read()
                            NationalID = sqldr.Item("NationalID").ToString.Trim
                            Firstname = sqldr.Item("Firstname").ToString.Trim
                            Lastname = sqldr.Item("Lastname").ToString.Trim
                            Fathername = sqldr.Item("Fathername").ToString.Trim
                            Shomareh = sqldr.Item("Shomareh").ToString.Trim & "/" & malicode
                            WorkPlace = sqldr.Item("WorkPlace").ToString.Trim
                            BankFullname = sqldr.Item("BankFullname").ToString.Trim
                            LoanAmount = CType(sqldr.Item("LoanAmount"), Long)
                            MablaghKhalesDaryafti = CType(sqldr.Item("MablaghKhalesDaryafti"), Long)
                            DateOfCreate = CType(sqldr.Item("DateOfCreate"), Date)
                            MablaghKhalesbehoruf = MablaghKhalesDaryafti.NumberToText(Language.Persian) & vahed&
                            MablaghvambeHoruf = LoanAmount.NumberToText(Language.Persian) & vahed
                        End If
                    End Using
                End Using
            End Using

            Dim Etebar As String = utill.Get_PersianMonthName(utill.GetPersianMonth(DateOfCreate)) & " ماه " & " سال " & utill.En2Fa(utill.GetPersianYear(DateOfCreate))
            Dim Persian_Date As String = utill.GetPersianDate(DateOfCreate)
            Dim QRCode As String = "Code Meli:" + NationalID + " - " + "Code prs:" + code + " - " + Persian_Date + " - " + Shomareh + " - Vam= " + LoanAmount.ToString("#,##0") + " - Daryafti= " + MablaghKhalesDaryafti.ToString("#,##0")

            Dim serverlocation As String = HttpContext.Current.Server.MapPath(String.Empty)
            Dim myreport As New StiReport()
            myreport.Load(serverlocation + "\reports\govahie.mrt")
            myreport.Dictionary.Variables.Clear()

            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Code", utill.En2Fa(code)))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "NationalID", utill.En2Fa(NationalID)))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Fullname", Firstname & " " & Lastname))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Fathername", Fathername))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Shomareh", Shomareh))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "WorkPlace", WorkPlace))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "BankFullname", BankFullname))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "LoanAmount", utill.En2Fa(LoanAmount.ToString("#,##0"))))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "MablaghKhalesDaryafti", utill.En2Fa(MablaghKhalesDaryafti.ToString("#,##0"))))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "DateOfCreate", utill.En2Fa(Persian_Date)))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "MablaghvambeHoruf", MablaghvambeHoruf))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "MablaghKhalesbehoruf", MablaghKhalesbehoruf))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Orgtitle", orgtitle))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Orgaddress", orgaddress))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Signerpost", signerpost))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Signername", signername))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Etebar", Etebar))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "GenderPrefix", GenderPrefix))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Karmand", Karmand))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "QRCodeIImage", CreateQRCode(QRCode)))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "saderkonandeh", ""))
            If File.Exists(serverlocation & signFilename) Then
                myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Sign", Image.FromFile(serverlocation & signFilename)))
            End If



            myreport.Dictionary.Synchronize()
            myreport.Compile()
            myreport.Render(True)

            StiWebViewer1.Report = myreport

            'Stimulsoft.Report.Web.StiReportResponse.ResponseAsPdf(myreport,FALSE)
            ReturnValue = True
        Catch ex As Exception
            'Throw
            ReturnValue = False
        End Try
        Return ReturnValue
    End Function

    Private Function preparingZemanatnameh(ByVal TypeId As Integer, ByVal RowID As Long) As Boolean
        Dim ReturnValue As Boolean = False
        Dim strSQLSelect As String = "SELECT Users_table.NationalID,  Users_table.Firstname,  Users_table.Lastname,  Users_table.Fathername,  Govahies.Shomareh, Users_table.WorkPlace, " _
                                & " Govahies.BankFullname, Govahies.LoanAmount,  Govahies.MablaghKhalesDaryafti,  Govahies.LoanOwner_FirstName,  Govahies.LoanOwner_LastName," _
                                & " Govahies.LoanOwner_FatherName,Govahies.DateOfCreate FROM  Users_table INNER JOIN Govahies ON  Users_table.Code =  Govahies.Code " _
                                & " WHERE ((Govahies.[RowID]=@RowID) AND (Users_table.Code=@Code))"
        Dim code As String = HttpContext.Current.User.Identity.Name
        Dim NationalID As String = ""
        Dim Firstname As String = ""
        Dim Lastname As String = ""
        Dim Fathername As String = ""
        Dim Shomareh As String = ""
        Dim WorkPlace As String = ""
        Dim BankFullname As String = ""
        Dim LoanAmount As Long = 0
        Dim MablaghKhalesDaryafti As Long = 0
        Dim LoanOwner_FirstName As String = ""
        Dim LoanOwner_LastName As String = ""
        Dim LoanOwner_FatherName As String = ""
        Dim DateOfCreate As Date
        Dim MablaghvambeHoruf As String = ""
        Dim MablaghKhalesbehoruf As String = ""
        Dim orgtitle As String = utill.Get_Application_Settings(AppSettings.orgtitle.ToString).Trim
        Dim orgphone As String = " تلفن " & utill.Get_Application_Settings(AppSettings.orgphone.ToString).Trim
        Dim orgfax As String = " فکس " & utill.Get_Application_Settings(AppSettings.orgfax.ToString).Trim
        Dim orgaddress As String = utill.Get_Application_Settings(AppSettings.orgaddress.ToString).Trim
        Dim malicode As String = utill.Get_Application_Settings(AppSettings.malicode.ToString).Trim
        Dim signerpost As String = utill.Get_Application_Settings(AppSettings.signerpost.ToString).Trim
        Dim signername As String = utill.Get_Application_Settings(AppSettings.signername.ToString).Trim
        Dim title As String = ""
        Dim GenderPrefix As String = utill.Get_GenderID_Prefix_Title_By_GenderID(utill.Get_GenderId_By_Code(code), title).Trim
        Dim Eshteghal As String = utill.Get_EshteghalType_By_EshteghalID(utill.Get_EshteghalID_By_Code(code)).Trim
        Dim Estekhdam As String = utill.Get_EstekhdamType_By_EstekhdamID(utill.Get_EstekhdamID_By_Code(code))
        Dim Karmand As String = Estekhdam & " و " & Eshteghal
        orgaddress = orgaddress & " " & orgphone & " " & orgfax


        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using selectCommand As New SqlCommand(strSQLSelect, connection)
                    selectCommand.CommandType = CommandType.Text
                    selectCommand.Parameters.Clear()
                    selectCommand.Parameters.AddWithValue("@Code", code)
                    selectCommand.Parameters.AddWithValue("@RowID", RowID)
                    connection.Open()
                    Using sqldr As SqlDataReader = selectCommand.ExecuteReader()
                        If sqldr.HasRows Then
                            sqldr.Read()
                            NationalID = sqldr.Item("NationalID").ToString.Trim
                            Firstname = sqldr.Item("Firstname").ToString.Trim
                            Lastname = sqldr.Item("Lastname").ToString.Trim
                            Fathername = sqldr.Item("Fathername").ToString.Trim
                            Shomareh = sqldr.Item("Shomareh").ToString.Trim & "/" & malicode
                            WorkPlace = sqldr.Item("WorkPlace").ToString.Trim
                            BankFullname = sqldr.Item("BankFullname").ToString.Trim
                            LoanAmount = CType(sqldr.Item("LoanAmount"), Long)
                            MablaghKhalesDaryafti = CType(sqldr.Item("MablaghKhalesDaryafti"), Long)
                            LoanOwner_FirstName = sqldr.Item("LoanOwner_FirstName").ToString.Trim
                            LoanOwner_LastName = sqldr.Item("LoanOwner_LastName").ToString.Trim
                            LoanOwner_FatherName = sqldr.Item("LoanOwner_FatherName").ToString.Trim
                            DateOfCreate = CType(sqldr.Item("DateOfCreate"), Date)
                            MablaghKhalesbehoruf = MablaghKhalesDaryafti.NumberToText(Language.Persian) & vahed&
                            MablaghvambeHoruf = LoanAmount.NumberToText(Language.Persian) & vahed
                        End If
                    End Using
                End Using
            End Using

            Dim Etebar As String = utill.Get_PersianMonthName(utill.GetPersianMonth(DateOfCreate)) & " ماه " & " سال " & utill.En2Fa(utill.GetPersianYear(DateOfCreate))
            Dim Persian_Date As String = utill.GetPersianDate(DateOfCreate)
            Dim QRCode As String = "Code Meli:" + NationalID + " - " + "Code prs:" + code + " - " + Persian_Date + " - " + Shomareh + " - Vam= " + LoanAmount.ToString("#,##0") + " - Daryafti= " + MablaghKhalesDaryafti.ToString("#,##0")

            Dim serverlocation As String = HttpContext.Current.Server.MapPath(String.Empty)
            Dim myreport As New StiReport()
            myreport.Load(serverlocation + "\reports\Zemanatnameh.mrt")
            myreport.Dictionary.Variables.Clear()

            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Code", utill.En2Fa(code)))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "NationalID", utill.En2Fa(NationalID)))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Fullname", Firstname & " " & Lastname))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Fathername", Fathername))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Shomareh", Shomareh))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "WorkPlace", WorkPlace))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "BankFullname", BankFullname))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "LoanAmount", utill.En2Fa(LoanAmount.ToString("#,##0"))))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "MablaghKhalesDaryafti", utill.En2Fa(MablaghKhalesDaryafti.ToString("#,##0"))))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "DateOfCreate", utill.En2Fa(Persian_Date)))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "MablaghvambeHoruf", MablaghvambeHoruf))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "MablaghKhalesbehoruf", MablaghKhalesbehoruf))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Orgtitle", orgtitle))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Orgaddress", orgaddress))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Signerpost", signerpost))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Signername", signername))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Etebar", Etebar))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "GenderPrefix", GenderPrefix))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Karmand", Karmand))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "QRCodeIImage", CreateQRCode(QRCode)))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "saderkonandeh", ""))
            If File.Exists(serverlocation & signFilename) Then
                myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Sign", Image.FromFile(serverlocation & signFilename)))
            End If


            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "LoanOwner_Fullname", LoanOwner_FirstName & " " & LoanOwner_LastName))
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "LoanOwner_FatherName", LoanOwner_FatherName))


            myreport.Dictionary.Synchronize()
            myreport.Compile()
            myreport.Render(True)

            StiWebViewer1.Report = myreport
            ReturnValue = True
        Catch ex As Exception
            ' Throw
            ReturnValue = False
        End Try
        Return ReturnValue
    End Function
    Private Function CreateQRCode(ByVal InputCode As String) As System.Drawing.Image
        Using qr_Generator As New QRCodeGenerator()
            Using qr_CodeData As QRCodeData = qr_Generator.CreateQrCode(InputCode, QRCodeGenerator.ECCLevel.Q)
                Using qr_Code As QRCode = New QRCode(qr_CodeData)
                    Dim imgBarCode As New System.Web.UI.WebControls.Image()
                    imgBarCode.Height = 200
                    imgBarCode.Width = 200
                    Dim byteImage As Byte()
                    Using bitMap As Bitmap = qr_Code.GetGraphic(20)
                        Using ms As New MemoryStream()
                            bitMap.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                            byteImage = ms.ToArray()
                        End Using
                    End Using
                    Dim Memst As MemoryStream = New MemoryStream(byteImage)
                    Dim Image As System.Drawing.Image = System.Drawing.Image.FromStream(Memst)
                    Return Image
                End Using
            End Using
        End Using
    End Function
End Class