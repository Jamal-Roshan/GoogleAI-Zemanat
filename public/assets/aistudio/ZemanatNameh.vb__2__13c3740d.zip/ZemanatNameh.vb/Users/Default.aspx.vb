﻿
Public Class _Default3
    Inherits System.Web.UI.Page
    Private utill As New Utility

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim Code As String = HttpContext.Current.User.Identity.Name
        utill.Is_User_Data_Correct(Code)
        Dim vahed As String = " ریال "

        If Not utill.ActiveUser(Code) Then
            pnlmsg.Visible = True
            Dim msg As String = "<h4>" & "حساب کاربری شما جهت صدور ضمانت نامه و گواهی حقوقی غیر فعال شده است" & "</h4>"
            Dim res As String = "<h5>" & "دلیل غیر فعال شدن حساب کاربری شما: " & "<span  style=""color:blue"">" & "عدم دریافت حقوق و مزایا در ماه جاری" & "</span>" & "</h5>"
            Dim ret As String = "<h5>" & "جهت بررسی و برطرف کردن مشکل به واحد امور مالی اداره مراجعه نمایید" & "</h5>"
            litmsg.Text = msg & res & ret
            BasicInformation.Visible = False
            pnlgovahieinfo.Visible = False
            Return
        End If


        If utill.IsBlockedUser(Code) Then
            pnlmsg.Visible = True
            Dim msg As String = "<h4>" & "حساب کاربری شما جهت صدور ضمانت نامه و گواهی حقوقی مسدود شده است" & "</h4>"
            Dim res As String = "<h5>" & "دلیل مسدود شدن حساب کاربری شما: " & "<span  style=""color:blue"">" & utill.GetBlockResone(HttpContext.Current.User.Identity.Name) & "</span>" & "</h5>"
            Dim ret As String = "<h5>" & "جهت بررسی و برطرف کردن مشکل به واحد امور مالی اداره مراجعه نمایید" & "</h5>"
            litmsg.Text = msg & res & ret
            BasicInformation.Visible = False
            pnlgovahieinfo.Visible = False
            Return
        Else
            pnlmsg.Visible = False
            litmsg.Text = ""
        End If
        Dim maxzemanat As Long = utill.Get_Khalesdaryafti_By_Code(Code:=Code) * CType(utill.Get_Application_Settings(AppSettings.zarib.ToString), Long)
        utill.Get_Khalesdaryafti_By_Code(Code:=Code)
        Dim mincredit As Long = CType(utill.Get_Application_Settings(AppSettings.mincredit.ToString), Long)
        Dim Sum_Of_Active_Govahies_And_Zemanatnameh As Long = utill.Get_Sum_Of_Active_Govahies_And_Zemanatnameh_By_Code(Code)
        Dim khalesdaryafti As Long = utill.Get_Khalesdaryafti_By_Code(Code)
        Dim mablaghmojaz As Long = maxzemanat - Sum_Of_Active_Govahies_And_Zemanatnameh

        If mablaghmojaz <= 0 Then
            lblvaziyat.ForeColor = Drawing.Color.Red
            lblvaziyat.Text = "به علت دریافت حداکثر مبلغ ضمانت نامه شما مجاز به دریافت ضمانت نامه و گواهی حقوقی جدید نیستید"
        ElseIf khalesdaryafti < mincredit Then
            lblvaziyat.ForeColor = Drawing.Color.Red
            lblvaziyat.Text = "به علت اینکه مبلغ خالص دریافتی شما کمتر از حداقل تعیین شده است شمامجاز به دریافت ضمانت نامه و گواهی حقوقی جدید نیستید"
        Else
            lblvaziyat.ForeColor = Drawing.Color.Green
            lblvaziyat.Text = "شما می توانید گواهی حقوقی و یا ضمانت نامه تا مبلغ مجاز تعیین شده دریافت کنید "
        End If

        If mablaghmojaz <= 0 OrElse khalesdaryafti < mincredit Then
            mablaghmojaz = 0
        End If

        lblprstitle.Text = "اطلاعات پرسنلی شما در  " & utill.Get_PersianMonthName(utill.Get_CurrentMonth_By_Code(Code)) & " ماه " & " سال " & utill.En2Fa(utill.GetPersianYear(utill.Get_OperationDate_By_Code(Code)))
        lblfullname.Text = " " & utill.Get_Fullname_By_Code(Code)
        lblfather.Text = " " & utill.Get_Fathername_By_Code(Code)
        lblnid.Text = " " & utill.En2Fa(utill.Get_NationalID_By_Code(Code))
        lblcode.Text = " " & utill.En2Fa(Code)
        lblEstekhdam.Text = " " & utill.Get_EstekhdamType_By_EstekhdamID(utill.Get_EstekhdamID_By_Code(Code))
        lblEshteghal.Text = " " & utill.Get_EshteghalType_By_EshteghalID(utill.Get_EshteghalID_By_Code(Code))
        lblkhales.Text = " " & utill.En2Fa(khalesdaryafti.ToString("#,##0")) & vahed
        lblhesab.Text = " " & utill.En2Fa(utill.Get_AccountNumber_By_Code(Code))
        lblworkplace.Text = " " & utill.En2Fa(utill.Get_WorkPlace_By_Code(Code))

        lblnumberofactivezemanatnameh.Text = " " & utill.En2Fa(utill.Get_Number_Of_Active_Zemanatnameh_By_Code(Code).ToString("#,##0"))
        lblnumberofactivegovahies.Text = " " & utill.En2Fa(utill.Get_Number_Of_Active_Govahies_By_Code(Code).ToString("#,##0"))
        lbltotalnumberofzemanatandgovahie.Text = " " & utill.En2Fa((utill.Get_Number_Of_Active_Zemanatnameh_By_Code(Code) + utill.Get_Number_Of_Active_Govahies_By_Code(Code)).ToString("#,##0"))
        lblsumofactivezemanat.Text = " " & utill.En2Fa(utill.Get_Sum_Of_Active_Zemanatnameh_By_Code(Code).ToString("#,##0")) & vahed
        lblsumofactivegovahies.Text = " " & utill.En2Fa(utill.Get_Sum_Of_Active_Govahies_By_Code(Code).ToString("#,##0")) & vahed
        lblsumofactivezemanatandgovahies.Text = " " & utill.En2Fa(Sum_Of_Active_Govahies_And_Zemanatnameh.ToString("#,##0")) & vahed
        lblmaxzemanat.Text = " " & utill.En2Fa(maxzemanat.ToString("#,##0")) & vahed
        lblmincredit.Text = " " & utill.En2Fa(mincredit.ToString("#,##0")) & vahed

        lblmabkaghmojaz.Text = " " & utill.En2Fa(mablaghmojaz.ToString("#,##0")) & vahed


    End Sub

End Class