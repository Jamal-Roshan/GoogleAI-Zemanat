﻿<%@ Page Title="صفحه اصلی کاربر" Language="vb" AutoEventWireup="false" MasterPageFile="~/Users/MasterPage.Master" CodeBehind="Default.aspx.vb" Inherits="ZemanatNameh.vb._Default3" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style>
        .rowstyle {
            padding-top: 4px;
            padding-bottom: 4px;
        }
    </style>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class=" container">
        <div class="row panel-group" id="Dashbord" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">
            <asp:Panel ID="pnlmsg" runat="server" ForeColor="Red" BackColor="LightYellow" Font-Bold="true" Visible="false" CssClass=" text-center" Style="padding-top: 5px; padding-bottom: 5px">
                <asp:Literal Text="" ID="litmsg" runat="server" />
            </asp:Panel>
            <asp:Panel runat="server" ID="BasicInformation">
                <div class="panel  panel-primary  " style="font-size: 1.1em; font-weight: bold;">
                    <div class="panel-heading text-center">
                        <asp:Label Text="" ID="lblprstitle" runat="server" />
                    </div>

                    <div class="panel-body">
                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                            نام و نام خانوادگی:
                            <asp:Label Text="" ID="lblfullname" runat="server" ForeColor="Blue" />
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                            نام پدر:
                            <asp:Label Text="" ID="lblfather" runat="server" ForeColor="Blue" />
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                            شماره ملی:
                            <asp:Label Text="" ID="lblnid" runat="server" ForeColor="Blue" />
                        </div>


                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                            شماره پرسنلی:
                            <asp:Label Text="" ID="lblcode" runat="server" ForeColor="Blue" />
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                            نوع استخدام:
                            <asp:Label Text="" ID="lblEstekhdam" runat="server" ForeColor="Blue" />
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                            وضعیت اشتغال:
                            <asp:Label Text="" ID="lblEshteghal" runat="server" ForeColor="Blue" />
                        </div>

                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                            مبلغ خالص دریافتی:
                            <asp:Label Text="" ID="lblkhales" runat="server" ForeColor="Blue" />
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                            شماره حساب:
                            <asp:Label Text="" ID="lblhesab" runat="server" ForeColor="Blue" />
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                            نام محل کار:
                            <asp:Label Text="" ID="lblworkplace" runat="server" ForeColor="Blue" />
                        </div>

                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 rowstyle">
                            مبلغ مجاز شما برای دریافت ضمانت نامه یا گواهی حقوقی:
                            <asp:Label Text="" ID="lblmabkaghmojaz" runat="server" ForeColor="Red" />
                        </div>

                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  rowstyle">
                            وضعیت دریافت گواهی جدید: 
                            <asp:Label Text="" ID="lblvaziyat" runat="server" ForeColor="Blue" />
                        </div>


                    </div>
                </div>
            </asp:Panel>
            <asp:Panel runat="server" ID="pnlgovahieinfo" Style="font-size: 1.1em; font-weight: bold;">
                <div class="panel panel-primary  ">
                    <div class="panel-heading text-center">
                        اطلاعات گواهی حقوقی و ضمانت نامه های صادر شده
                    </div>
                    <div class="panel-body">

                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                            تعداد ضمانت نامه های فعال:
                            <asp:Label Text="" ID="lblnumberofactivezemanatnameh" runat="server" ForeColor="Blue" />
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                            تعداد گواهی حقوقی فعال:
                            <asp:Label Text="" ID="lblnumberofactivegovahies" runat="server" ForeColor="Blue" />
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                            مجموع:
                            <asp:Label Text="" ID="lbltotalnumberofzemanatandgovahie" runat="server" ForeColor="Blue" />
                        </div>


                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                            مجموع مبالغ ضمانت نامه های فعال:
                            <asp:Label Text="" ID="lblsumofactivezemanat" runat="server" ForeColor="Blue" />
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                            مجموع مبالغ گواهی حقوقی فعال:
                            <asp:Label Text="" ID="lblsumofactivegovahies" runat="server" ForeColor="Blue" />
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle ">
                            جمع کل(ضمانت نامه و گواهی حقوقی تسویه نشده):
                            <asp:Label Text="" ID="lblsumofactivezemanatandgovahies" runat="server" ForeColor="red" Font-Bold="true"/>
                        </div>

                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                            حداکثر مبلغ مجاز ضمانت:
                            <asp:Label Text="" ID="lblmaxzemanat" runat="server" ForeColor="Blue" />
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                            حداقل خالص دریافتی جهت صدور ضمانت:
                            <asp:Label Text="" ID="lblmincredit" runat="server" ForeColor="Blue" />
                        </div>


                    </div>
                </div>
            </asp:Panel>
        </div>
    </div>
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">
</asp:Content>
