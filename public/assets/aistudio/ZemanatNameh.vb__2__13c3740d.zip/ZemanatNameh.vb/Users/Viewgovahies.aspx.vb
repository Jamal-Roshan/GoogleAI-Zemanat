﻿Imports System.Data.SqlClient
Imports Telerik.Web.UI

Public Class Viewgovahies
    Inherits System.Web.UI.Page
    Public utill As New Utility
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Me.Page.IsPostBack Then
            bindgrid()
            If RadGrid1.MasterTableView.Items.Count = 0 Then
                pnlgrid.Visible = False
                btnExportToexcel.Visible = False
                'btnExportToPDF.Visible = False
                btnprint.Visible = False
            Else
                pnlgrid.Visible = True
                btnExportToexcel.Visible = True
                'btnExportToPDF.Visible = True
                btnprint.Visible = True
            End If
        End If

    End Sub

    Protected Sub RadGrid1_ItemDataBound(sender As Object, e As GridItemEventArgs) Handles RadGrid1.ItemDataBound
        If (TypeOf e.Item Is GridDataItem) Then
            ' AndAlso e.Item.OwnerTableView.DataSource = "Sqldr"
            Dim lbl As Label = CType(e.Item.FindControl("Grid_RowNumber_Label"), Label)
            lbl.Text = (((e.Item.OwnerTableView.CurrentPageIndex * e.Item.OwnerTableView.PageSize) + (e.Item.ItemIndex + 1)).ToString())
            Dim refChk As CheckBox = DirectCast(e.Item.FindControl("chkRowSelectCheckBox"), CheckBox)
            ClientScript.RegisterArrayDeclaration("chk_Array_IDs", String.Concat("'", refChk.ClientID, "'"))
        End If
    End Sub
    Protected Sub RadGrid1_ColumnsReorder(sender As Object, e As GridColumnsReorderEventArgs) Handles RadGrid1.ColumnsReorder
        bindgrid()
    End Sub
    Protected Sub RadGrid1_PageIndexChanged(sender As Object, e As GridPageChangedEventArgs) Handles RadGrid1.PageIndexChanged ', RadGrid2.PageIndexChanged
        bindgrid()
    End Sub
    Protected Sub RadGrid1_PageSizeChanged(sender As Object, e As GridPageSizeChangedEventArgs) Handles RadGrid1.PageSizeChanged ', RadGrid2.PageSizeChanged
        bindgrid()
    End Sub
    Protected Sub RadGrid1_SortCommand(sender As Object, e As GridSortCommandEventArgs) Handles RadGrid1.SortCommand
        bindgrid()
    End Sub

    Protected Function getcolor(typeid As Integer) As System.Drawing.Color
        Dim ret As System.Drawing.Color
        Select Case typeid
            Case 1
                ret = System.Drawing.Color.Red
            Case 2
                ret = System.Drawing.Color.Blue
            Case 3
                ret = System.Drawing.Color.Green
        End Select
        Return ret
    End Function
    Protected Sub bindgrid()
        Dim strselect As String = "SELECT Users_table.Code,(Govahies.RowID) AS RowID, Govahies.Shomareh,Govahies.GovahiTypeID, Govahies.BankFullname, Govahies.LoanAmount, Govahies.MablaghKhalesDaryafti," _
                                & " Govahies.LoanOwner_FirstName, Govahies.LoanOwner_LastName, Govahies.LoanOwner_FatherName, Govahies.StateId, Govahies.DateOfCreate" _
                                & " FROM Users_table INNER JOIN Govahies ON Users_table.Code = Govahies.Code INNER JOIN Genders ON Users_table.GenderId = Genders.Genders_ID" _
                                & " where Users_table.Code=@Code  ORDER BY Govahies.DateOfCreate DESC"

        Dim sum As Double = 0
        Dim totalRecord As Long = 0
        Dim TasviyehRecords As Long = 0
        Dim TotalActiveGovahiesAndZemanatnameh As Long = 0
        Dim NumberOfActiveZemanatnameh As Long = 0
        Dim NumberOfActiveGovahie As Long = 0
        Dim TotalActiveGovahie As Long = 0
        Dim TotalActiveZemanatnameh As Long = 0

        Using connection As New SqlConnection(utill.Connectionstring)
            Using command As New SqlCommand(strselect, connection)
                command.CommandType = CommandType.Text
                command.Parameters.Clear()
                command.Parameters.AddWithValue("@Code", HttpContext.Current.User.Identity.Name)
                Using sda As New SqlDataAdapter(command)
                    Dim dt As New DataTable()
                    Try
                        dt.Clear()
                        sda.Fill(dt)
                        RadGrid1.DataSource = dt
                        RadGrid1.DataBind()
                    Catch ex As Exception
                        dt.Clear()
                        Throw
                    End Try

                    Try
                        totalRecord = CType(dt.Compute("Count(Code)", ""), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        totalRecord = 0
                    End Try

                    Try
                        TasviyehRecords = CType(dt.Compute("Count(Code)", "StateId=3"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        TasviyehRecords = 0
                    End Try
                    Try
                        TotalActiveGovahiesAndZemanatnameh = CType(dt.Compute("Count(Code)", "StateId=1"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        TotalActiveGovahiesAndZemanatnameh = 0
                    End Try

                    Try
                        NumberOfActiveGovahie = CType(dt.Compute("Count(Code)", "StateId=1 AND GovahiTypeID=1"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        NumberOfActiveGovahie = 0
                    End Try
                    Try
                        NumberOfActiveZemanatnameh = CType(dt.Compute("Count(Code)", "StateId=1 AND GovahiTypeID=2"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        NumberOfActiveZemanatnameh = 0
                    End Try

                    Try
                        sum = CType(dt.Compute("sum(LoanAmount)", "StateId=1"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        sum = 0
                    End Try

                    Try
                        TotalActiveGovahie = CType(dt.Compute("sum(LoanAmount)", "StateId=1 AND GovahiTypeID=1"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        TotalActiveGovahie = 0
                    End Try

                    Try
                        TotalActiveZemanatnameh = CType(dt.Compute("sum(LoanAmount)", "StateId=1 AND GovahiTypeID=2"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        TotalActiveZemanatnameh = 0
                    End Try
                End Using
            End Using
        End Using

        If sum = 0 Then
            ImageButton_Print_List.Visible = False
        Else
            ImageButton_Print_List.Visible = True
        End If
        lblNumberOfActiveGovahie.Text = "تعداد گواهی حقوقی فعال:" & " " & NumberOfActiveGovahie.ToString
        lblNumberOfActiveZemanatnameh.Text = "تعداد ضمانت نامه فعال:" & " " & NumberOfActiveZemanatnameh.ToString
        lblactive.Text = "تعداد کل گواهی حقوقی و ضمانت نامه های فعال:" & " " & TotalActiveGovahiesAndZemanatnameh.ToString
        lblTasviyeh.Text = "تعداد گواهی حقوقی و ضمانت نامه های تسویه شده:" & " " & TasviyehRecords.ToString
        lbltotal.Text = "تعداد کل گواهی حقوقی و ضمانت نامه ثبت شده(فعال و تسویه شده):" & " " & totalRecord.ToString

    End Sub

    Protected Sub btnExportToexcel_Click(sender As Object, e As ImageClickEventArgs) Handles btnExportToexcel.Click
        If RadGrid1.MasterTableView.Items.Count = 0 Then
            Return
        End If
        RadGrid1.MasterTableView.GetColumn("chkRow").Visible = False
        bindgrid()
        RadGrid1.ExportSettings.Excel.Format = DirectCast([Enum].Parse(GetType(GridExcelExportFormat), "Xlsx"), GridExcelExportFormat)
        RadGrid1.ExportSettings.IgnorePaging = True
        RadGrid1.ExportSettings.ExportOnlyData = False
        RadGrid1.ExportSettings.OpenInNewWindow = True
        RadGrid1.ExportSettings.FileName = HttpContext.Current.User.Identity.Name
        RadGrid1.MasterTableView.ExportToExcel()
    End Sub

    Protected Sub btnprint_Click(sender As Object, e As ImageClickEventArgs) Handles btnprint.Click
        Dim RowID As String = ""
        Dim Typeid As String = ""
        Dim StateId As String = ""
        Dim DateOfCreate As Date

        For Each dataItem As GridDataItem In RadGrid1.SelectedItems
            RowID = dataItem.GetDataKeyValue("RowID").ToString
            Typeid = dataItem.GetDataKeyValue("GovahiTypeID").ToString ' dataItem("GovahiTypeID").Text.ToString()
            StateId = dataItem.GetDataKeyValue("StateId").ToString
            DateOfCreate = CType(dataItem.GetDataKeyValue("DateOfCreate"), Date)
        Next
        Dim intsudormonth As Integer = utill.GetPersianMonth(DateOfCreate)
        Dim intcurrentMonth As Integer = utill.GetPersianMonth(Today)

        If intcurrentMonth <> intsudormonth Then
            pnlmsg.Visible = True
            lblmessage.Text = "گواهی حقوقی و ضمانت نامه های که فعال (تسویه نشده) و تاریخ ثبت آنها در ماه جاری باشد قابلیت چاپ مجدد را دارند"
            Return
        End If

        If StateId.Trim = "2" OrElse StateId.Trim = "3" Then
            pnlmsg.Visible = True
            lblmessage.Text = "گواهی حقوقی و ضمانت نامه های که فعال (تسویه نشده) و تاریخ ثبت آنها در ماه جاری باشد قابلیت چاپ مجدد را دارند"
            Return
        Else
            pnlmsg.Visible = False
        End If
        If RowID.Trim = "" OrElse Typeid.Trim = "" OrElse StateId.Trim = "" Then
            Return
        End If

        Session.Add("Typeid", Typeid)
        Session.Add("Rowid", RowID)

        Response.Redirect("./print", True)
    End Sub

    Protected Sub ImageButton_Print_List_Click(sender As Object, e As ImageClickEventArgs) Handles ImageButton_Print_List.Click
        Response.Redirect("./printlist", True)
    End Sub
    'Protected Sub btnExportToPDF_Click(sender As Object, e As ImageClickEventArgs) Handles btnExportToPDF.Click
    '    If RadGrid1.MasterTableView.Items.Count = 0 Then
    '        Return
    '    End If
    '    RadGrid1.MasterTableView.GetColumn("chkRow").Visible = False
    '    bindgrid()

    '    RadGrid1.ExportSettings.IgnorePaging = True
    '    RadGrid1.ExportSettings.ExportOnlyData = False
    '    RadGrid1.ExportSettings.OpenInNewWindow = True
    '    RadGrid1.ExportSettings.FileName = HttpContext.Current.User.Identity.Name

    '    'RadGrid1.ExportSettings.Word.Format = Web.UI.GridWordExportFormat.Docx

    '    'RadGrid1.MasterTableView.ExportToWord()

    '    RadGrid1.MasterTableView.ExportToPdf()
    'End Sub






End Class