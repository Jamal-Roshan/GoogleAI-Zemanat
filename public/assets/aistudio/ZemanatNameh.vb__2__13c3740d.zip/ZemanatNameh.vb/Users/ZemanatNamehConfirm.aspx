﻿<%@ Page Title="تایید موارد ثبت ضمانت نامه" Language="vb" AutoEventWireup="false" MasterPageFile="~/home/MasterPage.Master" CodeBehind="ZemanatNamehConfirm.aspx.vb" Inherits="ZemanatNameh.vb.ZemanatNamehConfirm" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class=" container">
        <div class="row" id="Dashbord" style="direction: rtl; border: 1px solid lightgray; margin: 1px 6px 0px 6px; background-color: whitesmoke">
            <div class=" panel panel-primary" style="margin-bottom: 0px !important; padding-bottom: 0px !important;">
                <div class=" panel-heading">
                    <div class="panel-title text-center">
                        صدور ضمانت نامه بانکی
                    </div>
                </div>
                <div class="panel-body " style="margin: 0 auto; width: 70%">
                    
                    <div class="row myrow">
                        <div class="col-lg-3">
                            <label for="txtbankname">نام و شعبه بانک /موسسه مالی:</label>
                        </div>
                        <div class="col-lg-9">
                            <asp:TextBox runat="server" ID="txtbankname" MaxLength="230" ClientIDMode="Static" CssClass=" form-control"
                                required="required" autofocus="autofocus" red
                                oninvalid="InvalidMsg(this,'نام کامل بانک یا موسسه مالی را وارد کنید');"
                                oninput="nvalidMsg(this,'نام کامل بانک یا موسسه مالی را وارد کنید');" />
                        </div>
                    </div>
                    <div class="row myrow">
                        <div class="col-lg-3">
                            <label for="txtbankname">نام وام گیرنده:</label>
                        </div>
                        <div class="col-lg-9">
                            <asp:TextBox runat="server" ID="txtname" MaxLength="45" ClientIDMode="Static" CssClass=" form-control"
                                required="required" autofocus="autofocus"
                                oninvalid="InvalidMsg(this,'نام وام گیرنده را وارد کنید');"
                                oninput="nvalidMsg(this,'نام وام گیرنده را وارد کنید');" />
                        </div>
                    </div>
                    <div class="row myrow">
                        <div class="col-lg-3">
                            <label for="txtbankname">نام خانوادگی وام گیرنده:</label>
                        </div>
                        <div class="col-lg-9">
                            <asp:TextBox runat="server" ID="txtfamily" MaxLength="45" ClientIDMode="Static" CssClass=" form-control"
                                required="required" autofocus="autofocus"
                                oninvalid="InvalidMsg(this,'نام خانوادگی وام گیرنده را وارد کنید');"
                                oninput="nvalidMsg(this,'نام خانوادگی وام گیرنده را وارد کنید');" />
                        </div>
                    </div>
                    <div class="row myrow">
                        <div class="col-lg-3">
                            <label for="txtbankname">نام پدر وام گیرنده:</label>
                        </div>
                        <div class="col-lg-9">
                            <asp:TextBox runat="server" ID="txtpedar" MaxLength="45" ClientIDMode="Static" CssClass=" form-control"
                                required="required" autofocus="autofocus"
                                oninvalid="InvalidMsg(this,'نام پدر وام گیرنده را وارد کنید');"
                                oninput="nvalidMsg(this,'نام پدر وام گیرنده را وارد کنید');" />
                        </div>
                    </div>
                    <div class="row myrow">
                        <div class="col-lg-3">
                            <label for="txtbankname">مبلغ وام (ریال):</label>
                        </div>
                        <div class="col-lg-9">
                            <asp:TextBox runat="server" ID="txtmablaghvam" MaxLength="15" ClientIDMode="Static" CssClass=" form-control"
                                required="required" autofocus="autofocus"
                                oninvalid="InvalidMsg(this,'مبلغ وام را وارد کنید');"
                                oninput="nvalidMsg(this,'مبلغ وام را وارد کنید');"
                                onkeyup="javascript:this.value=Comma(this.value);"
                                onkeypress="return isNumber(event)"/>
                            حداکثر مبلغ مجاز شما جهت ضمانت نامه :
                            <asp:Label Text="" runat="server" ID="lblmaxloan" ForeColor="Blue" Font-Bold="true" />
                            
                        </div>
                    </div>

                </div>
                <div class=" panel-footer text-center">
                    <div class="row">
                        <div class="col-lg-6 text-center">
                            <asp:Button Text="ثبت و ادامه" runat="server" CssClass="btn btn-primary" ID="btnContinue" />
                        </div>
                        <div class="col-lg-6 text-center">
                            <input type="button" name="btnclear" value="فرم جدید " class="btn btn-primary" onclick="return clearform();" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">
</asp:Content>
