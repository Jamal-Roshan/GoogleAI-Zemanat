﻿<%@ Page Title="چاپ ضمانت نامه و گواهی حقوقی" Language="vb" AutoEventWireup="false" MasterPageFile="~/Users/MasterPage.Master" CodeBehind="PrintGovahie.aspx.vb" Inherits="ZemanatNameh.vb.PrintGovahie" %>

<%@ Register TagPrefix="sti" Namespace="Stimulsoft.Report.Web" Assembly="Stimulsoft.Report.Web, Version=2020.2.1.0, Culture=neutral, PublicKeyToken=ebe6666cba19647a" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style type="text/css">
        .stiJsViewerClearAllStyles {
            font-size: 10pt !important;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class=" container">
        <div class="row" id="Dashbord" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; padding-top: 8px; overflow: scroll">

            <asp:Panel runat="server" ID="pnlmsg" BackColor="LightYellow" Style="padding: 8px">
                <asp:Label Text="" ID="lblmessage" runat="server" ForeColor="Red" />



            </asp:Panel>
            <asp:Panel runat="server" ID="pnlmsg2" Style="padding: 8px" ForeColor="DarkGreen">
                <p>
                    در مرورگر Mozilla Firefox ممکن است چاپ گزارش با تاخیر انجام شود . برای چاپ بهتر، از
                مروگر
                <a href="https://www.google.com/chrome/browser/" target="_blank">Google Chrome </a>
                    یا مرورگر
                 <a href="http://www.opera.com/download/" target="_blank">Opera </a>
                    استفاده کنید.
                </p>
                همچنین شما می توانید از طریق دکمه ذخیره گزارش نسبت به ذخیره گزارش با قالب فایل PDF اقدام نمایید.
            </asp:Panel>

            <sti:StiWebViewer ID="StiWebViewer1" runat="server" PageAlignment="Center" ReportDisplayMode="Div" RightToLeft="True" ScrollbarsMode="False" ShowTooltipsHelp="False"
                ShowEmailDialog="False" ShowEmailExportDialog="False" ShowExportDialog="True" ShowExportToCsv="False" ShowExportToDbf="False" ShowExportToDif="False"
                ShowExportToDocument="False" ShowExportToExcel="False" ShowExportToExcel2007="False" ShowExportToExcelXml="False" ShowExportToHtml="False" ShowExportToHtml5="False"
                ShowExportToImageBmp="False" ShowExportToImageGif="False" ShowExportToImageJpeg="False" ShowExportToImageMetafile="False" ShowExportToImagePcx="False" ShowExportToImagePng="False"
                ShowExportToImageSvg="False" ShowExportToImageSvgz="False" ShowExportToImageTiff="False" ShowExportToMht="False" ShowExportToOpenDocumentCalc="False"
                ShowExportToOpenDocumentWriter="False" ShowExportToPowerPoint="False" ShowExportToRtf="False" ShowExportToSylk="False" ShowExportToText="False" ShowExportToWord2007="False"
                ShowExportToXml="False" ShowExportToXps="False" PrintDestination="Pdf" ShowAboutButton="False" ShowBookmarksButton="False" ShowEditorButton="False" ShowFindButton="False"
                ShowFirstPageButton="False" ShowLastPageButton="False" ShowNextPageButton="False" ShowParametersButton="False" ShowPreviousPageButton="False" ToolbarAlignment="Center"
                ToolbarFontFamily="tahoma" ShowTooltips="False" Zoom="100" DesignWindow="Blank" />

        </div>
    </div>
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">
</asp:Content>
