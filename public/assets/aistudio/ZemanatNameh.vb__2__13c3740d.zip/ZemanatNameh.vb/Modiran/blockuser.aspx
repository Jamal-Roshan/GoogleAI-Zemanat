﻿<%@ Page Title="مسدود کردن کاربر" Language="vb" AutoEventWireup="false" MasterPageFile="~/modiran/ModirMasterPage.Master" CodeBehind="blockuser.aspx.vb" Inherits="ZemanatNameh.vb.blockuser" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style type="text/css">
        .panel {
            margin-bottom: 10px;
            border-color: rgba(128, 120, 128, 0.53);
        }

        .panel-body {
            background-color: rgba(222, 217, 217, 0.5);
        }

        .RightAndLeftPadding {
            padding-right: 5px;
            padding-left: 5px;
        }
    </style>
    <script type="text/javascript">
        function InvalidMsg(textbox, msg) {

            if (textbox.value === '') {
                textbox.setCustomValidity(msg);
            }

            else {
                textbox.setCustomValidity('');
            }
            return true;
        }
        $(document).ready(function () {
            $('input[type="checkbox"]').click(function () {
                if ($(this).is(":checked")) {
                    //alert("checked");
                }
                else {
                    document.getElementById('<%= txtdalilmasdoodi.ClientID %>').value = "-";
                }
            });
        });
        function isNumber(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }
    </script>
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="MainContent" runat="Server">
    <div class=" container">
        <div class="row" id="main" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">
            <div style="margin: 0 auto; width: 80%">
                <div class="panel panel-primary">
                    <div class="panel-heading text-center" style="padding: 10px; margin: 0px">
                        <h1 style="font-size: 1.2em; padding: 0px; margin: 0px">مسدود کردن کاربر</h1>
                    </div>
                    <div class="panel-body" style="padding: 10px 20px 10px 20px">
                        <div class="panel-heading " style="padding: 10px; margin: 0px">
                            <div id="info" style="text-align: justify; direction: rtl; line-height: 3em; border: 1px solid lightblue; padding: 8px;">
                                در این صفحه شما می‌توانید امکان صدور گواهی حقوقی و ضمانت‌نامه را برای فرد خاصی مسدود و یا کاربر را از حالت مسدود بودن خارج نمایید. برای بررسی وضعیت فعلی کاربر با استفاده از شماره پرسنلی آن شخص را جستجو کنید.
                            </div>
                            <asp:Panel runat="server" Style="width: 90%; margin: 0 auto; padding: 0px 10px 0px 10px; margin-bottom: 5px; margin-top: 5px; line-height: 25px; background-color: LightYellow"
                                ID="pnlmsg" CssClass="text-center">
                                <asp:ValidationSummary ValidationGroup="first" runat="server" ForeColor="red" BackColor="LightYellow" />
                                <asp:RequiredFieldValidator ValidationGroup="first" SetFocusOnError="true" ErrorMessage="شماره پرسنلی را وارد کنید" Text="" ControlToValidate="txtcode" runat="server" ForeColor="Red" Display="none" />
                                <asp:Label Font-Bold="true" runat="server" Text="" ForeColor="Red" ID="lblmsg" Visible="false" />
                            </asp:Panel>
                        </div>
                        <div id="panelbody" style="width: 60%; margin: 0 auto" class="text-center">
                            <div class="row" style="">
                                <div class=" col-lg-8 col-md-8 col-sm-8 col-xs-8">
                                    <asp:TextBox runat="server" ID="txtcode" CssClass="form-control" placeholder="شماره پرسنلی"
                                        onfocus="document.getElementById('MainContent_lblmsg').style.display='none'" onkeypress="return isNumber(event)"  ValidationGroup="first" />
                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                                    <asp:Button Text="بررسی وضعیت" runat="server" CssClass="btn btn-primary" ID="btnsearch" ValidationGroup="first" />
                                </div>
                            </div>
                            <asp:Panel runat="server" ID="pnlstatus" Style="padding: 10px; margin-top: 8px;" Visible="false">
                                <div class="row" style="background-color: antiquewhite; padding: 5px; margin-top: 10px">
                                    <asp:Label Text="نام ونام خانوادگی:" runat="server" />
                                    <asp:Label ID="lblfullname" Text="" runat="server" />
                                    <br />
                                    <br />
                                    <asp:Label Text="وضعیت جاری فرد:" runat="server" />
                                    <asp:Label ID="lblvaziyat" Text="" runat="server" />
                                    <br />
                                    <br />
                                    <asp:CheckBox Text="&nbsp;&nbsp;مسدود" ID="chkblock" runat="server" />
                                    <br />
                                    <br />
                                    <label for="txtdalilmasdoodi">دلیل انسداد</label>
                                    <br />
                                    <asp:TextBox runat="server" ID="txtdalilmasdoodi" Text="" TextMode="MultiLine" Width="100%" CssClass="form-control" Height="100px" required="required"
                                        onfocus="document.getElementById('MainContent_lblmsg').style.display='none'"
                                        oninvalid="InvalidMsg(this,'در صورتیکه کاربر مسدود خواهد شد دلیل مسدود شدن را بنویسید و درغیر اینصورت یک - تایپ کنید');"
                                        oninput="InvalidMsg(this,'در صورتیکه کاربر مسدود خواهد شد دلیل مسدود شدن را بنویسید و درغیر اینصورت یک - تایپ کنید');" />
                                    <div style="padding-top: 10px; margin: 0 auto" class="text-center">
                                        <div class=" col-lg-6 col-md-6 col-sm-6 col-xs-6 text-center">
                                            <asp:Button Text="ثبت وضعیت" runat="server" ID="btnsabt" CssClass="btn btn-primary" Width="100px" />
                                        </div>
                                        <div class=" col-lg-6 col-md-6 col-sm-6 col-xs-6 text-center">
                                            <asp:Button Text="پاک کردن فرم" runat="server" ID="btnreset" CssClass="btn btn-primary" Width="100px" />
                                        </div>
                                    </div>
                                </div>
                            </asp:Panel>


                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

</asp:Content>
<asp:Content ID="Content4" ContentPlaceHolderID="EndOfPageContent" runat="Server">
</asp:Content>
