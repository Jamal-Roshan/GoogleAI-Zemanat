﻿<%@ Page Title="اصلاح مشخصات شناسنامه‌ای" Language="vb" AutoEventWireup="false" MasterPageFile="~/modiran/ModirMasterPage.Master" CodeBehind="aa.aspx.vb" Inherits="ZemanatNameh.vb.NameCorrection" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style type="text/css">
        .panel {
            margin-bottom: 10px;
            border-color: rgba(128, 120, 128, 0.53);
        }

        .panel-body {
            background-color: rgba(222, 217, 217, 0.5);
        }

        .RightAndLeftPadding {
            padding-right: 5px;
            padding-left: 5px;
        }
    </style>
    <%--<script type="text/javascript">
        function InvalidMsg(textbox, msg) {

            if (textbox.value === '') {
                textbox.setCustomValidity(msg);
            }

            else {
                textbox.setCustomValidity('');
            }
            return true;
        }
        $(document).ready(function () {
            $('input[type="checkbox"]').click(function () {
                if ($(this).is(":checked")) {
                    //alert("checked");
                }
                else {
                    document.getElementById('<%= txtdalilmasdoodi.ClientID %>').value = "-";
                }
            });
        });
        function isNumber(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }
    </script>--%>
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="MainContent" runat="Server">
    <div class=" container">
        <div class="row" id="main" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">
            <div style="margin: 0 auto; width: 80%">
                <div class="panel panel-primary">
                    <div class="panel-heading text-center" style="padding: 10px; margin: 0px">
                        <h1 style="font-size: 1.2em; padding: 0px; margin: 0px">اصلاح مشخصات شناسنامه‌ای افراد</h1>
                    </div>
                    <div class="panel-body" style="padding: 10px 20px 10px 20px">
                        <div class="panel-heading " style="padding: 10px; margin: 0px">
                            <div id="info" style="text-align: justify; direction: rtl; line-height: 3em; border: 1px solid lightblue; padding: 8px;">
                                در این صفحه شما می‌توانید مشخصات شناسنامه‌ای افراد از جمله نام ، نام خانوادگی و نام پدر را اصلاح نماييد. با استفاده از شماره پرسنلی آن شخص را جستجو کنید.
                            </div>
                            <asp:Panel runat="server" Style="width: 90%; margin: 0 auto; padding: 0px 10px 0px 10px; margin-bottom: 5px; margin-top: 5px; line-height: 25px; background-color: LightYellow"
                                ID="pnlmsg" CssClass="text-center">
                                <asp:ValidationSummary ValidationGroup="first" runat="server" ForeColor="red" BackColor="LightYellow" />
                                <asp:RequiredFieldValidator ValidationGroup="first" SetFocusOnError="true" ErrorMessage="شماره پرسنلی را وارد کنید" Text="" ControlToValidate="txtcode" runat="server" ForeColor="Red" Display="none" />
                                <asp:Label Font-Bold="true" runat="server" Text="" ForeColor="Red" ID="lblmsg" Visible="false" />
                            </asp:Panel>
                        </div>
                        <div id="panelbody" style="width: 60%; margin: 0 auto" class="text-center">
                            <div class="row" style="">
                                <div class=" col-lg-8 col-md-8 col-sm-8 col-xs-8">
                                    <asp:TextBox runat="server" ID="txtcode" CssClass="form-control" placeholder="شماره پرسنلی"
                                        onfocus="document.getElementById('MainContent_lblmsg').style.display='none'" onkeypress="return isNumber(event)"  ValidationGroup="first" />
                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                                    <asp:Button Text="جستجو" runat="server" CssClass="btn btn-primary" ID="btnsearch" ValidationGroup="first" />
                                </div>
                            </div>
                            <asp:Panel runat="server" ID="pnlstatus" Style="padding: 10px; margin-top: 8px;" Visible="false" Width="457px">
                                <div class="row" style="background-color: antiquewhite; padding: 5px; margin-top: 10px">
                                    <asp:Label Text="نام : " runat="server" />
                                    <asp:TextBox ID="txtfirstname" runat="server" ValidationGroup="myform" CssClass="form-control" Height="35px" onfocus="document.getElementById('MainContent_lblmsg').style.display='none'" placeholder="نام" Width="423px" />
                                    <asp:RequiredFieldValidator runat="server" ControlToValidate="txtfirstname" ForeColor="red" ValidationGroup="myform">نام را وارد كنيد</asp:RequiredFieldValidator>
                                    <br />
                                    <asp:Label ID="Label1" runat="server" Text="نام خانوادگی:" />
                                    <asp:TextBox ID="txtlastname" runat="server" ValidationGroup="myform" CssClass="form-control" Height="35px" onfocus="document.getElementById('MainContent_lblmsg').style.display='none'" placeholder="نام" Width="423px" />
                                    <asp:RequiredFieldValidator runat="server" ControlToValidate="txtlastname" ForeColor="red" ValidationGroup="myform">نام خانوادگي را وارد كنيد</asp:RequiredFieldValidator>
                                    <br />
                                    <asp:Label Text="نام پدر:" runat="server" />
                                    <asp:TextBox ID="txtfathername" runat="server"  ValidationGroup="myform" CssClass="form-control" Height="35px" onfocus="document.getElementById('MainContent_lblmsg').style.display='none'" placeholder="نام" Width="423px" />
                                    <asp:RequiredFieldValidator runat="server" ControlToValidate="txtfathername" ForeColor="red" ValidationGroup="myform">نام پدر را وارد كنيد</asp:RequiredFieldValidator>
                                    <br />
                                    <br />
                                    <div style="padding-top: 10px; margin: 0 auto" class="text-center">
                                        <div class=" col-lg-6 col-md-6 col-sm-6 col-xs-6 text-center">
                                            <asp:Button Text="ثبت " runat="server" ID="btnsabt" CssClass="btn btn-primary" Width="100px" ValidationGroup="myform" />
                                        </div>
                                        <div class=" col-lg-6 col-md-6 col-sm-6 col-xs-6 text-center">
                                            <asp:Button Text="پاک کردن فرم" runat="server" ID="btnreset" CssClass="btn btn-primary" Width="100px" />
                                        </div>
                                    </div>
                                </div>
                            </asp:Panel>


                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

</asp:Content>
<asp:Content ID="Content4" ContentPlaceHolderID="EndOfPageContent" runat="Server">
</asp:Content>
