﻿<%@ Page Title="مشاهده استعلام های صادر شده" Language="vb" AutoEventWireup="false" MasterPageFile="~/modiran/ModirMasterPage.Master" CodeBehind="viewEstelamha.aspx.vb" Inherits="ZemanatNameh.vb.viewEstelamha" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <script type="text/javascript">
        function isNumber(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }
        //////////////////////////////////////////////
        function confirmDelete() {
            var xCounter = 0;
            if (chk_Array_IDs !== null) {

                for (i = 0; i < chk_Array_IDs.length; i++) {
                    var ref_chk = document.getElementById(chk_Array_IDs[i]);
                    if (ref_chk !== null)
                        if (ref_chk.checked === true)
                            ++xCounter;
                }
                if (xCounter === 0) {
                    alert("یک گواهی حقوقی و یا ضمانت نامه را انتخاب کنید");
                    return false;
                }
                else {
                    var ret_confirm = confirm("آیا مایل هستید تا برگه استعلام برای سطر انتخاب شده چاپ شود");
                    if (ret_confirm === true) {
                        checkclick = "true";
                        return true;
                    }
                    else
                        return false;
                }
            }
        }
        ////////////////////////////////////////////// 
    </script>
    <script type="text/javascript">
        function InvalidMsg(textbox, msg) {

            if (textbox.value === '') {
                textbox.setCustomValidity(msg);
            }

            else {
                textbox.setCustomValidity('');
            }
            return true;
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">


    <div class=" container">
        <div class="row" id="Dashbord" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">
            <asp:Panel runat="server" ID="pnlsearch" DefaultButton="btnfilter">
                <div class="panel panel-info" style="margin-bottom: 0px; padding-bottom: 0px">
                    <div class="panel-heading text-center">
                        <h5>صدور استعلام</h5>
                        جستجو براساس شماره پرسنلی یا شماره ملی
                    </div>
                    <div class="panel-body" style="margin-bottom: 0px; padding-bottom: 10px">
                        <div class="row">
                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2  ">
                                <asp:TextBox ID="txtcode" runat="server" CssClass="form-control" placeholder="شماره پرسنلی" Style="margin-bottom: 3px"
                                    onkeydown="document.getElementById('MainContent_txtnid').value=''"
                                    onkeypress="return isNumber(event)" />
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
                                <asp:TextBox ID="txtnid" runat="server" CssClass="form-control" placeholder="شماره ملی" Style="margin-bottom: 3px"
                                    onkeydown="document.getElementById('MainContent_txtcode').value=''"
                                    onkeypress="return isNumber(event)" />
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2  ">
                                <asp:Button ID="btnfilter" Text="  &nbsp;  &nbsp;جستجو  &nbsp;  &nbsp;" runat="server" CssClass="btn btn-info" formnovalidate="formnovalidate" />
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2  ">
                                <asp:Button ID="btnclearfilter" Text="حذف فیلتر" runat="server" CssClass="btn btn-info" Style="margin-right: 10px;" formnovalidate="formnovalidate" />
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3  ">
                                <asp:Button ID="btnestelam" Text="  &nbsp; &nbsp;  &nbsp;صدور استعلام  &nbsp;  &nbsp; &nbsp;" runat="server" CssClass="btn btn-info" Style="margin-right: 10px;" Enabled="false" Visible="false"
                                    OnClientClick="return confirmDelete();" />
                            </div>
                            <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 ">
                                <asp:ImageButton ImageUrl="Images/other/excel.png" ID="btnExportToexcel" runat="server" ToolTip="ارسال به فایل اکسل" Height="35px" Visible="false" CausesValidation="false" formnovalidate="formnovalidate" />
                            </div>
                        </div>
                        <asp:Panel runat="server" ID="pnlinfo" Visible="false">
                            <div class="row">
                                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-4">
                                    نام و نام خانوادگی:
                                 <asp:Label runat="server" ID="lblfullname" ForeColor="Blue" Text=""></asp:Label>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-4">
                                    نام پدر:
                                 <asp:Label runat="server" ID="lblfather" ForeColor="Blue" Text=""></asp:Label>
                                </div>
                            </div>
                        </asp:Panel>
                    </div>
                    <asp:Panel runat="server" ID="pnlmsg" BackColor="LightYellow" Style="padding: 8px" Visible="false" CssClass=" text-center">
                        <asp:Label Text="موردی با مشخصات وارد شده موجود نیست" ID="lblmessage" runat="server" ForeColor="Red" />
                    </asp:Panel>
                </div>
            </asp:Panel>

            <asp:Panel ID="pnlgrid" runat="server" CssClass="panel-body" Style="padding: 5px">
                <telerik:RadGrid ID="RadGrid1" runat="server" AllowPaging="True" CssClass="table-responsive" AllowSorting="True" AutoGenerateColumns="False" PageSize="50"
                    BorderStyle="Solid" Skin="Outlook" Font-Names="yekan" class="table-responsive">
                    <GroupingSettings CollapseAllTooltip="Collapse all groups"></GroupingSettings>
                    <ClientSettings EnableRowHoverStyle="true" EnableAlternatingItems="true" Selecting-AllowRowSelect="true">
                        <Selecting AllowRowSelect="True" />
                    </ClientSettings>
                    <GroupingSettings GroupContinuedFormatString="... ادامه گروه از صفحه قبل" GroupContinuesFormatString="ادامه گروه در صفحه بعد"
                        UnGroupButtonTooltip="برای لغو گروه بندی اینجا کلیک کنید" UnGroupTooltip="برای لغو گروه بندی گروه مورد نظر رابا ماوس از اینجا به بیرون بکشید" />
                    <GroupHeaderItemStyle Font-Bold="true" Font-Names="tahoma,arial" Font-Size="11px" />
                    <GroupPanel Font-Bold="true" Font-Names="tahoma,arial" Font-Size="11px" Font-Strikeout="False"
                        Text="برای گروه بندی بر اساس نام خانوادگی و نام بانک  عنوان ستون مورد نظر را کشیده و در اینجا رها کنید"
                        Width="100%">
                        <PanelStyle Font-Bold="true" Font-Names="tahoma,arial" Font-Size="11px" Height="35px"
                            HorizontalAlign="Center" Width="100%" />
                        <PanelItemsStyle Font-Bold="true" Font-Names="tahoma,arial" Font-Size="11px" HorizontalAlign="Center" />
                    </GroupPanel>
                    <MasterTableView CssClass="table-responsive" DataKeyNames="RowID">
                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                            <HeaderStyle Font-Bold="true" Width="20px" />
                        </RowIndicatorColumn>
                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                            <HeaderStyle Font-Bold="true" Width="20px" />
                        </ExpandCollapseColumn>
                        <EditFormSettings>
                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                            </EditColumn>
                        </EditFormSettings>
                        <Columns>

                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="False" HeaderText="ردیف" ReadOnly="True" UniqueName="radif" AllowSorting="true">
                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Width="10px" Font-Names="yekan" VerticalAlign="Middle" />
                                <ItemTemplate>
                                    <asp:Label ID="Grid_RowNumber_Label" runat="server" />
                                </ItemTemplate>
                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="40px" />
                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="Center" Width="10px" Font-Names="yekan" VerticalAlign="Middle" />
                            </telerik:GridTemplateColumn>



                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="شماره گواهی" ReadOnly="True" DataField="Shomareh" UniqueName="Shomareh" AllowSorting="true" SortExpression="Shomareh">
                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                <ItemTemplate>
                                    <asp:Label ID="lblshomarehgovahei" runat="server" Text='<%# (Eval("Shomareh")) %>'></asp:Label>
                                </ItemTemplate>
                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="60px" />
                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="center" Font-Names="yekan" VerticalAlign="Middle" />
                            </telerik:GridTemplateColumn>

                            <telerik:GridBoundColumn Visible="false" DataField="Firstname" FilterControlAltText="Filter firstname column" HeaderText="نام" ReadOnly="True" UniqueName="firstname" Groupable="false" AllowSorting="true">
                                <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="80px" Font-Bold="true" />
                                <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                            </telerik:GridBoundColumn>

                            <telerik:GridBoundColumn Visible="false" DataField="Lastname" FilterControlAltText="Filter lastname column" HeaderText="نام خانوادگی" ReadOnly="True" UniqueName="lastname" Groupable="true" AllowSorting="true">
                                <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="100px" Font-Bold="true" />
                                <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                            </telerik:GridBoundColumn>

                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="نوع گواهی" ReadOnly="True" DataType="System.Int16"
                                DataField="GovahiTypeID" UniqueName="GovahiTypeID" AllowSorting="true" SortExpression="GovahiTypeID">
                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                <ItemTemplate>
                                    <asp:Label runat="server" Text='<%# utill.GetGovahiType(Eval("GovahiTypeID")) %>'></asp:Label>
                                </ItemTemplate>
                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="70px" />
                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="right" Font-Names="yekan" VerticalAlign="Middle" />
                            </telerik:GridTemplateColumn>

                            <telerik:GridBoundColumn DataField="BankFullname" HeaderText="نام بانک" ReadOnly="True" UniqueName="BankFullname" Groupable="true" AllowSorting="true" AllowFiltering="False">
                                <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="150px" Font-Bold="true" />
                                <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                            </telerik:GridBoundColumn>

                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="مبلغ ضمانت" ReadOnly="True" DataField="LoanAmount"
                                UniqueName="LoanAmount" AllowSorting="true" SortExpression="LoanAmount">
                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                <ItemTemplate>
                                    <asp:Label ID="lblLoanAmount" runat="server" Text='<%# (DataBinder.Eval(Container.DataItem, "LoanAmount", "{0:##,###}"))%>'></asp:Label>
                                </ItemTemplate>
                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="70px" />
                                <ItemStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" HorizontalAlign="left" Font-Names="yekan" VerticalAlign="Middle" />
                            </telerik:GridTemplateColumn>

                            <telerik:GridBoundColumn DataField="LoanOwner_FirstName" HeaderText="نام وام گیرنده" ReadOnly="True" UniqueName="LoanOwner_FirstName" Groupable="false" AllowSorting="true" AllowFiltering="False">
                                <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="70px" Font-Bold="true" />
                                <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                            </telerik:GridBoundColumn>

                            <telerik:GridBoundColumn DataField="LoanOwner_LastName" HeaderText="نام خانوادگی وام گیرنده" ReadOnly="True" UniqueName="LoanOwner_LastName" Groupable="false" AllowSorting="true" AllowFiltering="False">
                                <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="80px" Font-Bold="true" />
                                <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                            </telerik:GridBoundColumn>
                            <telerik:GridBoundColumn DataField="LoanOwner_FatherName" HeaderText="نام پدر وام گیرنده" ReadOnly="True" UniqueName="LoanOwner_FatherName" Groupable="false" AllowSorting="true" AllowFiltering="False">
                                <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="70px" Font-Bold="true" />
                                <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                            </telerik:GridBoundColumn>

                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="وضعیت گواهی" ReadOnly="True" DataField="StateId" UniqueName="StateId" AllowSorting="true" SortExpression="StateId">
                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                <ItemTemplate>
                                    <asp:Label runat="server" Text='<%# utill.GetGovahiStatus(Eval("StateId")) %>' ForeColor='<%# getcolor(Eval("StateId")) %>'></asp:Label>
                                </ItemTemplate>
                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="60px" />
                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="center" Font-Names="yekan" VerticalAlign="Middle" />
                            </telerik:GridTemplateColumn>

                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="تاریخ تبت" ReadOnly="True" DataField="DateOfCreate" UniqueName="DateOfCreate" AllowSorting="true" SortExpression="DateOfCreate">
                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                <ItemTemplate>
                                    <asp:Label ID="lblDateOfCreate" runat="server" Text='<%# utill.En2Fa(utill.DateToString(Eval("DateOfCreate"))) %>'></asp:Label>
                                </ItemTemplate>
                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="70px" />
                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="center" Font-Names="yekan" VerticalAlign="Middle" />
                            </telerik:GridTemplateColumn>

                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="شماره نامه بانک" ReadOnly="True" DataField="Shomareh_Nameh_Estelam_Bank" UniqueName="Shomareh_Nameh_Estelam_Bank" AllowSorting="true" SortExpression="Shomareh_Nameh_Estelam_Bank">
                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                <ItemTemplate>
                                    <asp:Label ID="lblShomareh_Nameh_Estelam_Bank" runat="server" Text='<%# utill.En2Fa(Eval("Shomareh_Nameh_Estelam_Bank")) %>'></asp:Label>
                                </ItemTemplate>
                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="120px" />
                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="center" Font-Names="yekan" VerticalAlign="Middle" />
                            </telerik:GridTemplateColumn>

                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="تاریخ نامه بانک" ReadOnly="True" DataField="Tarikh_Nameh_Estelam_Bank" UniqueName="Tarikh_Nameh_Estelam_Bank" AllowSorting="true" SortExpression="Tarikh_Nameh_Estelam_Bank">
                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                <ItemTemplate>
                                    <asp:Label ID="lblTarikh_Nameh_Estelam_Bank" runat="server" Text='<%# utill.En2Fa(Eval("Tarikh_Nameh_Estelam_Bank")) %>'></asp:Label>
                                </ItemTemplate>
                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="80px" />
                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="center" Font-Names="yekan" VerticalAlign="Middle" />
                            </telerik:GridTemplateColumn>

                            <telerik:GridBoundColumn DataField="Sader_Konnandeh_Estelam" HeaderText="صادرکننده استعلام" ReadOnly="True" UniqueName="Sader_Konnandeh_Estelam" Groupable="false" AllowSorting="true" AllowFiltering="False">
                                <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="80px" Font-Bold="true" />
                                <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                            </telerik:GridBoundColumn>

                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="تاریخ صدور استعلام" ReadOnly="True" DataField="Tarikh_Sodur_Estelam" UniqueName="Tarikh_Sodur_Estelam" AllowSorting="true" SortExpression="Tarikh_Sodur_Estelam">
                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                <ItemTemplate>
                                    <asp:Label ID="lblTarikh_Sodur_Estelam" runat="server" Text='<%# utill.En2Fa(utill.DateToString(Eval("Tarikh_Sodur_Estelam"))) %>'></asp:Label>
                                </ItemTemplate>
                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="80px" />
                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="center" Font-Names="yekan" VerticalAlign="Middle" />
                            </telerik:GridTemplateColumn>

                        </Columns>
                    </MasterTableView>
                    <PagerStyle FirstPageToolTip="اولین صفحه"
                        Font-Strikeout="False" HorizontalAlign="Center" LastPageToolTip="آخرین صفحه"
                        NextPagesToolTip="صفحه بعد" NextPageToolTip="صفحه بعد" PageSizeLabelText="تعداد سطر های هر صفحه:"
                        PrevPagesToolTip="صفحه قبل" PrevPageToolTip="صفحه قبل" />
                    <FilterMenu EnableImageSprites="False">
                    </FilterMenu>
                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                    </HeaderContextMenu>
                </telerik:RadGrid>
                <div class="row" style="padding-bottom: 5px; padding-top: 5px;">
                    <div class="col-lg-4 text-center">
                        <asp:Label Text="" ID="lblactive" runat="server" ForeColor="DarkBlue" />
                    </div>

                </div>

            </asp:Panel>
        </div>
    </div>
       
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">
    <script>
        String.prototype.toPersianDigit = function (a) {
            return this.replace(/\d+/g, function (digit) {
                var enDigitArr = [], peDigitArr = [];
                for (var i = 0; i < digit.length; i++) {
                    enDigitArr.push(digit.charCodeAt(i));
                }
                for (var j = 0; j < enDigitArr.length; j++) {
                    peDigitArr.push(String.fromCharCode(enDigitArr[j] + ((!!a && a === true) ? 1584 : 1728)));
                }
                return peDigitArr.join('');
            });
        };

        function TraceNodes(Node) {
            if (Node.nodeType === 3 && Node.parentNode.localName !== "style" && Node.parentNode.localName !== "script")  //TextNode
                Node.nodeValue = Node.nodeValue.toPersianDigit();
            else
                for (var i = 0; i < Node.childNodes.length; i++)
                    TraceNodes(Node.childNodes[i]);
        }

        TraceNodes(document);
    </script>
</asp:Content>

