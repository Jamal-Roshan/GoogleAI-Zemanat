﻿<%@ Page Title="صدور گواهی حقوقی و ضمانت نامه جدید" Language="vb" AutoEventWireup="false" MasterPageFile="~/Modiran/ModirMasterPage.Master" CodeBehind="Newgovahie.aspx.vb" Inherits="ZemanatNameh.vb.newgovahie" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">


    <link href="Content/jquery-ui.css" rel="stylesheet" />
   

    <style type="text/css">
        .ui-corner-all {
            font-family: Yekan;
        }

        .myrow {
            padding-bottom: 5px !important;
            padding-top: 8px !important;
            background-color: lightgray;
            margin-bottom: 5px;
            vertical-align: middle;
        }

        .ui-autocomplete {
            height: 350px;
            overflow: scroll;
        }
    </style>

    <script type="text/javascript">
        $(function () {
            $("#zemtxtbankname").autocomplete({
                source: function (request, response) {
                    var param = { bankname: $('#zemtxtbankname').val() };
                    $.ajax({

                        url: "./modiran/Newgovahie.aspx/GetBankname",
                        data: JSON.stringify(param),
                        dataType: "json",
                        type: "POST",
                        contentType: "application/json; charset=utf-8",
                        dataFilter: function (data) { return data; },
                        success: function (data) {
                            response($.map(data.d, function (item) {
                                return {
                                    value: item
                                }
                            }))
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            var err = eval("(" + XMLHttpRequest.responseText + ")");
                            alert(err.Message)
                            // console.log("Ajax Error!");  
                        }
                    });
                },
                minLength: 2 //This is the Char length of inputTextBox  
            });
        });

        $(function () {
            $("#govtxtbankname").autocomplete({
                source: function (request, response) {
                    var param = { bankname: $('#govtxtbankname').val() };
                    $.ajax({

                        url: "./modiran/Newgovahie.aspx/GetBankname",
                        data: JSON.stringify(param),
                        dataType: "json",
                        type: "POST",
                        contentType: "application/json; charset=utf-8",
                        dataFilter: function (data) { return data; },
                        success: function (data) {
                            response($.map(data.d, function (item) {
                                return {
                                    value: item
                                }
                            }))
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            var err = eval("(" + XMLHttpRequest.responseText + ")");
                            alert(err.Message)
                            // console.log("Ajax Error!");  
                        }
                    });
                },
                minLength: 2 //This is the Char length of inputTextBox  
            });
        });

        $(function () {
            $("#zemtxtbankname, #zemtxtfirstname,#zemtxtlastname,#zemtxtfathername,#govtxtbankname").farsiInput();
        });
        function isNumber(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }

        function InvalidMsg(textbox, msg) {
            if (textbox.value === '') {
                textbox.setCustomValidity(msg);
            }
            else {
                textbox.setCustomValidity('');
            }
            return true;
        }

        function zemclearform() {
            $('#zemtxtbankname').val('');
            $('#zemtxtfirstname').val('');
            $('#zemtxtlastname').val('');
            $('#zemtxtfathername').val('');
            $('#zemtxtmablaghvam').val('');
            $('#zemsummary').empty();
            $('#zemtxtbankname').focus();
            document.getElementById('zemmablaghfarsiRial').innerHTML = '';
            document.getElementById('zemmablaghfarsiToman').innerHTML = '';
        }

        function govclearform() {
            $('#govtxtbankname').val('');
            $('#govtxtmablaghvam').val('');
            $('#govsummary').empty();
            $('#govtxtbankname').focus();
            document.getElementById('govmablaghfarsiRial').innerHTML = '';
            document.getElementById('govmablaghfarsiToman').innerHTML = '';
        }
        function Comma(Num) {
            Num += '';
            Num = Num.replace(',', ''); Num = Num.replace(',', ''); Num = Num.replace(',', '');
            Num = Num.replace(',', ''); Num = Num.replace(',', ''); Num = Num.replace(',', '');
            x = Num.split('.');
            x1 = x[0];
            x2 = x.length > 1 ? '.' + x[1] : '';
            var rgx = /(\d+)(\d{3})/;
            while (rgx.test(x1))
                x1 = x1.replace(rgx, '$1' + ',' + '$2');
            return x1 + x2;
        }

        function confirmGO() {
            return confirm("آیا از صحت اطلاعات وارد شده اطمینان دارید؟");
            //if (ret_confirm === true) {
            //    checkclick = "true";
            //    return true;
            //}
            //else
            //    return false;
        }

        function zemmablaghbehoorof() {
            var m = document.getElementById('zemtxtmablaghvam').value.replace(',', '');
            m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', '');
            m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', '');
            document.getElementById('zemmablaghfarsiRial').innerHTML = wordifyRials(m);
            if (wordifyRials(m) === 'undefined ریال') {
                document.getElementById('zemmablaghfarsiRial').innerHTML = 'صفر ریال'
            }
            document.getElementById('zemmablaghfarsiToman').innerHTML = wordifyRialsInTomans(m);
        }

        function govmablaghbehoorof() {
            var m = document.getElementById('govtxtmablaghvam').value.replace(',', '');
            m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', '');
            m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', ''); m = m.replace(',', '');
            document.getElementById('govmablaghfarsiRial').innerHTML = wordifyRials(m);
            if (wordifyRials(m) === 'undefined ریال') {
                document.getElementById('govmablaghfarsiRial').innerHTML = 'صفر ریال'
            }
            document.getElementById('govmablaghfarsiToman').innerHTML = wordifyRialsInTomans(m);
        }
        function confirmPrint() {
            var xCounter = 0;
            if (chk_Array_IDs !== null) {

                for (i = 0; i < chk_Array_IDs.length; i++) {
                    var ref_chk = document.getElementById(chk_Array_IDs[i]);
                    if (ref_chk !== null)
                        if (ref_chk.checked === true)
                            ++xCounter;
                }
                if (xCounter === 0) {
                    alert("هیچ گواهی و یا ضمانت نامه ای انتخاب نشده است ");
                    return false;
                }
                else {
                    var ret_confirm = confirm("آیا برای چاپ مجدد اطمینان دارید؟");
                    if (ret_confirm === true) {
                        checkclick = "true";
                        return true;
                    }
                    else
                        return false;
                }
            }
        }
    </script>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">

    <div class=" container">
        <div class="row" id="Dashbord" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">
            <asp:Panel runat="server" ID="pnlsearch" DefaultButton="btnfilter">
                <div class="panel panel-primary" style="margin-bottom: 0px; padding-bottom: 0px">
                    <div class="panel-heading text-center">
                        <h5>صدور گواهی حقوقی و ضمانت نامه جدید </h5>
                        جستجو براساس شماره پرسنلی یا شماره ملی
                       
                    </div>
                    <div class="panel-body" style="margin-bottom: 0px; padding-bottom: 10px">
                        <div class="row">
                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2  ">
                                <label for="txtcode">شماره پرسنلی</label>
                                <asp:TextBox ID="txtcode" runat="server" CssClass="form-control" placeholder="شماره پرسنلی" Style="margin-bottom: 3px"
                                    onkeydown="document.getElementById('MainContent_txtnid').value=''"
                                    onkeypress="return isNumber(event)" />
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
                                <label for="txtnid">شماره ملی</label>
                                <asp:TextBox ID="txtnid" runat="server" CssClass="form-control" placeholder="شماره ملی" Style="margin-bottom: 3px"
                                    onkeydown="document.getElementById('MainContent_txtcode').value=''"
                                    onkeypress="return isNumber(event)" />
                            </div>
                            <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1  " style="padding-top: 25px">
                                <asp:Button ID="btnfilter" Text="جستجو" runat="server" CssClass="btn btn-info" formnovalidate="formnovalidate" />
                            </div>
                            <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1  " style="padding-top: 25px">
                                <asp:Button ID="btnclearfilter" Text="جستجوی جدید" runat="server" CssClass="btn btn-info" Style="margin-right: 10px;" formnovalidate="formnovalidate" />
                            </div>
                        </div>
                        <asp:Panel runat="server" ID="pnlinfo" Visible="false" Style="padding: 8px; background-color: lightblue; margin: 5px">
                            <div class="row">
                                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-4">
                                    نام و نام خانوادگی:
                                 <asp:Label runat="server" ID="lblfullname" ForeColor="Blue" Text=""></asp:Label>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-3">
                                    نام پدر:
                                 <asp:Label runat="server" ID="lblfather" ForeColor="Blue" Text=""></asp:Label>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-4">
                                    شماره پرسنلی:
                                 <asp:Label runat="server" ID="lblcode" ForeColor="Blue" Text=""></asp:Label>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-4">
                                    شماره ملی:
                                 <asp:Label runat="server" ID="lblnid" ForeColor="Blue" Text=""></asp:Label>
                                </div>
                            </div>
                        </asp:Panel>
                    </div>
                    <asp:Panel runat="server" ID="pnlusernotfound" BackColor="LightYellow" Style="padding: 8px" Visible="false" CssClass=" text-center">
                        <asp:Label Text="موردی با مشخصات وارد شده موجود نیست" ID="lblmessage" runat="server" ForeColor="Red" />
                    </asp:Panel>
                </div>
            </asp:Panel>

            <asp:Panel ID="pnlmain" runat="server" CssClass="panel-body" Style="padding: 5px">

                <telerik:RadTabStrip ID="RadTabStrip1" runat="server" Align="Right" Skin="Telerik"
                     Font-Names="Yekan,tahoma"                MultiPageID="RadMultiPage1" SelectedIndex="0">
                    <Tabs>
                        <telerik:RadTab runat="server" Text="اطلاعات اصلی" Selected="True" Font-Names="Yekan,tahoma">
                        </telerik:RadTab>
                        <telerik:RadTab runat="server" Text="صدور ضمانت نامه" Font-Names="Yekan,tahoma">
                        </telerik:RadTab>
                        <telerik:RadTab runat="server" Text="صدور گواهی حقوقی" Font-Names="Yekan,tahoma">
                        </telerik:RadTab>
                        <telerik:RadTab runat="server" Text="موارد صادر شده" Font-Names="Yekan,tahoma">
                        </telerik:RadTab>
                    </Tabs>
                </telerik:RadTabStrip>


                <telerik:RadMultiPage ID="RadMultiPage1" runat="server" SelectedIndex="0">
                    <telerik:RadPageView runat="server" ID="RadPageView1">
                        <div class="row panel-group" id="divDashbord" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">
                            <asp:Panel ID="pnlnotallowed" runat="server" ForeColor="Red" BackColor="LightYellow" Font-Bold="true" Visible="false" CssClass=" text-center" Style="padding-top: 5px; padding-bottom: 5px">
                                <asp:Literal Text="" ID="litmsg" runat="server" />
                            </asp:Panel>
                            <asp:Panel runat="server" ID="BasicInformation">
                                <div class="panel  panel-primary  " style="font-size: 1.1em; font-weight: bold;">
                                    <div class="panel-heading text-center">
                                        <asp:Label Text="" ID="lblprstitle" runat="server" />
                                    </div>
                                    <div class="panel-body">

                                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                                            نوع استخدام:
                                             <asp:Label Text="" ID="lblEstekhdam" runat="server" ForeColor="Blue" />
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                                            وضعیت اشتغال:
                                           <asp:Label Text="" ID="lblEshteghal" runat="server" ForeColor="Blue" />
                                        </div>

                                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                                            مبلغ خالص دریافتی:
                                            <asp:Label Text="" ID="lblkhales" runat="server" ForeColor="Blue" />
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                                            شماره حساب:
                                              <asp:Label Text="" ID="lblhesab" runat="server" ForeColor="Blue" />
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                                            نام محل کار:
                                             <asp:Label Text="" ID="lblworkplace" runat="server" ForeColor="Blue" />
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 rowstyle">
                                            مبلغ مجاز برای دریافت ضمانت نامه یا گواهی حقوقی:
                                              <asp:Label Text="" ID="lblmabkaghmojaz" runat="server" ForeColor="Red" />
                                        </div>

                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  rowstyle">
                                            وضعیت دریافت گواهی جدید: 
                                                <asp:Label Text="" ID="lblvaziyat" runat="server" ForeColor="Blue" />
                                        </div>
                                    </div>
                                </div>
                            </asp:Panel>
                            <asp:Panel runat="server" ID="pnlgovahieinfo" Style="font-size: 1.1em; font-weight: bold;">
                                <div class="panel panel-primary  ">
                                    <div class="panel-heading text-center">
                                        اطلاعات گواهی حقوقی و ضمانت نامه های صادر شده
                                    </div>
                                    <div class="panel-body">

                                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                                            تعداد ضمانت نامه های فعال:    
                                            <asp:Label Text="" ID="lblnumberofactivezemanatnameh" runat="server" ForeColor="Blue" />
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                                            تعداد گواهی حقوقی فعال:                           
                                            <asp:Label Text="" ID="lblnumberofactivegovahies" runat="server" ForeColor="Blue" />
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                                            مجموع:                           
                                            <asp:Label Text="" ID="lbltotalnumberofzemanatandgovahie" runat="server" ForeColor="Blue" />
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                                            مجموع مبالغ ضمانت نامه های فعال:                           
                                            <asp:Label Text="" ID="lblsumofactivezemanat" runat="server" ForeColor="Blue" />
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                                            مجموع مبالغ گواهی حقوقی فعال:                           
                                            <asp:Label Text="" ID="lblsumofactivegovahies" runat="server" ForeColor="Blue" />
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle ">
                                            جمع کل(ضمانت نامه و گواهی حقوقی تسویه نشده):                           
                                            <asp:Label Text="" ID="lblsumofactivezemanatandgovahies" runat="server" ForeColor="red" Font-Bold="true" />
                                        </div>

                                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                                            حداکثر مبلغ مجاز ضمانت:                           
                                            <asp:Label Text="" ID="lblmaxzemanat" runat="server" ForeColor="Blue" />
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 rowstyle">
                                            حداقل خالص دریافتی جهت صدور ضمانت:                           
                                            <asp:Label Text="" ID="lblmincredit" runat="server" ForeColor="Blue" />
                                        </div>
                                    </div>
                                </div>
                            </asp:Panel>
                        </div>
                    </telerik:RadPageView>
                    <telerik:RadPageView runat="server" ID="RadPageView2">
                        <div class="row" id="zemanatDashbord" style="direction: rtl; border: 1px solid lightgray; margin: 1px 6px 0px 6px; background-color: whitesmoke">
                            <div class=" panel panel-primary" style=" background-color: beige ;margin-bottom: 0px !important; padding-bottom: 0px !important; padding-top: 0px !important; margin-top: 0px !important">
                                <div class=" panel-heading">
                                    <div class="panel-title text-center">
                                        صدور ضمانت نامه بانکی
                                    </div>
                                </div>
                                <div class="panel-body " style="margin: 0 auto; width: 70%">
                                    <asp:Panel runat="server" ID="zempnlmsg" CssClass="row text-center" Visible="false" BackColor="LightYellow">
                                        <asp:Label Text="" ID="zemlblmsg" ForeColor="Red" runat="server" />
                                    </asp:Panel>
                                    <br />
                                    <asp:ValidationSummary ID="zemsummary" runat="server" ForeColor="Red" ClientIDMode="Static" ValidationGroup="zemgroup" />
                                    <div class="row myrow">
                                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                            <label for="zemtxtbankname">نام و شعبه بانک /موسسه مالی:</label>
                                        </div>
                                        <div class="col-lg-9  col-md-9 col-sm-12 col-xs-12">
                                            <asp:TextBox runat="server" ID="zemtxtbankname" MaxLength="230" ClientIDMode="Static" CssClass=" form-control"
                                                ValidationGroup="zemgroup" CausesValidation="true" />
                                            <asp:RequiredFieldValidator Display="None" ValidationGroup="zemgroup" SetFocusOnError="true" ErrorMessage="نام بانک را وارد کنید" ControlToValidate="zemtxtbankname" runat="server" />
                                        </div>
                                    </div>
                                    <div class="row myrow">
                                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                            <label for="zemtxtfirstname">نام وام گیرنده:</label>
                                        </div>
                                        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                                            <asp:TextBox runat="server" ID="zemtxtfirstname" MaxLength="45" ClientIDMode="Static" CssClass=" form-control"
                                                ValidationGroup="zemgroup" CausesValidation="true" />
                                            <asp:RequiredFieldValidator Display="None" ValidationGroup="zemgroup" SetFocusOnError="true" ErrorMessage="نام وام گیرنده را وارد کنید" ControlToValidate="zemtxtfirstname" runat="server" />
                                        </div>
                                    </div>
                                    <div class="row myrow">
                                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                            <label for="zemtxtlastname">نام خانوادگی وام گیرنده:</label>
                                        </div>
                                        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                                            <asp:TextBox runat="server" ID="zemtxtlastname" MaxLength="45" ClientIDMode="Static" CssClass=" form-control"
                                                ValidationGroup="zemgroup" CausesValidation="true" />
                                            <asp:RequiredFieldValidator Display="None" ValidationGroup="zemgroup" SetFocusOnError="true" ErrorMessage="نام خانوادگی وام گیرنده را وارد کنید" ControlToValidate="zemtxtlastname" runat="server" />
                                        </div>
                                    </div>
                                    <div class="row myrow">
                                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                            <label for="zemtxtfathername">نام پدر وام گیرنده:</label>
                                        </div>
                                        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                                            <asp:TextBox runat="server" ID="zemtxtfathername" MaxLength="45" ClientIDMode="Static" CssClass=" form-control"
                                                ValidationGroup="zemgroup" CausesValidation="true" />
                                            <asp:RequiredFieldValidator Display="None" ValidationGroup="zemgroup" SetFocusOnError="true" ErrorMessage="نام پدر وام گیرنده را وارد کنید" ControlToValidate="zemtxtfathername" runat="server" />
                                        </div>
                                    </div>
                                    <div class="row myrow">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            حداکثر مبلغ مجاز شما جهت ضمانت نامه :                           
                                            <asp:Label Text="" runat="server" ID="zemlblmaxloan" ForeColor="Blue" Font-Bold="true" Font-Size="1.1em" />
                                        </div>
                                        <br />
                                        <br />
                                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                            <label for="zemtxtmablaghvam">مبلغ وام (ریال):</label>
                                        </div>

                                        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                                            <asp:TextBox runat="server" ID="zemtxtmablaghvam" MaxLength="18" ClientIDMode="Static" CssClass=" form-control"
                                                ValidationGroup="zemgroup" CausesValidation="true"
                                                onkeyup="javascript:this.value=Comma(this.value);zemmablaghbehoorof()"
                                                onkeypress="return isNumber(event)"
                                                Font-Bold="true" Font-Size="16px" />
                                            <asp:RequiredFieldValidator Display="None" ValidationGroup="zemgroup" SetFocusOnError="true" ErrorMessage="مبلغ وام را وارد کنید" ControlToValidate="zemtxtmablaghvam" runat="server" />
                                            <div>
                                                <label id="zemmablaghfarsiToman" style="color: royalblue; font-size: 1.1em;"></label>
                                            </div>
                                            <div>
                                                <label id="zemmablaghfarsiRial" style="color: green; font-size: 1.1em;"></label>
                                            </div>


                                        </div>
                                    </div>

                                </div>
                                <div class=" panel-footer text-center">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 text-center">
                                            <asp:Button Text="ثبت و چاپ" runat="server" CssClass="btn btn-primary " ID="zembtnContinue" ValidationGroup="zemgroup" CausesValidation="true"
                                                OnClientClick=" return confirmGO();" />
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 text-center">
                                            <input type="button" name="btnclear" value="پاک کردن فرم" class="btn btn-primary" onclick="return zemclearform();" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </telerik:RadPageView>
                    <telerik:RadPageView runat="server" ID="RadPageView3">
                        <div class="row" id="GovahieDashbord" style="direction: rtl; border: 1px solid lightgray; margin: 1px 6px 0px 6px; background-color: whitesmoke">
                            <div class=" panel panel-primary" style=" background-color: beige ;margin-bottom: 0px !important; padding-bottom: 0px !important;">
                                <div class=" panel-heading">
                                    <div class="panel-title text-center">
                                        صدور گواهی حقوقی
                                    </div>
                                </div>
                                <div class="panel-body " style="margin: 0 auto; width: 70%; padding-top: 0px !important; margin-top: 0px !important">
                                    <asp:Panel runat="server" ID="govpnlmsg" CssClass="row text-center" Visible="false" BackColor="LightYellow">
                                        <asp:Label Text="" ID="govlblmsg" ForeColor="Red" runat="server" />
                                    </asp:Panel>
                                    <br />
                                    <asp:ValidationSummary ID="govsummary" runat="server" ForeColor="Red" ClientIDMode="Static" ValidationGroup="govgroup" />

                                    <div class="row myrow">
                                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                            <label for="govtxtbankname">نام و شعبه بانک /موسسه مالی:</label>
                                        </div>
                                        <div class="col-lg-9  col-md-9 col-sm-12 col-xs-12">
                                            <asp:TextBox runat="server" ID="govtxtbankname" MaxLength="230" ClientIDMode="Static" CssClass=" form-control" autofocus="autofocus"
                                                ValidationGroup="govgroup" CausesValidation="true" />
                                            <asp:RequiredFieldValidator Display="None" ValidationGroup="govgroup" SetFocusOnError="true" ErrorMessage="نام بانک را وارد کنید" ControlToValidate="govtxtbankname" runat="server" />
                                        </div>
                                    </div>
                                    <div class="row myrow">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            حداکثر مبلغ مجازجهت گواهی حقوقی :                           
                                            <asp:Label Text="" runat="server" ID="govlblmaxloan" ForeColor="Blue" Font-Bold="true" Font-Size="1.1em" />
                                        </div>
                                        <br />
                                        <br />
                                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                            <label for="govtxtmablaghvam">مبلغ وام (ریال):</label>
                                        </div>
                                        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                                            <asp:TextBox runat="server" ID="govtxtmablaghvam" MaxLength="18" ClientIDMode="Static" CssClass=" form-control" autofocus="autofocus"
                                                ValidationGroup="govgroup" CausesValidation="true"
                                                onkeyup="javascript:this.value=Comma(this.value);govmablaghbehoorof()"
                                                onkeypress="return isNumber(event)"
                                                Font-Bold="true" Font-Size="16px" />
                                            <asp:RequiredFieldValidator Display="None" ValidationGroup="govgroup" SetFocusOnError="true" ErrorMessage="مبلغ وام را وارد کنید" ControlToValidate="govtxtmablaghvam" runat="server" />
                                            <div>
                                                <label id="govmablaghfarsiToman" style="color: royalblue; font-size: 1.1em;"></label>
                                            </div>
                                            <div>
                                                <label id="govmablaghfarsiRial" style="color: green; font-size: 1.1em;"></label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=" panel-footer text-center">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 text-center">
                                            <asp:Button Text="ثبت و چاپ" runat="server" CssClass="btn btn-primary " ID="govbtnContinue" ValidationGroup="govgroup" CausesValidation="true"
                                                OnClientClick="return confirmGO();" />
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 text-center">
                                            <input type="button" name="btnclear" value="پاک کردن فرم" class="btn btn-primary" onclick="return govclearform();" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </telerik:RadPageView>
                    <telerik:RadPageView runat="server" ID="RadPageView4">
                        <div class="row" id="itmDashbord" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">

                            <div>
                                <asp:ImageButton ImageUrl="../Images/excel.png" ID="btnExportToexcel" runat="server" ToolTip="ارسال لیست به فایل اکسل" Height="35px" Visible="false" Style="margin-right: 5px;" ClientIDMode="Static" />
                                <asp:ImageButton ImageUrl="../Images/printer.png" ID="btnprint" runat="server" ToolTip="چاپ مجدد گواهی های تسویه نشده و صادر شده در ماه جاری" Height="35px" Visible="false" Style="margin-right: 5px;" OnClientClick="return confirmPrint();" ClientIDMode="Static" />
                                <asp:ImageButton ImageUrl="../Images/PrintList.png" ID="ImageButton_Print_List" runat="server" ToolTip="چاپ گزارش گواهی های تسویه نشده" Height="35px" Visible="false" Style="margin-right: 5px;" ClientIDMode="Static" />

                                <link href="../Content/tooltip/tooltip.css" rel="stylesheet" />

                                <script src="./Scripts/tooltip/tooltip.js"></script>
                                <script type="text/javascript">
                                    $('#btnExportToexcel,#btnprint,#ImageButton_Print_List').tooltip({

                                        // 'left', 'right', 'below' or 'above'
                                        direction: "below",

                                        // in ms
                                        delay: 50

                                    });

                                </script>


                            </div>

                            <asp:Panel ID="pnlgrid" runat="server" CssClass="panel-body" Style="padding: 5px">
                                <asp:Panel runat="server" ID="itempnlmsg" BackColor="LightYellow" Style="padding: 8px" Visible="false">
                                    <p>
                                        <asp:Label Text="" ID="itemlblmsg" runat="server" ForeColor="Red" />

                                    </p>
                                </asp:Panel>
                                <telerik:RadGrid ID="RadGrid1" runat="server" AllowPaging="True" CssClass="table-responsive" AllowSorting="True" AutoGenerateColumns="False" PageSize="50"
                                    BorderStyle="Solid" Skin="Outlook" Font-Names="yekan" MasterTableView-NoMasterRecordsText="هیچ اطلاعاتی برای نمایش موجود نیست" GroupingSettings-GroupSplitDisplayFormat="نمایش {0} از {1} " PagerStyle-PageSizeLabelText="اندازه صفحه" PagerStyle-NextPageToolTip="صفحه بعد" PagerStyle-NextPagesToolTip="صفحه بعد" PagerStyle-LastPageToolTip="آخرین صفحه" PagerStyle-FirstPageToolTip="اولین صفحه" PagerStyle-GoToPageButtonToolTip="برو به صفحه">
                                    <GroupingSettings CollapseAllTooltip="Collapse all groups"></GroupingSettings>
                                    <ClientSettings EnableRowHoverStyle="true" EnableAlternatingItems="true" Selecting-AllowRowSelect="true">
                                        <Selecting AllowRowSelect="True" />
                                    </ClientSettings>
                                    <ExportSettings Pdf-AllowPrinting="true" Pdf-PaperSize="A4" IgnorePaging="true" OpenInNewWindow="true">
                                        <Pdf PageHeight="210mm" PageWidth="297mm" DefaultFontFamily="B Nazanin" PageTopMargin="15mm" PageLeftMargin="15mm" PageRightMargin="15mm"
                                            BorderStyle="Medium" BorderType="AllBorders" BorderColor="Black">
                                        </Pdf>
                                        <Word Format="Docx" />
                                    </ExportSettings>
                                    <MasterTableView CssClass="table-responsive" DataKeyNames="RowID,GovahiTypeID,StateId,DateOfCreate">
                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                            <HeaderStyle Font-Bold="true" Width="20px" />
                                        </RowIndicatorColumn>
                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                            <HeaderStyle Font-Bold="true" Width="20px" />
                                        </ExpandCollapseColumn>
                                        <EditFormSettings>
                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                            </EditColumn>
                                        </EditFormSettings>
                                        <Columns>
                                            <telerik:GridClientSelectColumn Reorderable="False" UniqueName="chkRow">
                                                <HeaderStyle Width="30px"></HeaderStyle>
                                            </telerik:GridClientSelectColumn>

                                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="False" HeaderText="ردیف" ReadOnly="True" UniqueName="radif" AllowSorting="true">
                                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Width="10px" Font-Names="yekan" VerticalAlign="Middle" />
                                                <ItemTemplate>
                                                    <asp:Label ID="Grid_RowNumber_Label" runat="server" />
                                                </ItemTemplate>
                                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="40px" />
                                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="Center" Width="10px" Font-Names="yekan" VerticalAlign="Middle" />
                                            </telerik:GridTemplateColumn>

                                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="شماره گواهی" ReadOnly="True" DataField="Shomareh" UniqueName="Shomareh" AllowSorting="true" SortExpression="Shomareh">
                                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                                <ItemTemplate>
                                                    <asp:Label ID="lblshomarehgovahei" runat="server" Text='<%# (Eval("Shomareh")) %>'></asp:Label>
                                                </ItemTemplate>
                                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="60px" />
                                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="center" Font-Names="yekan" VerticalAlign="Middle" />
                                            </telerik:GridTemplateColumn>

                                            <telerik:GridBoundColumn DataField="BankFullname" HeaderText="نام بانک" ReadOnly="True" UniqueName="BankFullname" Groupable="true" AllowSorting="true" AllowFiltering="False">
                                                <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="150px" Font-Bold="true" />
                                                <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                                            </telerik:GridBoundColumn>

                                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="مبلغ ضمانت" ReadOnly="True" DataField="LoanAmount"
                                                UniqueName="LoanAmount" AllowSorting="true" SortExpression="LoanAmount">
                                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                                <ItemTemplate>
                                                    <asp:Label ID="lblLoanAmount" runat="server" Text='<%# (DataBinder.Eval(Container.DataItem, "LoanAmount", "{0:##,###}"))%>'></asp:Label>
                                                </ItemTemplate>
                                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="70px" />
                                                <ItemStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" HorizontalAlign="left" Font-Names="yekan" VerticalAlign="Middle" />
                                            </telerik:GridTemplateColumn>

                                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="خالص دریافتی" ReadOnly="True" DataField="MablaghKhalesDaryafti"
                                                UniqueName="MablaghKhalesDaryafti" AllowSorting="true" SortExpression="MablaghKhalesDaryafti">
                                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                                <ItemTemplate>
                                                    <asp:Label runat="server" Text='<%# (DataBinder.Eval(Container.DataItem, "MablaghKhalesDaryafti", "{0:#,###,###}"))%>'></asp:Label>
                                                </ItemTemplate>
                                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="70px" />
                                                <ItemStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" HorizontalAlign="left" Font-Names="yekan" VerticalAlign="Middle" />
                                            </telerik:GridTemplateColumn>

                                            <telerik:GridBoundColumn DataField="LoanOwner_FirstName" HeaderText="نام وام گیرنده" ReadOnly="True" UniqueName="LoanOwner_FirstName" Groupable="false" AllowSorting="true" AllowFiltering="False">
                                                <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="80px" Font-Bold="true" />
                                                <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                                            </telerik:GridBoundColumn>

                                            <telerik:GridBoundColumn DataField="LoanOwner_LastName" HeaderText="نام خانوادگی وام گیرنده" ReadOnly="True" UniqueName="LoanOwner_LastName" Groupable="false" AllowSorting="true" AllowFiltering="False">
                                                <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="100px" Font-Bold="true" />
                                                <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                                            </telerik:GridBoundColumn>

                                            <telerik:GridBoundColumn DataField="LoanOwner_FatherName" HeaderText="نام پدر وام گیرنده" ReadOnly="True" UniqueName="LoanOwner_FatherName" Groupable="false" AllowSorting="true" AllowFiltering="False">
                                                <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="80px" Font-Bold="true" />
                                                <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                                            </telerik:GridBoundColumn>

                                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="نوع گواهی" ReadOnly="True" DataType="System.Int16"
                                                DataField="GovahiTypeID" UniqueName="GovahiTypeID" AllowSorting="true" SortExpression="GovahiTypeID">
                                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                                <ItemTemplate>
                                                    <asp:Label runat="server" Text='<%# utill.GetGovahiType(Eval("GovahiTypeID")) %>'></asp:Label>
                                                </ItemTemplate>
                                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="70px" />
                                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="right" Font-Names="yekan" VerticalAlign="Middle" />
                                            </telerik:GridTemplateColumn>

                                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="وضعیت گواهی" ReadOnly="True" DataField="StateId" UniqueName="StateId" AllowSorting="true" SortExpression="StateId">
                                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                                <ItemTemplate>
                                                    <asp:Label runat="server" Text='<%# utill.GetGovahiStatus(Eval("StateId")) %>' ForeColor='<%# getcolor(Eval("StateId")) %>'></asp:Label>
                                                </ItemTemplate>
                                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="70px" />
                                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="center" Font-Names="yekan" VerticalAlign="Middle" />
                                            </telerik:GridTemplateColumn>

                                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="تاریخ ثبت" ReadOnly="True" DataField="DateOfCreate" UniqueName="DateOfCreate" AllowSorting="true" SortExpression="DateOfCreate">
                                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                                <ItemTemplate>
                                                    <asp:Label ID="lblDateOfCreate" runat="server" Text='<%# utill.En2Fa(utill.DateToString(Eval("DateOfCreate"))) %>'></asp:Label>
                                                </ItemTemplate>
                                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="70px" />
                                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="center" Font-Names="yekan" VerticalAlign="Middle" />
                                            </telerik:GridTemplateColumn>

                                            <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="وضعیت صدور گواهی" ReadOnly="True" DataField="Vaziyat_Soudur" UniqueName="Vaziyat_Soudur" AllowSorting="true" SortExpression="Vaziyat_Soudur">
                                                <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                                <ItemTemplate>
                                                    <asp:Label runat="server" Text='<%# utill.Vaziyat_Soudur_To_String(Eval("Vaziyat_Soudur")) %>' ForeColor='<%# VaziyatSoudorColor(Eval("Vaziyat_Soudur")) %>'></asp:Label>
                                                </ItemTemplate>
                                                <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="70px" Font-Size="Small" />
                                                <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="center" Font-Names="yekan" VerticalAlign="Middle" />
                                            </telerik:GridTemplateColumn>

                                            <telerik:GridBoundColumn DataField="Sader_Konandeh" HeaderText="صادر کننده" ReadOnly="True" UniqueName="Sader_Konandeh" Groupable="false" AllowSorting="true" AllowFiltering="False">
                                                <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="100px" Font-Bold="true" />
                                                <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                                            </telerik:GridBoundColumn>

                                           

                                        </Columns>
                                    </MasterTableView>
                                    <PagerStyle FirstPageToolTip="اولین صفحه"
                                        Font-Strikeout="False" HorizontalAlign="Center" LastPageToolTip="آخرین صفحه"
                                        NextPagesToolTip="صفحه بعد" NextPageToolTip="صفحه بعد" PageSizeLabelText="تعداد سطر های هر صفحه:"
                                        PrevPagesToolTip="صفحه قبل" PrevPageToolTip="صفحه قبل" />
                                    <FilterMenu EnableImageSprites="False">
                                    </FilterMenu>
                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                    </HeaderContextMenu>
                                </telerik:RadGrid>
                                <div class="row" style="padding-bottom: 5px; padding-top: 5px;">
                                    <div class="col-lg-2 col-md-12 col-sm-12 col-xs-12 text-center">
                                        <asp:Label Text="" ID="lblNumberOfActiveGovahie" runat="server" ForeColor="DarkBlue" />
                                    </div>
                                    <div class="col-lg-2 col-md-12 col-sm-12 col-xs-12 text-center">
                                        <asp:Label Text="" ID="Label2" runat="server" ForeColor="DarkBlue" />
                                    </div>
                                    <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 text-center">
                                        <asp:Label Text="" ID="lblactive" runat="server" ForeColor="DarkBlue" Font-Size=".93em" />
                                    </div>
                                    <div class="col-lg-2 col-md-12 col-sm-12 col-xs-12 text-center">
                                        <asp:Label Text="" ID="lblTasviyeh" runat="server" ForeColor="DarkBlue" />
                                    </div>
                                    <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 text-center">
                                        <asp:Label Text="" ID="lbltotal" runat="server" ForeColor="DarkBlue" />
                                    </div>
                                </div>

                            </asp:Panel>
                        </div>

                    </telerik:RadPageView>
                </telerik:RadMultiPage>
            </asp:Panel>
        </div>
    </div>


</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">

    <script>
        String.prototype.toPersianDigit = function (a) {
            return this.replace(/\d+/g, function (digit) {
                var enDigitArr = [], peDigitArr = [];
                for (var i = 0; i < digit.length; i++) {
                    enDigitArr.push(digit.charCodeAt(i));
                }
                for (var j = 0; j < enDigitArr.length; j++) {
                    peDigitArr.push(String.fromCharCode(enDigitArr[j] + ((!!a && a === true) ? 1584 : 1728)));
                }
                return peDigitArr.join('');
            });
        };

        function TraceNodes(Node) {
            if (Node.nodeType === 3 && Node.parentNode.localName !== "style" && Node.parentNode.localName !== "script")  //TextNode
                Node.nodeValue = Node.nodeValue.toPersianDigit();
            else
                for (var i = 0; i < Node.childNodes.length; i++)
                    TraceNodes(Node.childNodes[i]);
        }

        TraceNodes(document);
    </script>
</asp:Content>
