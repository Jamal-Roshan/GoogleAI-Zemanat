﻿<%@ Page Language="vb" AutoEventWireup="false" CodeBehind="g.aspx.vb" Inherits="ZemanatNameh.vb.g" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title> 
    <script src="../Scripts/jquery-2.2.0.min.js"></script>
    <script src="../Scripts/jquery.farsiInput.js"></script>
    <script type="text/javascript">
        $(function () {
            $("#txtbankname, #txtfirstname,#txtlastname,#txtfathername").farsiInput();
        });
    </script>
</head>
<body>
    <form id="form1" runat="server">
      

        <div class="row" id="zemanatDashbord" style="direction: rtl; border: 1px solid lightgray; margin: 1px 6px 0px 6px; background-color: whitesmoke">
            <div class=" panel panel-primary" style="margin-bottom: 0px !important; padding-bottom: 0px !important;">
                <div class=" panel-heading">
                    <div class="panel-title text-center">
                        صدور ضمانت نامه بانکی
                    </div>
                </div>
                <div class="panel-body " style="margin: 0 auto; width: 70%">
                    <asp:Panel runat="server" ID="Panel2" CssClass="row text-center" Visible="false" BackColor="LightYellow">
                        <asp:Label Text="" ID="lblmsg" ForeColor="Red" runat="server" />
                    </asp:Panel>
                    <br />
                    <div class="row myrow">
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <label for="txtbankname">نام و شعبه بانک /موسسه مالی:</label>
                        </div>
                        <div class="col-lg-9  col-md-9 col-sm-12 col-xs-12">
                            <asp:TextBox runat="server" ID="txtbankname" MaxLength="230" ClientIDMode="Static" CssClass=" form-control" required="required" autofocus="autofocus"
                                oninvalid="InvalidMsg(this,'نام کامل بانک یا موسسه مالی را وارد کنید');"
                                oninput="nvalidMsg(this,'نام کامل بانک یا موسسه مالی را وارد کنید');" />
                        </div>
                    </div>
                    <div class="row myrow">
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <label for="txtbankname">نام وام گیرنده:</label>
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                            <asp:TextBox runat="server" ID="txtfirstname" MaxLength="45" ClientIDMode="Static" CssClass=" form-control" required="required" autofocus="autofocus"
                                oninvalid="InvalidMsg(this,'نام وام گیرنده را وارد کنید');"
                                oninput="nvalidMsg(this,'نام وام گیرنده را وارد کنید');" />
                        </div>
                    </div>
                    <div class="row myrow">
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <label for="txtbankname">نام خانوادگی وام گیرنده:</label>
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                            <asp:TextBox runat="server" ID="txtlastname" MaxLength="45" ClientIDMode="Static" CssClass=" form-control" required="required" autofocus="autofocus"
                                oninvalid="InvalidMsg(this,'نام خانوادگی وام گیرنده را وارد کنید');"
                                oninput="nvalidMsg(this,'نام خانوادگی وام گیرنده را وارد کنید');" />
                        </div>
                    </div>
                    <div class="row myrow">
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <label for="txtbankname">نام پدر وام گیرنده:</label>
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                            <asp:TextBox runat="server" ID="txtfathername" MaxLength="45" ClientIDMode="Static" CssClass=" form-control" required="required" autofocus="autofocus"
                                oninvalid="InvalidMsg(this,'نام پدر وام گیرنده را وارد کنید');"
                                oninput="nvalidMsg(this,'نام پدر وام گیرنده را وارد کنید');" />
                        </div>
                    </div>
                    <div class="row myrow">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            حداکثر مبلغ مجاز شما جهت ضمانت نامه :                           
                                            <asp:Label Text="" runat="server" ID="lblmaxloan" ForeColor="Blue" Font-Bold="true" />
                        </div>
                        <br />
                        <br />
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <label for="txtbankname">مبلغ وام (ریال):</label>
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                            <asp:TextBox runat="server" ID="txtmablaghvam" MaxLength="18" ClientIDMode="Static" CssClass=" form-control" required="required" autofocus="autofocus"
                                oninvalid="InvalidMsg(this,'مبلغ وام را وارد کنید');"
                                oninput="nvalidMsg(this,'مبلغ وام را وارد کنید');"
                                onkeyup="javascript:this.value=Comma(this.value);mablaghbehoorof()"
                                onkeypress="return isNumber(event)"
                                Font-Bold="true" Font-Size="16px" />
                            <div>
                                <label id="mablaghfarsiToman" style="color: royalblue"></label>
                            </div>
                            <div>
                                <label id="mablaghfarsiRial" style="color: green"></label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=" panel-footer text-center">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 text-center">
                            <asp:Button Text="ثبت و چاپ" runat="server" CssClass="btn btn-primary " ID="btnContinue" OnClientClick="return confirmGO();" />
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 text-center">
                            <input type="button" name="btnclear" value="پاک کردن فرم" class="btn btn-primary" onclick="return clearform();" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</body>
</html>
