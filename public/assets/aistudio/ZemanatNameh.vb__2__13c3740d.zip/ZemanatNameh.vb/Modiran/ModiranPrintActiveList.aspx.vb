﻿Imports System.Data.SqlClient
Imports Stimulsoft.Report
Public Class ModiranPrintActiveList
    Inherits System.Web.UI.Page
    Private utill As New Utility
    Private vahed As String = " ریال "
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim Code As String = ""
        If Session("userCode") Is Nothing Then
            Response.Redirect("./new", True)
        End If
        Code = Session("userCode").ToString

        Dim strselect As String = "SELECT dbo.Users_table.Code, dbo.Govahies.RowID, dbo.Govahies.Shomareh, dbo.Govahies.BankFullname, dbo.Govahies.LoanAmount, dbo.Govahies.LoanOwner_FirstName, " _
                         & " dbo.Govahies.LoanOwner_LastName, dbo.Govahies.LoanOwner_FatherName, dbo.Govahies.DateOfCreate, dbo.Vaziyat_Eshteghal.Title AS Eshteghal, dbo.EmployeeTypes.Title AS Estekhdam, dbo.Users_table.Firstname, " _
                         & " dbo.Users_table.Lastname, 'PersianDate' AS PersianDate, dbo.Users_table.Fathername, dbo.Users_table.NationalID, dbo.Govahistatus.Title AS VAziyatGovahie, dbo.GovahiTypes.Id, dbo.GovahiTypes.Title AS GovahieType, " _
                         & " dbo.Vaziyat_Soudor_Type.Title AS Vaziyat_Soudor FROM dbo.Users_table INNER JOIN dbo.Govahies ON dbo.Users_table.Code = dbo.Govahies.Code INNER JOIN " _
                         & " dbo.Vaziyat_Eshteghal ON dbo.Users_table.EshteghalID = dbo.Vaziyat_Eshteghal.EshteghalID INNER JOIN " _
                         & " dbo.EmployeeTypes On dbo.Users_table.EstekhdamID = dbo.EmployeeTypes.Type_ID INNER JOIN dbo.Govahistatus ON dbo.Govahies.StateId = dbo.Govahistatus.Status_ID INNER JOIN " _
                         & " dbo.GovahiTypes ON dbo.Govahies.GovahiTypeID = dbo.GovahiTypes.Id INNER JOIN dbo.Vaziyat_Soudor_Type ON dbo.Govahies.Vaziyat_Soudur = dbo.Vaziyat_Soudor_Type.id " _
                         & " WHERE (dbo.Govahies.StateId = 1) And (dbo.Users_table.Code =@Code) ORDER BY dbo.Govahies.DateOfCreate DESC "


        ' Dim sum As Double = 0

        Dim dt As New DataTable()

        Using connection As New SqlConnection(utill.Connectionstring)
            Using command As New SqlCommand(strselect, connection)
                command.CommandType = CommandType.Text
                command.Parameters.Clear()
                command.Parameters.AddWithValue("@Code", Code)
                Using sda As New SqlDataAdapter(command)

                    Try
                        dt.Clear()
                        sda.Fill(dt)
                        For Each datarow As DataRow In dt.Rows
                            Dim RowID As Long = CType(datarow.Item("RowID"), Long)
                            Dim row() As DataRow
                            row = dt.Select("ROWID=" & RowID)
                            row(0)("PersianDate") = utill.GetPersianDate(CType(datarow.Item("DateOfCreate"), Date))
                        Next
                    Catch ex As Exception
                        dt.Clear()
                        lblmessage.Text = "در عملیت چاپ گزارش خطا رخ داده است.لطفا دوباره سعی کنید."
                        pnlmsg2.Visible = False
                        pnlmsg.Visible = True
                        Exit Sub
                    End Try

                    'Try
                    '    sum = CType(dt.Compute("sum(LoanAmount)", "StateId=1"), Long)
                    'Catch ex As Exception
                    '    Server.ClearError()
                    '    sum = 0
                    'End Try

                End Using
            End Using
        End Using


        Dim NationalID As String = utill.Get_NationalID_By_Code(code)
        Dim Firstname As String = utill.Get_Firstname_By_Code(code)
        Dim Lastname As String = utill.Get_Lastname_By_Code(code)
        Dim orgtitle As String = utill.Get_Application_Settings(AppSettings.orgtitle.ToString).Trim & " - واحد " & utill.Get_Application_Settings(AppSettings.orgunittitle.ToString).Trim
        Dim Eshteghal As String = utill.Get_EshteghalType_By_EshteghalID(utill.Get_EshteghalID_By_Code(code)).Trim
        Dim Estekhdam As String = utill.Get_EstekhdamType_By_EstekhdamID(utill.Get_EstekhdamID_By_Code(code))
        Dim MablaghKhales As Long = utill.Get_Khalesdaryafti_By_Code(Code)
        Dim serverlocation As String = HttpContext.Current.Server.MapPath(String.Empty)
        Dim myreport As New StiReport()
        myreport.Load(serverlocation + "\reports\ActiveList.mrt")
        myreport.Dictionary.Variables.Clear()

        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "orgtitle", orgtitle))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "firstname", Firstname))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "lastname", Lastname))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "prscode", Code))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "mablaghkhales", MablaghKhales))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "nidcode", NationalID))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "eshteghal", Eshteghal))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "estekhdam", Estekhdam))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Karmand_Info", "printdate", utill.GetPersianDate(Today)))

        myreport.RegData(dt)
        myreport.Compile()
        myreport.Dictionary.Synchronize()
        myreport.Render(True)
        StiWebViewer1.Report = myreport

        dt.Clear()


    End Sub

End Class