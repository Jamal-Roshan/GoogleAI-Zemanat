﻿Public Class init
    Inherits System.Web.UI.Page
    Public utill As New Utility
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub gg_Click(sender As Object, e As EventArgs) Handles gg.Click
        utill.Set_RowValidationCode_For_All_Rows_In_Govaheis_Table()
        utill.Set_Number_Of_Active_Govahie_For_ALL_Users()
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        utill.Set_Number_Of_Active_Govahie_For_ALL_Users()
        'utill.Set_RowValidationCode_For_All_User_In_Users_Table()
    End Sub
End Class