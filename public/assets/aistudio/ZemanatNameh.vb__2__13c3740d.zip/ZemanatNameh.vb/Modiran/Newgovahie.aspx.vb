﻿Imports System.Data.SqlClient
Imports System.Web.Services
'Imports NumberToWordsLib
Imports Telerik.Web.UI
Public Class newgovahie
    Inherits System.Web.UI.Page
    Public utill As New Utility
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Me.Page.IsPostBack Then
            If Not isUSerExist() Then
                pnlmain.Visible = False
                pnlinfo.Visible = False
            Else
                pnlmain.Visible = True
                pnlinfo.Visible = True
                bindgrid()
                If RadGrid1.MasterTableView.Items.Count = 0 Then
                    pnlgrid.Visible = False
                    btnExportToexcel.Visible = False
                    'btnExportToPDF.Visible = False
                    btnprint.Visible = False
                Else
                    pnlgrid.Visible = True
                    btnExportToexcel.Visible = True
                    'btnExportToPDF.Visible = True
                    btnprint.Visible = True
                End If
            End If


        End If
    End Sub

    Protected Sub btnfilter_Click(sender As Object, e As EventArgs) Handles btnfilter.Click
        Filter_Clear_Helper()
        If Not isUSerExist() Then
            pnlmain.Visible = False
            pnlinfo.Visible = False
        Else
            ' غير فعال كردن صدور ضمانت نامه براي افراد بازنشسته
            If utill.Get_EshteghalID_By_Code(lblcode.Text) = 2 Then
                pnlmain.Visible = False
                pnlusernotfound.Visible = True
                pnlinfo.Visible = True
                lblmessage.Text = "امكان صدور گواهی برای افراد بازنشسته وجود ندارد"
                zembtnContinue.Enabled = False
                govbtnContinue.Enabled = False
            Else
                zembtnContinue.Enabled = True
                govbtnContinue.Enabled = True
            End If
            ' غير فعال كردن صدور ضمانت نامه براي افراد بازنشسته

            pnlmain.Visible = True
                pnlinfo.Visible = True
                bindgrid()
                If RadGrid1.MasterTableView.Items.Count = 0 Then
                    pnlgrid.Visible = False
                    btnExportToexcel.Visible = False
                    'btnExportToPDF.Visible = False
                    btnprint.Visible = False
                Else
                    pnlgrid.Visible = True
                    btnExportToexcel.Visible = True
                    'btnExportToPDF.Visible = True
                    btnprint.Visible = True
                End If

            End If
            RadTabStrip1.SelectedIndex = 0
        RadMultiPage1.SelectedIndex = 0
    End Sub

    Protected Sub btnclearfilter_Click(sender As Object, e As EventArgs) Handles btnclearfilter.Click
        txtcode.Text = ""
        txtnid.Text = ""
        Filter_Clear_Helper()
    End Sub
    Private Sub Filter_Clear_Helper()
        lblfullname.Text = ""
        lblfather.Text = ""
        lblnid.Text = ""
        pnlinfo.Visible = False
        pnlmain.Visible = False
        pnlusernotfound.Visible = False
        RadTabStrip1.SelectedIndex = 0
        RadMultiPage1.SelectedIndex = 0
        zemtxtbankname.Text = ""
        zemtxtfirstname.Text = ""
        zemtxtlastname.Text = ""
        zemtxtfathername.Text = ""
        zemtxtmablaghvam.Text = ""
        zemlblmaxloan.Text = ""
        zemlblmsg.Text = ""

        govtxtbankname.Text = ""
        govtxtmablaghvam.Text = ""
        govlblmaxloan.Text = ""
        govlblmsg.Text = ""
    End Sub
    Private Function isUSerExist() As Boolean
        Dim returnResult As Boolean = False
        Dim serchcondition As String = ""
        If txtnid.Text.Trim.Length > 0 Then
            serchcondition = "[NationalID]=@NationalID"
        End If
        If txtcode.Text.Trim.Length > 0 Then
            serchcondition = "[Code]=@Code"
        End If

        If txtnid.Text.Trim.Length = 0 And txtcode.Text.Trim.Length = 0 Then
            Return False
        End If

        Dim strselect As String = "SELECT [Code],[NationalID],[Firstname],[Lastname],[Fathername] FROM [Users_table] WHERE " & serchcondition
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()

                    If txtcode.Text.Trim.Length > 0 Then
                        command.Parameters.AddWithValue("@Code", utill.Fa2En(txtcode.Text.Trim))
                    End If
                    If txtnid.Text.Trim.Length > 0 Then
                        command.Parameters.AddWithValue("@NationalID", utill.Fa2En(txtnid.Text.Trim))
                    End If

                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            lblfullname.Text = reader("Firstname").ToString & " " & reader("Lastname").ToString
                            lblfather.Text = reader("Fathername").ToString
                            lblcode.Text = reader("Code").ToString
                            lblnid.Text = reader("NationalID").ToString
                            returnResult = True
                            pnlusernotfound.Visible = False
                            RadTabStrip1.TabIndex = 0
                            fillMainTab()

                        Else
                            pnlusernotfound.Visible = True
                            lblmessage.Text = "موردی با مشخصات وارد شده موجود نیست"
                            Return False
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class UserAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return returnResult
    End Function

    Private Sub fillMainTab()
        Dim Code As String = utill.Fa2En(lblcode.Text)
        utill.Is_User_Data_Correct(Code)
        Dim vahed As String = " ریال "
        CheckSoudor()
        If Not utill.ActiveUser(Code) Then
            pnlnotallowed.Visible = True
            Dim msg As String = "<h4>" & "حساب کاربری جهت صدور ضمانت نامه و گواهی حقوقی غیر فعال شده است" & "</h4>"
            Dim res As String = "<h5>" & "دلیل غیر فعال شدن حساب کاربری : " & "<span  style=""color:blue"">" & "عدم دریافت حقوق و مزایا در ماه جاری" & "</span>" & "</h5>"

            litmsg.Text = msg & res
            BasicInformation.Visible = False
            pnlgovahieinfo.Visible = False
            Return
        End If


        If utill.IsBlockedUser(Code) Then
            pnlnotallowed.Visible = True
            Dim msg As String = "<h4>" & "حساب کاربری جهت صدور ضمانت نامه و گواهی حقوقی مسدود شده است" & "</h4>"
            Dim res As String = "<h5>" & "دلیل مسدود شدن حساب کاربری : " & "<span  style=""color:blue"">" & utill.GetBlockResone(Code) & "</span>" & "</h5>"

            litmsg.Text = msg & res
            BasicInformation.Visible = False
            pnlgovahieinfo.Visible = False
            Return
        Else
            pnlnotallowed.Visible = False
            litmsg.Text = ""
            BasicInformation.Visible = True
            pnlgovahieinfo.Visible = True
        End If
        Dim maxzemanat As Long = utill.Get_Khalesdaryafti_By_Code(Code:=Code) * CType(utill.Get_Application_Settings(AppSettings.zarib.ToString), Long)
        utill.Get_Khalesdaryafti_By_Code(Code:=Code)
        Dim mincredit As Long = CType(utill.Get_Application_Settings(AppSettings.mincredit.ToString), Long)
        Dim Sum_Of_Active_Govahies_And_Zemanatnameh As Long = utill.Get_Sum_Of_Active_Govahies_And_Zemanatnameh_By_Code(Code)
        Dim khalesdaryafti As Long = utill.Get_Khalesdaryafti_By_Code(Code)
        Dim mablaghmojaz As Long = maxzemanat - Sum_Of_Active_Govahies_And_Zemanatnameh


        If mablaghmojaz <= 0 Then
            lblvaziyat.ForeColor = Drawing.Color.Red
            lblvaziyat.Text = "به علت دریافت حداکثر مبلغ ضمانت نامه  مجاز به دریافت ضمانت نامه و گواهی حقوقی جدید نمی باشد"

        ElseIf khalesdaryafti < mincredit Then
            lblvaziyat.ForeColor = Drawing.Color.Red
            lblvaziyat.Text = "به علت اینکه مبلغ خالص دریافتی  کمتر از حداقل تعیین شده است مجاز به دریافت ضمانت نامه و گواهی حقوقی جدید نمی باشد"
        Else
            lblvaziyat.ForeColor = Drawing.Color.Green
            lblvaziyat.Text = "  صدور گواهی حقوقی و یا ضمانت نامه بانکی تا مبلغ مجاز تعیین شده امکان پذیر است "
        End If

        If mablaghmojaz <= 0 OrElse khalesdaryafti < mincredit Then
            mablaghmojaz = 0
        End If

        lblprstitle.Text = "اطلاعات پرسنلی " & lblfullname.Text & " در " & utill.Get_PersianMonthName(utill.Get_CurrentMonth_By_Code(Code)) & " ماه " & " سال " & utill.En2Fa(utill.GetPersianYear(utill.Get_OperationDate_By_Code(Code)))
        lblEstekhdam.Text = " " & utill.Get_EstekhdamType_By_EstekhdamID(utill.Get_EstekhdamID_By_Code(Code))
        lblEshteghal.Text = " " & utill.Get_EshteghalType_By_EshteghalID(utill.Get_EshteghalID_By_Code(Code))
        lblkhales.Text = " " & utill.En2Fa(khalesdaryafti.ToString("#,##0")) & vahed
        lblhesab.Text = " " & utill.En2Fa(utill.Get_AccountNumber_By_Code(Code))
        lblworkplace.Text = " " & utill.En2Fa(utill.Get_WorkPlace_By_Code(Code))

        lblnumberofactivezemanatnameh.Text = " " & utill.En2Fa(utill.Get_Number_Of_Active_Zemanatnameh_By_Code(Code).ToString("#,##0"))
        lblnumberofactivegovahies.Text = " " & utill.En2Fa(utill.Get_Number_Of_Active_Govahies_By_Code(Code).ToString("#,##0"))
        lbltotalnumberofzemanatandgovahie.Text = " " & utill.En2Fa((utill.Get_Number_Of_Active_Zemanatnameh_By_Code(Code) + utill.Get_Number_Of_Active_Govahies_By_Code(Code)).ToString("#,##0"))
        lblsumofactivezemanat.Text = " " & utill.En2Fa(utill.Get_Sum_Of_Active_Zemanatnameh_By_Code(Code).ToString("#,##0")) & vahed
        lblsumofactivegovahies.Text = " " & utill.En2Fa(utill.Get_Sum_Of_Active_Govahies_By_Code(Code).ToString("#,##0")) & vahed
        lblsumofactivezemanatandgovahies.Text = " " & utill.En2Fa(Sum_Of_Active_Govahies_And_Zemanatnameh.ToString("#,##0")) & vahed
        lblmaxzemanat.Text = " " & utill.En2Fa(maxzemanat.ToString("#,##0")) & vahed
        lblmincredit.Text = " " & utill.En2Fa(mincredit.ToString("#,##0")) & vahed

        lblmabkaghmojaz.Text = " " & utill.En2Fa(mablaghmojaz.ToString("#,##0")) & vahed
        zemlblmaxloan.Text = lblmabkaghmojaz.Text
        govlblmaxloan.Text = lblmabkaghmojaz.Text

    End Sub

    Sub CheckSoudor()

        Dim Code As String = utill.Fa2En(lblcode.Text)
        utill.Is_User_Data_Correct(code)
        utill.Is_Govahie_Data_Correct(code)
        If utill.IsBlockedUser(code) Then
            RadTabStrip1.Tabs.Item(1).Enabled = False
            RadTabStrip1.Tabs.Item(2).Enabled = False
            'zembtnContinue.Enabled = False
            'govbtnContinue.Enabled = False

            RadTabStrip1.TabIndex = 0
            RadMultiPage1.SelectedIndex = 0
            Return
        Else
            RadTabStrip1.Tabs.Item(1).Enabled = True
            RadTabStrip1.Tabs.Item(2).Enabled = True
            'zembtnContinue.Enabled = True
            'govbtnContinue.Enabled = True

        End If
        If Not utill.AllowedToGetGovahie(Code) Then
            RadTabStrip1.Tabs.Item(1).Enabled = False
            RadTabStrip1.Tabs.Item(2).Enabled = False
            'zembtnContinue.Enabled = False
            'govbtnContinue.Enabled = False

            RadTabStrip1.TabIndex = 0
            RadMultiPage1.SelectedIndex = 0
            Return
        Else
            RadTabStrip1.Tabs.Item(1).Enabled = True
            RadTabStrip1.Tabs.Item(2).Enabled = True
            'zembtnContinue.Enabled = True
            'govbtnContinue.Enabled = True
        End If
        If Not utill.ActiveUser(Code) Then
            RadTabStrip1.Tabs.Item(1).Enabled = False
            RadTabStrip1.Tabs.Item(2).Enabled = False
            'zembtnContinue.Enabled = False
            'govbtnContinue.Enabled = False

            RadTabStrip1.TabIndex = 0
            RadMultiPage1.SelectedIndex = 0
            Return
        Else
            RadTabStrip1.Tabs.Item(1).Enabled = True
            RadTabStrip1.Tabs.Item(2).Enabled = True
            'zembtnContinue.Enabled = True
            'govbtnContinue.Enabled = True
        End If
    End Sub


    Protected Function getcolor(typeid As Integer) As System.Drawing.Color
        Dim ret As System.Drawing.Color
        Select Case typeid
            Case 1
                ret = System.Drawing.Color.Red
            Case 2
                ret = System.Drawing.Color.Blue
            Case 3
                ret = System.Drawing.Color.Green
        End Select
        Return ret
    End Function

    Protected Function VaziyatSoudorColor(typeid As Integer) As System.Drawing.Color
        Dim ret As System.Drawing.Color
        Select Case typeid
            Case 1
                ret = System.Drawing.Color.Green
            Case 2
                ret = System.Drawing.Color.Red
        End Select
        Return ret
    End Function

    Protected Sub bindgrid()
        Dim strselect As String = "SELECT Users_table.Code,(Govahies.RowID) AS RowID, Govahies.Shomareh,Govahies.GovahiTypeID, Govahies.BankFullname, Govahies.LoanAmount, Govahies.MablaghKhalesDaryafti," _
                                & " Govahies.LoanOwner_FirstName, Govahies.LoanOwner_LastName, Govahies.LoanOwner_FatherName, Govahies.StateId, Govahies.DateOfCreate,Govahies.Vaziyat_Soudur,Govahies.Sader_Konandeh" _
                                & " FROM Users_table INNER JOIN Govahies ON Users_table.Code = Govahies.Code INNER JOIN Genders ON Users_table.GenderId = Genders.Genders_ID" _
                                & " where Users_table.Code=@Code  ORDER BY Govahies.DateOfCreate DESC"

        Dim Code As String = utill.Fa2En(lblcode.Text)
        Dim sum As Double = 0
        Dim totalRecord As Long = 0
        Dim TasviyehRecords As Long = 0
        Dim TotalActiveGovahiesAndZemanatnameh As Long = 0
        Dim NumberOfActiveZemanatnameh As Long = 0
        Dim NumberOfActiveGovahie As Long = 0
        Dim TotalActiveGovahie As Long = 0
        Dim TotalActiveZemanatnameh As Long = 0

        Using connection As New SqlConnection(utill.Connectionstring)
            Using command As New SqlCommand(strselect, connection)
                command.CommandType = CommandType.Text
                command.Parameters.Clear()
                command.Parameters.AddWithValue("@Code", Code)
                Using sda As New SqlDataAdapter(command)
                    Dim dt As New DataTable()
                    Try
                        dt.Clear()
                        sda.Fill(dt)
                        RadGrid1.DataSource = dt
                        RadGrid1.DataBind()
                    Catch ex As Exception
                        dt.Clear()
                        Throw
                    End Try

                    Try
                        totalRecord = CType(dt.Compute("Count(Code)", ""), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        totalRecord = 0
                    End Try

                    Try
                        TasviyehRecords = CType(dt.Compute("Count(Code)", "StateId=3"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        TasviyehRecords = 0
                    End Try
                    Try
                        TotalActiveGovahiesAndZemanatnameh = CType(dt.Compute("Count(Code)", "StateId=1"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        TotalActiveGovahiesAndZemanatnameh = 0
                    End Try

                    Try
                        NumberOfActiveGovahie = CType(dt.Compute("Count(Code)", "StateId=1 AND GovahiTypeID=1"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        NumberOfActiveGovahie = 0
                    End Try
                    Try
                        NumberOfActiveZemanatnameh = CType(dt.Compute("Count(Code)", "StateId=1 AND GovahiTypeID=2"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        NumberOfActiveZemanatnameh = 0
                    End Try

                    Try
                        sum = CType(dt.Compute("sum(LoanAmount)", "StateId=1"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        sum = 0
                    End Try

                    Try
                        TotalActiveGovahie = CType(dt.Compute("sum(LoanAmount)", "StateId=1 AND GovahiTypeID=1"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        TotalActiveGovahie = 0
                    End Try

                    Try
                        TotalActiveZemanatnameh = CType(dt.Compute("sum(LoanAmount)", "StateId=1 AND GovahiTypeID=2"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        TotalActiveZemanatnameh = 0
                    End Try
                End Using
            End Using
        End Using

        If sum = 0 Then
            ImageButton_Print_List.Visible = False
        Else
            ImageButton_Print_List.Visible = True
        End If
        lblNumberOfActiveGovahie.Text = "تعداد گواهی حقوقی فعال:" & " " & NumberOfActiveGovahie.ToString
        lblnumberofactivezemanatnameh.Text = "تعداد ضمانت نامه فعال:" & " " & NumberOfActiveZemanatnameh.ToString
        lblactive.Text = "تعداد کل گواهی حقوقی و ضمانت نامه های فعال:" & " " & TotalActiveGovahiesAndZemanatnameh.ToString
        lblTasviyeh.Text = "تعداد گواهی حقوقی و ضمانت نامه های تسویه شده:" & " " & TasviyehRecords.ToString
        lbltotal.Text = "تعداد کل گواهی حقوقی و ضمانت نامه ثبت شده(فعال و تسویه شده):" & " " & totalRecord.ToString

    End Sub

    Protected Sub btnExportToexcel_Click(sender As Object, e As ImageClickEventArgs) Handles btnExportToexcel.Click
        If RadGrid1.MasterTableView.Items.Count = 0 Then
            Return
        End If
        Dim Code As String = utill.Fa2En(lblcode.Text)
        RadGrid1.MasterTableView.GetColumn("chkRow").Visible = False
        bindgrid()
        RadGrid1.ExportSettings.Excel.Format = DirectCast([Enum].Parse(GetType(GridExcelExportFormat), "Xlsx"), GridExcelExportFormat)
        RadGrid1.ExportSettings.IgnorePaging = True
        RadGrid1.ExportSettings.ExportOnlyData = False
        RadGrid1.ExportSettings.OpenInNewWindow = True
        RadGrid1.ExportSettings.FileName = Code
        RadGrid1.MasterTableView.ExportToExcel()
    End Sub

    Protected Sub btnprint_Click(sender As Object, e As ImageClickEventArgs) Handles btnprint.Click
        Dim RowID As String = ""
        Dim Typeid As String = ""
        Dim StateId As String = ""
        Dim DateOfCreate As Date

        For Each dataItem As GridDataItem In RadGrid1.SelectedItems
            RowID = dataItem.GetDataKeyValue("RowID").ToString
            Typeid = dataItem.GetDataKeyValue("GovahiTypeID").ToString ' dataItem("GovahiTypeID").Text.ToString()
            StateId = dataItem.GetDataKeyValue("StateId").ToString
            DateOfCreate = CType(dataItem.GetDataKeyValue("DateOfCreate"), Date)
        Next
        Dim intsudormonth As Integer = utill.GetPersianMonth(DateOfCreate)
        Dim intcurrentMonth As Integer = utill.GetPersianMonth(Today)

        If intcurrentMonth <> intsudormonth Then
            itempnlmsg.Visible = True
            itemlblmsg.Text = "گواهی حقوقی و ضمانت نامه های که فعال (تسویه نشده) و تاریخ ثبت آنها در ماه جاری باشد قابلیت چاپ مجدد را دارند"
            Return
        End If

        If StateId.Trim = "2" OrElse StateId.Trim = "3" Then
            itempnlmsg.Visible = True
            itemlblmsg.Text = "گواهی حقوقی و ضمانت نامه های که فعال (تسویه نشده) و تاریخ ثبت آنها در ماه جاری باشد قابلیت چاپ مجدد را دارند"
            Return
        Else
            itempnlmsg.Visible = False
        End If
        If RowID.Trim = "" OrElse Typeid.Trim = "" OrElse StateId.Trim = "" Then
            Return
        End If
        Dim Code As String = utill.Fa2En(lblcode.Text)
        Session.Add("modirTypeid", Typeid)
        Session.Add("modirRowid", RowID)
        Session.Add("userCode", Code)

        Response.Redirect("./modirprint", True)

    End Sub

    Protected Sub ImageButton_Print_List_Click(sender As Object, e As ImageClickEventArgs) Handles ImageButton_Print_List.Click
        Dim Code As String = utill.Fa2En(lblcode.Text)
        Session.Add("userCode", Code)
        Response.Redirect("./modirprintactivelist", True)
    End Sub

    Protected Sub RadGrid1_ItemDataBound(sender As Object, e As GridItemEventArgs) Handles RadGrid1.ItemDataBound
        If (TypeOf e.Item Is GridDataItem) Then
            ' AndAlso e.Item.OwnerTableView.DataSource = "Sqldr"
            Dim lbl As Label = CType(e.Item.FindControl("Grid_RowNumber_Label"), Label)
            lbl.Text = (((e.Item.OwnerTableView.CurrentPageIndex * e.Item.OwnerTableView.PageSize) + (e.Item.ItemIndex + 1)).ToString())
            Dim refChk As CheckBox = DirectCast(e.Item.FindControl("chkRowSelectCheckBox"), CheckBox)
            ClientScript.RegisterArrayDeclaration("chk_Array_IDs", String.Concat("'", refChk.ClientID, "'"))
        End If
    End Sub
    Protected Sub RadGrid1_ColumnsReorder(sender As Object, e As GridColumnsReorderEventArgs) Handles RadGrid1.ColumnsReorder
        bindgrid()
    End Sub
    Protected Sub RadGrid1_PageIndexChanged(sender As Object, e As GridPageChangedEventArgs) Handles RadGrid1.PageIndexChanged ', RadGrid2.PageIndexChanged
        bindgrid()
    End Sub
    Protected Sub RadGrid1_PageSizeChanged(sender As Object, e As GridPageSizeChangedEventArgs) Handles RadGrid1.PageSizeChanged ', RadGrid2.PageSizeChanged
        bindgrid()
    End Sub
    Protected Sub RadGrid1_SortCommand(sender As Object, e As GridSortCommandEventArgs) Handles RadGrid1.SortCommand
        bindgrid()
    End Sub


    'System.Web.Script.Services.ScriptMethod(),

    <WebMethod()>
    Public Shared Function GetBankname(bankname As String) As List(Of String)
        Dim listbankname As New List(Of String)()
        listbankname.Clear()
        ' bankname = bankname.Replace("ي", "ی")
        Dim sqlSelectstring As String = String.Format("Select [BankFullName] FROM [Banks] WHERE [BankFullName] Like N'%{0}%'", bankname)
        Try
            Dim utill As New Utility
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(sqlSelectstring, connection)
                    command.CommandType = CommandType.Text
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        While reader.Read()
                            listbankname.Add(reader("Bankfullname").ToString)
                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception

        End Try
        Return listbankname
    End Function

    Protected Sub zembtnContinue_Click(sender As Object, e As EventArgs) Handles zembtnContinue.Click
        If Page.IsValid Then
            Dim Code As String = utill.Fa2En(lblcode.Text)
            Dim maxzemanat As Long = utill.Get_Khalesdaryafti_By_Code(Code:=code) * CType(utill.Get_Application_Settings(AppSettings.zarib.ToString), Long)
            Dim Sum_Of_Active_Govahies_And_Zemanatnameh As Long = utill.Get_Sum_Of_Active_Govahies_And_Zemanatnameh_By_Code(code)
            Dim mablaghmojaz As Long = maxzemanat - Sum_Of_Active_Govahies_And_Zemanatnameh
            Dim MablaghVam As Long = 0
            Dim blnerror As Boolean = False
            Try
                MablaghVam = CType(zemtxtmablaghvam.Text.Replace(",", "").Trim, Long)
            Catch ex As Exception
                blnerror = True
            End Try

            If zemtxtbankname.Text.Trim.Length > zemtxtbankname.MaxLength Then
                zemtxtbankname.Text = zemtxtbankname.Text.Substring(0, zemtxtbankname.MaxLength)
            End If

            If zemtxtfirstname.Text.Trim.Length > zemtxtfirstname.MaxLength Then
                zemtxtfirstname.Text = zemtxtfirstname.Text.Substring(0, zemtxtfirstname.MaxLength)
            End If

            If zemtxtlastname.Text.Trim.Length > zemtxtlastname.MaxLength Then
                zemtxtlastname.Text = zemtxtlastname.Text.Substring(0, zemtxtlastname.MaxLength)
            End If

            If zemtxtfathername.Text.Trim.Length > zemtxtfathername.MaxLength Then
                zemtxtfathername.Text = zemtxtfathername.Text.Substring(0, zemtxtfathername.MaxLength)
            End If

            If zemtxtmablaghvam.Text.Trim.Length > zemtxtmablaghvam.MaxLength Then
                zemtxtmablaghvam.Text = zemtxtmablaghvam.Text.Substring(0, zemtxtmablaghvam.MaxLength)
            End If


            If blnerror Then
                zemlblmsg.Text = "مبلغ وارد شده صحیح نیست"
                zempnlmsg.Visible = True
                zemtxtmablaghvam.Focus()
                Exit Sub
            Else
                zemlblmsg.Text = ""
                zempnlmsg.Visible = False
            End If
            If (CType(utill.Get_Application_Settings(AppSettings.mazad.ToString), Byte)) = 0 Then
                If MablaghVam > mablaghmojaz Then
                    zemlblmsg.Text = "مبلغ وارد شده بیشتر از مبلغ مجاز شما است"
                    zempnlmsg.Visible = True
                    zemtxtmablaghvam.Focus()
                    Exit Sub
                Else
                    zemlblmsg.Text = ""
                    zempnlmsg.Visible = False
                End If
            End If
            Dim rowid As String = ""
                If Not InsertNewZemanatRecord(rowid) Then
                    zemlblmsg.Text = "در ثبت اطلاعات شما خطای رخ داده است لطفا دوباره سعی کنید"
                    zempnlmsg.Visible = True
                    zemtxtmablaghvam.Focus()
                    Exit Sub
                Else
                    zemlblmsg.Text = ""
                    zempnlmsg.Visible = False
                End If
                Session.Add("modirTypeid", 2)
                Session.Add("modirRowid", rowid)
                Session.Add("userCode", Code)

                Response.Redirect("./modirprint", True)
            End If
    End Sub


    Protected Sub govbtnContinue_Click(sender As Object, e As EventArgs) Handles govbtnContinue.Click
        If Page.IsValid Then

            Dim Code As String = utill.Fa2En(lblcode.Text)
            Dim maxzemanat As Long = utill.Get_Khalesdaryafti_By_Code(Code:=code) * CType(utill.Get_Application_Settings(AppSettings.zarib.ToString), Long)
            Dim Sum_Of_Active_Govahies_And_Zemanatnameh As Long = utill.Get_Sum_Of_Active_Govahies_And_Zemanatnameh_By_Code(code)
            Dim mablaghmojaz As Long = maxzemanat - Sum_Of_Active_Govahies_And_Zemanatnameh
            Dim MablaghVam As Long = 0
            Dim blnerror As Boolean = False
            Try
                MablaghVam = CType(govtxtmablaghvam.Text.Replace(",", "").Trim, Long)
            Catch ex As Exception
                blnerror = True
            End Try
            If blnerror Then
                govlblmsg.Text = "مبلغ وارد شده صحیح نیست"
                govpnlmsg.Visible = True
                govtxtmablaghvam.Focus()
                Exit Sub
            Else
                govlblmsg.Text = ""
                govpnlmsg.Visible = False
            End If
            If (CType(utill.Get_Application_Settings(AppSettings.mazad.ToString), Byte)) = 0 Then
                If MablaghVam > mablaghmojaz Then
                    govlblmsg.Text = "مبلغ وارد شده بیشتر از مبلغ مجاز شما است"
                    govpnlmsg.Visible = True
                    govtxtmablaghvam.Focus()
                    Exit Sub
                Else
                    govlblmsg.Text = ""
                    govpnlmsg.Visible = False
                End If
            End If
            If govtxtbankname.Text.Trim.Length > govtxtbankname.MaxLength Then
                govtxtbankname.Text = govtxtbankname.Text.Substring(0, govtxtbankname.MaxLength)
            End If

            If govtxtmablaghvam.Text.Trim.Length > govtxtmablaghvam.MaxLength Then
                govtxtmablaghvam.Text = govtxtmablaghvam.Text.Substring(0, govtxtmablaghvam.MaxLength)
            End If

            Dim rowid As String = ""
            If Not InsertNewGovahieRecord(rowid) Then
                zemlblmsg.Text = "در ثبت اطلاعات شما خطای رخ داده است لطفا دوباره سعی کنید"
                zempnlmsg.Visible = True
                zemtxtmablaghvam.Focus()
                Exit Sub
            Else
                zemlblmsg.Text = ""
                zempnlmsg.Visible = False
            End If
            Session.Add("modirTypeid", 1)
            Session.Add("modirRowid", rowid)
            Session.Add("userCode", Code)

            Response.Redirect("./modirprint", True)
        End If
    End Sub

    Private Function InsertNewGovahieRecord(ByRef rowid As String) As Boolean
        Dim ReturnValue As Boolean = False
        Dim Code As String = utill.Fa2En(lblcode.Text)
        Dim insertstring As String = "INSERT INTO [Govahies] ([Shomareh], [code], [GovahiTypeID], [BankFullname], [LoanAmount], [MablaghKhalesDaryafti],[StateId],[Vaziyat_Soudur],[Sader_Konandeh])" _
                & " VALUES (@Shomareh,@Code,@GovahiTypeID,@BankFullname,@LoanAmount,@MablaghKhalesDaryafti,/*StateId=*/ 1,@Vaziyat_Soudur,@Sader_Konandeh)"
        Dim shomareh As Long = utill.Get_Latest_Shomareh() + 1
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(insertstring, connection)
                    Dim adminmember As New AdminMembership()
                    command.CommandType = CommandType.Text
                    connection.Open()
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Shomareh", shomareh)
                    command.Parameters.AddWithValue("@Code", Code)
                    command.Parameters.AddWithValue("@GovahiTypeID", 1)
                    command.Parameters.AddWithValue("@BankFullname", govtxtbankname.Text.Trim)
                    command.Parameters.AddWithValue("@LoanAmount", CType(govtxtmablaghvam.Text.Replace(",", "").Trim, Long))
                    command.Parameters.AddWithValue("@MablaghKhalesDaryafti", utill.Get_Khalesdaryafti_By_Code(Code))
                    command.Parameters.AddWithValue("@Vaziyat_Soudur", utill.Vaziyat_Soudur(Code))
                    command.Parameters.AddWithValue("@Sader_Konandeh", adminmember.GetAdminFullname(HttpContext.Current.User.Identity.Name))

                    command.ExecuteNonQuery()
                End Using
            End Using
            ReturnValue = True
        Catch ex As Exception
            utill.RegisterError(ex.Message, "صدرو گواهی حقوقی - درج گواهی حقوقی", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            ReturnValue = False
        End Try
        If ReturnValue = True Then
            rowid = utill.Get_Last_Saved_RowID_By_Code(code)
            utill.Set_Shomareh(shomareh:=shomareh)
            utill.Set_RowValidationCode_For_Govaheis_Table_By_RowID(rowid)
            utill.Set_Number_Of_Active_Govahie_By_Code(code)
        End If
        Return ReturnValue
    End Function
    Private Function InsertNewZemanatRecord(ByRef rowid As String) As Boolean
        Dim ReturnValue As Boolean = False
        Dim Code As String = utill.Fa2En(lblcode.Text)
        Dim insertstring As String = "INSERT INTO [Govahies] ([Shomareh], [code], [GovahiTypeID], [BankFullname], [LoanAmount], [MablaghKhalesDaryafti], [LoanOwner_FirstName], [LoanOwner_LastName], [LoanOwner_FatherName], [StateId],[Vaziyat_Soudur],[Sader_Konandeh])" _
                & " VALUES (@Shomareh,@Code,@GovahiTypeID,@BankFullname,@LoanAmount,@MablaghKhalesDaryafti,@LoanOwner_FirstName,@LoanOwner_LastName,@LoanOwner_FatherName,/*StateId=*/ 1,@Vaziyat_Soudur,@Sader_Konandeh)"
        Dim shomareh As Long = utill.Get_Latest_Shomareh() + 1
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(insertstring, connection)
                    Dim adminmember As New AdminMembership()
                    command.CommandType = CommandType.Text
                    connection.Open()
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Shomareh", shomareh)
                    command.Parameters.AddWithValue("@Code", Code)
                    command.Parameters.AddWithValue("@GovahiTypeID", 2)
                    command.Parameters.AddWithValue("@BankFullname", zemtxtbankname.Text.Trim)
                    command.Parameters.AddWithValue("@LoanAmount", CType(zemtxtmablaghvam.Text.Replace(",", "").Trim, Long))
                    command.Parameters.AddWithValue("@MablaghKhalesDaryafti", utill.Get_Khalesdaryafti_By_Code(Code))
                    command.Parameters.AddWithValue("@LoanOwner_FirstName", zemtxtfirstname.Text.Trim)
                    command.Parameters.AddWithValue("@LoanOwner_LastName", zemtxtlastname.Text.Trim)
                    command.Parameters.AddWithValue("@LoanOwner_FatherName", zemtxtfathername.Text.Trim)
                    command.Parameters.AddWithValue("@Vaziyat_Soudur", utill.Vaziyat_Soudur(Code))
                    command.Parameters.AddWithValue("@Sader_Konandeh", adminmember.GetAdminFullname(HttpContext.Current.User.Identity.Name))

                    command.ExecuteNonQuery()
                End Using
            End Using
            ReturnValue = True
        Catch ex As Exception
            utill.RegisterError(ex.Message, "صدرو ضمانت نامه - درج ضمانت نامه", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            ReturnValue = False
        End Try
        If ReturnValue = True Then
            rowid = utill.Get_Last_Saved_RowID_By_Code(Code)
            utill.Set_Shomareh(shomareh:=shomareh)
            utill.Set_RowValidationCode_For_Govaheis_Table_By_RowID(rowid)
            utill.Set_Number_Of_Active_Govahie_By_Code(Code)
        End If
        Return ReturnValue
    End Function
End Class