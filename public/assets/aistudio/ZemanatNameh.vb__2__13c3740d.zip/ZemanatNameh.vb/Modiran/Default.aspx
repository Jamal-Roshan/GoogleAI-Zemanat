﻿<%@ Page Title="صفحه اصلی مدیریت سایت" Language="vb" AutoEventWireup="false" MasterPageFile="~/modiran/ModirMasterPage.Master" CodeBehind="Default.aspx.vb" Inherits="ZemanatNameh.vb._Default1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style type="text/css">
        .pics {
            width: 40%;
            margin: 0 auto;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class=" container">
        <div class="row" id="Dashbord" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; padding-top: 8px; background-color: whitesmoke">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-center ">
                <div class="panel">
                    <div class="panel-body">
                        <a href="./new">
                            <img alt="صدور گواهی و ضمانت نامه" class="img-responsive pics" src="./Modiran/Images/Dashboard/new.png" />
                            <div class="text-center">صدور گواهی و ضمانت نامه</div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-center ">
                <div class="panel">
                    <div class="panel-body">
                        <a href="./estelam">
                            <img alt="صدور استعلام" class="img-responsive pics" src="./Modiran/Images/Dashboard/check-mark.png" />
                            <div class="text-center">صدور استعلام</div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-center ">
                <div class="panel">
                    <div class="panel-body">
                        <a href="./viewestelam">
                            <img alt="مشاهده استعلام" class="img-responsive pics " src="./Modiran/Images/Dashboard/worker.png" />
                            <div class="text-center">مشاهده استعلام های صادر شده</div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-center ">
                <div class="panel">
                    <div class="panel-body">
                        <a href="./block">
                            <img alt="مسدود کردن کاربر" class="img-responsive pics" src="./Modiran/Images/Dashboard/block_user.png" />
                            <div class="text-center">مسدود کردن کاربر</div>
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-center ">
                <div class="panel">
                    <div class="panel-body">
                        <a href="./resetuserpass">
                            <img alt="ریست رمز کاربران" class="img-responsive pics" src="./Modiran/Images/Dashboard/Reset_Password.png" />
                            <div class="text-center">ریست رمز کاربران</div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-center ">
                <div class="panel">
                    <div class="panel-body">
                        <a href="./govahi">
                            <img alt="مشاهده ضمانت نامه ها ی ثبت شده" class="img-responsive pics" src="./Modiran/Images/Dashboard/books.png" />
                            <div class="text-center">مشاهده و تسویه ضمانت نامه ها ی ثبت شده</div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-center ">
                <div class="panel">
                    <div class="panel-body">
                        <a href="./list">
                            <img alt="مشاهده لیست کاربران" class="img-responsive pics" src="./Modiran/Images/Dashboard/List.png" />
                            <div class="text-center">مشاهده لیست کاربران</div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 text-center ">
                <div class="panel">
                    <div class="panel-body">
                        <a href="./upload">
                            <img alt="بارگذاری اطلاعات ماهانه پرسنل" class="img-responsive pics" src="./Modiran/Images/Dashboard/office-material.png" />
                            <div class="text-center">بارگذاری اطلاعات ماهانه پرسنل</div>
                        </a>
                    </div>
                </div>
            </div>


        </div>
        <div class="row" id="Status" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="padding-top: 10px">
                <div class="panel panel-primary">
                    <div class="panel-heading text-center" style="padding: 10px; margin: 0px">
                        <h1 style="font-size: 1.1em; padding: 0px; margin: 0px">وضعیت جاری سایت</h1>
                    </div>
                    <div class="panel-body" style="padding: 10px 20px 10px 20px">
                        <label>وضعیت جاری سایت: </label>
                        <asp:Label Text="" ForeColor="green" runat="server" ID="lblstatus" />
                        <p />
                        <div class="text-center">
                            <asp:Button Text="تغییر وضعیت" runat="server" ID="btnchangestatus" CssClass="btn btn-primary" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">
</asp:Content>
