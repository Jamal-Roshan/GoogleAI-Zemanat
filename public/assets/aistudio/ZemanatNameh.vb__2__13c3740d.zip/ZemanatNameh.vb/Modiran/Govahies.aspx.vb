﻿Imports System.Data.SqlClient
Imports Telerik.Web.UI
Public Class Govahies
    Inherits System.Web.UI.Page
    Public utill As New Utility
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Me.Page.IsPostBack Then
            If RadGrid1.MasterTableView.Items.Count = 0 Then

                pnlgrid.Visible = False
                btnExportToexcel.Visible = False
                btntasviyeh.Visible = False
                pnlname.Visible = False
                pnlinfo.Visible = False
            Else
                pnlmsg.Visible = False
                pnlgrid.Visible = True
                btnExportToexcel.Visible = True
                btntasviyeh.Visible = True
                pnlname.Visible = True
                '    pnlinfo.Visible = True
            End If
        End If
    End Sub
    Protected Sub RadGrid1_ItemDataBound(sender As Object, e As Telerik.Web.UI.GridItemEventArgs) Handles RadGrid1.ItemDataBound
        If (TypeOf e.Item Is GridDataItem) Then
            ' AndAlso e.Item.OwnerTableView.DataSource = "Sqldr"
            Dim lbl As Label = CType(e.Item.FindControl("Grid_RowNumber_Label"), Label)
            lbl.Text = (((e.Item.OwnerTableView.CurrentPageIndex * e.Item.OwnerTableView.PageSize) + (e.Item.ItemIndex + 1)).ToString())
            Dim refChk As CheckBox = DirectCast(e.Item.FindControl("chkRowSelectCheckBox"), CheckBox)
            ClientScript.RegisterArrayDeclaration("chk_Array_IDs", String.Concat("'", refChk.ClientID, "'"))
        End If
    End Sub

    Protected Sub btnfilter_Click(sender As Object, e As EventArgs) Handles btnfilter.Click
        bindgrid()
        If RadGrid1.MasterTableView.Items.Count = 0 Then
            pnlmsg.Visible = True
            pnlgrid.Visible = False
            btnExportToexcel.Visible = False
            btntasviyeh.Visible = False
            pnlname.Visible = False
            pnlinfo.Visible = False
        Else
            pnlmsg.Visible = False
            pnlgrid.Visible = True
            btnExportToexcel.Visible = True
            btntasviyeh.Visible = True
            pnlname.Visible = True
            '    pnlinfo.Visible = True
        End If
    End Sub

    Protected Sub btnclearfilter_Click(sender As Object, e As EventArgs) Handles btnclearfilter.Click
        txtcode.Text = ""
        txtnid.Text = ""
        RadGrid1.DataBind()
        lblsum.Text = ""
        lblTotalActiveGovahie.Text = ""
        lblTotalActiveZemanatnameh.Text = ""
        lblTotalActiveZemanatnameh.Text = ""
        lblfullname.Text = ""
        lblfather.Text = ""
        btntasviyeh.Visible = False
        btnExportToexcel.Visible = False
        pnlname.Visible = False
        pnlinfo.Visible = False
        pnlgrid.Visible = False
        pnlmsg.Visible = False

    End Sub
    Protected Function getcolor(typeid As Integer) As System.Drawing.Color
        Dim ret As System.Drawing.Color
        Select Case typeid
            Case 1
                ret = System.Drawing.Color.Red
            Case 2
                ret = System.Drawing.Color.Blue
            Case 3
                ret = System.Drawing.Color.Green
        End Select
        Return ret
    End Function
    Protected Sub bindgrid()
        Dim strCondition As String = ""
        Dim code = utill.Fa2En(txtcode.Text.Trim)
        Dim NID = utill.Fa2En(txtnid.Text.Trim)
        If code.Length > 0 Then
            strCondition = "Users_table.Code=@code"
        End If
        If NID.Length > 0 Then
            strCondition = "Users_table.NationalID=@nid"
        End If
        If code.Length = 0 AndAlso NID.Length = 0 Then
            Exit Sub
        End If
        Dim strselect As String = "SELECT Govahies.[RowID] , Users_table.Code,Users_table.NationalID,  Users_table.Firstname,  Users_table.Lastname,  Users_table.Fathername,  Govahies.Shomareh," _
                                & " Govahies.GovahiTypeID,  Govahies.BankFullname, Govahies.LoanAmount,  Govahies.MablaghKhalesDaryafti,  Govahies.LoanOwner_FirstName,  Govahies.LoanOwner_LastName," _
                                & " Govahies.LoanOwner_FatherName,  Govahies.StateId, Govahies.DateOfCreate,Govahies.Tasviyehby,(isnull(Govahies.TasviyehDate,0)) as TasviyehDate " _
                                & " FROM  Users_table INNER JOIN Govahies ON  Users_table.Code =  Govahies.Code " _
                                & "where " & strCondition & " ORDER BY Govahies.DateOfCreate DESC"
        Dim sum As Double = 0
        Dim totalRecord As Long = 0
        Dim TasviyehRecords As Long = 0
        Dim TotalActiveGovahiesAndZemanatnameh As Long = 0
        Dim NumberOfActiveZemanatnameh As Long = 0
        Dim NumberOfActiveGovahie As Long = 0
        Dim TotalActiveGovahie As Long = 0
        Dim TotalActiveZemanatnameh As Long = 0

        Using connection As New SqlConnection(utill.Connectionstring)
            Using command As New SqlCommand(strselect, connection)
                command.CommandType = CommandType.Text
                command.Parameters.Clear()

                If code.Length > 0 Then
                    command.Parameters.AddWithValue("@Code", code)
                End If
                If NID.Length > 0 Then
                    command.Parameters.AddWithValue("@nid", NID)
                End If
                Using sda As New SqlDataAdapter(command)
                    Dim dt As New DataTable()
                    Try
                        dt.Clear()
                        sda.Fill(dt)
                        RadGrid1.DataSource = dt
                        RadGrid1.DataBind()
                    Catch ex As Exception
                        dt.Clear()
                        Return
                    End Try


                    Try
                        lblfullname.Text = ""
                        lblfather.Text = ""
                        lblfullname.Text = dt.Rows(0).Item("Firstname").ToString & " " & dt.Rows(0).Item("Lastname").ToString
                        lblfather.Text = dt.Rows(0).Item("Fathername").ToString
                    Catch ex As Exception
                        lblfullname.Text = ""
                        lblfather.Text = ""
                        Server.ClearError()
                    End Try

                    Try
                        totalRecord = CType(dt.Compute("Count(Code)", ""), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        totalRecord = 0
                    End Try

                    Try
                        TasviyehRecords = CType(dt.Compute("Count(Code)", "StateId=3"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        TasviyehRecords = 0
                    End Try
                    Try
                        TotalActiveGovahiesAndZemanatnameh = CType(dt.Compute("Count(Code)", "StateId=1"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        TotalActiveGovahiesAndZemanatnameh = 0
                    End Try

                    Try
                        NumberOfActiveGovahie = CType(dt.Compute("Count(Code)", "StateId=1 AND GovahiTypeID=1"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        NumberOfActiveGovahie = 0
                    End Try
                    Try
                        NumberOfActiveZemanatnameh = CType(dt.Compute("Count(Code)", "StateId=1 AND GovahiTypeID=2"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        NumberOfActiveZemanatnameh = 0
                    End Try

                    Try
                        sum = CType(dt.Compute("sum(LoanAmount)", "StateId=1"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        sum = 0
                    End Try

                    Try
                        TotalActiveGovahie = CType(dt.Compute("sum(LoanAmount)", "StateId=1 AND GovahiTypeID=1"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        TotalActiveGovahie = 0
                    End Try

                    Try
                        TotalActiveZemanatnameh = CType(dt.Compute("sum(LoanAmount)", "StateId=1 AND GovahiTypeID=2"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        TotalActiveZemanatnameh = 0
                    End Try
                End Using
            End Using
        End Using



        If sum > 0 Then
            pnlinfo.Visible = True
            btntasviyeh.Visible = True
            lblTotalActiveGovahie.Text = "مجموع مبالغ گواهی حقوقی تسویه نشده : " & utill.En2Fa(TotalActiveGovahie.ToString("#,##0"))
            lblTotalActiveZemanatnameh.Text = "مجموع مبالغ ضمانت نامه تسویه نشده : " & utill.En2Fa(TotalActiveZemanatnameh.ToString("#,##0"))
            lblsum.Text = "مجموع مبالغ تسویه نشده : " & utill.En2Fa(sum.ToString("#,##0"))
        Else
            pnlinfo.Visible = False
            btntasviyeh.Visible = False
            lblsum.Text = ""
            lblTotalActiveGovahie.Text = ""
            lblTotalActiveZemanatnameh.Text = ""
        End If
        lblNumberOfActiveGovahie.Text = "تعداد گواهی حقوقی فعال:" & " " & NumberOfActiveGovahie.ToString
        lblNumberOfActiveZemanatnameh.Text = "تعداد ضمانت نامه فعال:" & " " & NumberOfActiveZemanatnameh.ToString
        lblactive.Text = "تعداد کل گواهی حقوقی و ضمانت نامه های فعال:" & " " & TotalActiveGovahiesAndZemanatnameh.ToString
        lblTasviyeh.Text = "تعداد گواهی حقوقی و ضمانت نامه های تسویه شده:" & " " & TasviyehRecords.ToString
        lbltotal.Text = "تعداد کل گواهی حقوقی و ضمانت نامه ثبت شده(فعال و تسویه شده):" & " " & totalRecord.ToString

    End Sub

    Protected Sub btntasviyeh_Click(sender As Object, e As EventArgs) Handles btntasviyeh.Click
        Dim strIDs As String = ""
        Dim code = utill.Fa2En(txtcode.Text.Trim)
        For Each dataItem As GridDataItem In RadGrid1.SelectedItems
            strIDs += dataItem.GetDataKeyValue("RowID").ToString & ","
        Next
        Dim keys As String = ""
        Dim returnmsg As String = ""
        If strIDs.Length > 0 Then
            keys = strIDs.Substring(0, strIDs.LastIndexOf(","))
            Dim strRowIDs() As String = keys.Split(","c)
            Dim m As New AdminMembership()
            For Each rowid As String In strRowIDs
                utill.Tasviyeh(rowid, m.GetAdminFullname(HttpContext.Current.User.Identity.Name))
                utill.Set_RowValidationCode_For_Govaheis_Table_By_RowID(rowid)
                utill.Set_Number_Of_Active_Govahie_By_Code(code)
            Next
        End If
        bindgrid()
    End Sub

    Protected Sub btnExportToexcel_Click(sender As Object, e As ImageClickEventArgs) Handles btnExportToexcel.Click
        If RadGrid1.MasterTableView.Items.Count = 0 Then
            Return
        End If
        RadGrid1.MasterTableView.GetColumn("chkRow").Visible = False
        RadGrid1.MasterTableView.GetColumn("firstname").Display = True
        RadGrid1.MasterTableView.GetColumn("lastname").Display = True
        RadGrid1.MasterTableView.GetColumn("father").Display = True
        bindgrid()


        RadGrid1.ExportSettings.Excel.Format = DirectCast([Enum].Parse(GetType(GridExcelExportFormat), "Xlsx"), GridExcelExportFormat)
        RadGrid1.ExportSettings.IgnorePaging = True
        RadGrid1.ExportSettings.ExportOnlyData = False
        RadGrid1.ExportSettings.OpenInNewWindow = True
        RadGrid1.ExportSettings.FileName = "Govahies"
        RadGrid1.MasterTableView.ExportToExcel()

        'RadGrid1.MasterTableView.GetColumn("firstname").Display = False
        'RadGrid1.MasterTableView.GetColumn("lastname").Display = False
        'RadGrid1.MasterTableView.GetColumn("father").Display = False
        '  RadGrid1.MasterTableView.GetColumn("chkRow").Visible = True
    End Sub
    Protected Sub RadGrid1_GroupsChanging(sender As Object, e As GridGroupsChangingEventArgs) Handles RadGrid1.GroupsChanging
        bindgrid()
    End Sub
    Protected Sub RadGrid1_ColumnsReorder(sender As Object, e As GridColumnsReorderEventArgs) Handles RadGrid1.ColumnsReorder
        bindgrid()
    End Sub
    Protected Sub RadGrid1_PageIndexChanged(sender As Object, e As GridPageChangedEventArgs) Handles RadGrid1.PageIndexChanged ', RadGrid2.PageIndexChanged
        bindgrid()
    End Sub
    Protected Sub RadGrid1_PageSizeChanged(sender As Object, e As GridPageSizeChangedEventArgs) Handles RadGrid1.PageSizeChanged ', RadGrid2.PageSizeChanged
        bindgrid()
    End Sub
    Protected Sub RadGrid1_SortCommand(sender As Object, e As GridSortCommandEventArgs) Handles RadGrid1.SortCommand
        bindgrid()
    End Sub

End Class