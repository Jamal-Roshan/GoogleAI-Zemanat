﻿Imports System.Data.SqlClient
Imports Telerik.Web.UI
Public Class UsersList
    Inherits System.Web.UI.Page
    Public utill As New Utility
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Me.Page.IsPostBack Then
            bindgrid()

            If RadGrid1.MasterTableView.Items.Count = 0 Then

                btnExportToexcel.Visible = False
                pnlgrid.Visible = False
                pnlmsg.Visible = True
                btnExportToexcel.Visible = False
            Else

                btnExportToexcel.Visible = True
                pnlgrid.Visible = True
                pnlmsg.Visible = False
                btnExportToexcel.Visible = True
            End If
        End If
    End Sub
    Protected Sub RadGrid1_ItemDataBound(sender As Object, e As Telerik.Web.UI.GridItemEventArgs) Handles RadGrid1.ItemDataBound
        If (TypeOf e.Item Is GridDataItem) Then
            ' AndAlso e.Item.OwnerTableView.DataSource = "Sqldr"
            Dim lbl As Label = CType(e.Item.FindControl("Grid_RowNumber_Label"), Label)
            lbl.Text = utill.En2Fa(((e.Item.OwnerTableView.CurrentPageIndex * e.Item.OwnerTableView.PageSize) + (e.Item.ItemIndex + 1)).ToString())
        End If
    End Sub
    Protected Function GetBlockStatus(isblock As Boolean) As String
        Dim ret As String = String.Empty
        Select Case isblock
            Case False
                ret = "مسدود نیست"
            Case True
                ret = "مسدود است"
        End Select
        Return ret
    End Function
    Protected Function Eshteghal(_ID As Byte) As String
        Return utill.Get_EshteghalType_By_EshteghalID(_ID)
    End Function

    Protected Function KhalesDryafti(mablagh As Long) As String
        Return mablagh.ToString("#,##0")
    End Function
    Protected Function getcolor(isblock As Boolean) As System.Drawing.Color
        Dim ret As System.Drawing.Color
        Select Case isblock
            Case False
                ret = System.Drawing.Color.Green
            Case True
                ret = System.Drawing.Color.Red
        End Select
        Return ret
    End Function

    Protected Sub btnfilter_Click(sender As Object, e As EventArgs) Handles btnfilter.Click
        bindgrid()
        If RadGrid1.MasterTableView.Items.Count = 0 Then
            pnlmsg.Visible = True
            pnlgrid.Visible = False
            btnExportToexcel.Visible = False
        Else
            pnlmsg.Visible = False
            pnlgrid.Visible = True
            btnExportToexcel.Visible = True
        End If
    End Sub

    Protected Sub btnclearfilter_Click(sender As Object, e As EventArgs) Handles btnclearfilter.Click
        txtcode.Text = ""
        txtfirstname.Text = ""
        txtlastname.Text = ""
        Response.Redirect("./list", True)
    End Sub

    Protected Sub btnExportToexcel_Click(sender As Object, e As ImageClickEventArgs) Handles btnExportToexcel.Click
        If RadGrid1.MasterTableView.Items.Count = 0 Then
            Return
        End If
        bindgrid(True)
        RadGrid1.MasterTableView.GetColumn("radif").Visible = False
        RadGrid1.ExportSettings.Excel.Format = DirectCast([Enum].Parse(GetType(GridExcelExportFormat), "Xlsx"), GridExcelExportFormat)
        RadGrid1.ExportSettings.IgnorePaging = True
        RadGrid1.ExportSettings.OpenInNewWindow = True
        RadGrid1.ExportSettings.FileName = "Users_List"
        RadGrid1.MasterTableView.ExportToExcel()

    End Sub

    Protected Sub bindgrid(Optional justbind As Boolean = False)
        Dim strfilter As String = ""
        Dim code = utill.Fa2En(txtcode.Text.Trim)

        If code.Length > 0 Then
            strfilter = String.Format(" {0} Code Like N'%{1}%'", strfilter, code)
            If txtfirstname.Text.Trim.Length > 0 OrElse txtlastname.Text.Trim.Length > 0 Then
                strfilter += " AND "
            End If
        End If
        If txtfirstname.Text.Trim.Length > 0 Then
            strfilter = String.Format(" {0} Firstname Like N'%{1}%'", strfilter, txtfirstname.Text.Trim)
            If txtlastname.Text.Trim.Length > 0 Then
                strfilter += " AND "
            End If
        End If
        If txtlastname.Text.Trim.Length > 0 Then

            strfilter = String.Format(" {0} Lastname Like N'%{1}%'", strfilter, txtlastname.Text.Trim)
        End If
        Dim strselect As String = ""
        If strfilter.Length > 0 Then
            strselect = "SELECT  [Code],[NationalID],  [Firstname], [Lastname], [Fathername], [EshteghalID], [WorkPlace], [MablaghKhales], [AccountNumber], 
                [IsBlock], [NumberOfActiveGovahi] FROM [Users_table] WHERE (" & strfilter & ") ORDER BY [Lastname],[Firstname],[Fathername]"
        Else
            strselect = "SELECT  [Code],[NationalID],  [Firstname], [Lastname], [Fathername], [EshteghalID], [WorkPlace], [MablaghKhales], [AccountNumber], 
                [IsBlock], [NumberOfActiveGovahi] FROM [Users_table]   ORDER BY [Lastname],[Firstname],[Fathername]"
        End If
        If justbind Then
            strselect = "SELECT  [Code],[NationalID],  [Firstname], [Lastname], [Fathername], [EshteghalID], [WorkPlace], [MablaghKhales], [AccountNumber], 
                [IsBlock], [NumberOfActiveGovahi] FROM [Users_table]   ORDER BY [Lastname],[Firstname],[Fathername]"
        End If

        Using connection As New SqlConnection(utill.Connectionstring)
            Using command As New SqlCommand(strselect, connection)
                command.CommandType = CommandType.Text
                command.Parameters.Clear()
                Using sda As New SqlDataAdapter(command)
                    Dim dt As New DataTable()
                    Try
                        dt.Clear()
                        sda.Fill(dt)
                        RadGrid1.DataSource = dt
                        RadGrid1.DataBind()
                    Catch ex As Exception
                        'Throw
                    End Try
                End Using
            End Using
        End Using
    End Sub
    Protected Sub RadGrid1_GroupsChanging(sender As Object, e As GridGroupsChangingEventArgs) Handles RadGrid1.GroupsChanging
        bindgrid()
    End Sub
    Protected Sub RadGrid1_ColumnsReorder(sender As Object, e As GridColumnsReorderEventArgs) Handles RadGrid1.ColumnsReorder
        bindgrid()
    End Sub
    Protected Sub RadGrid1_PageIndexChanged(sender As Object, e As GridPageChangedEventArgs) Handles RadGrid1.PageIndexChanged ', RadGrid2.PageIndexChanged
        bindgrid()
    End Sub
    Protected Sub RadGrid1_PageSizeChanged(sender As Object, e As GridPageSizeChangedEventArgs) Handles RadGrid1.PageSizeChanged ', RadGrid2.PageSizeChanged
        bindgrid()
    End Sub
    Protected Sub RadGrid1_SortCommand(sender As Object, e As GridSortCommandEventArgs) Handles RadGrid1.SortCommand
        bindgrid()
    End Sub
    'Protected Sub justbind()
    '    Dim strselect As String = ""
    '    strselect = "SELECT  [Code],[NationalID],  [Firstname], [Lastname], [Fathername], [EshteghalID], [WorkPlace], [MablaghKhales], [AccountNumber], 
    '            [IsBlock], [NumberOfActiveGovahi] FROM [Users_table]   ORDER BY [Lastname],[Firstname],[Fathername]"
    '    Using connection As New SqlConnection(utill.Connectionstring)
    '        Using command As New SqlCommand(strselect, connection)
    '            command.CommandType = CommandType.Text
    '            command.Parameters.Clear()
    '            Using sda As New SqlDataAdapter(command)
    '                Dim dt As New DataTable()
    '                Try
    '                    dt.Clear()
    '                    sda.Fill(dt)
    '                    RadGrid1.DataSource = dt
    '                    RadGrid1.DataBind()
    '                Catch ex As Exception
    '                    Throw
    '                End Try
    '            End Using
    '        End Using
    '    End Using
    'End Sub
End Class