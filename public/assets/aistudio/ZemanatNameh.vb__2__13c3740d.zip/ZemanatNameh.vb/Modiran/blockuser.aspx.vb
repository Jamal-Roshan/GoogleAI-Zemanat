﻿Public Class blockuser
    Inherits System.Web.UI.Page
    Private Utill As New Utility()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        If Me.Page.IsValid Then
            Dim code = Utill.Fa2En(txtcode.Text.Trim)
            If Not Utill.UserExist(code) Then
                lblmsg.Text = "کاربری با این شماره پرسنلی موجود نیست"
                lblmsg.Visible = True
                lblvaziyat.Text = ""
                pnlstatus.Visible = False
                Return
            End If
            Dim m As New UserMembership
            lblfullname.Text = m.GetUserFullname(code)
            If Not Utill.IsBlockedUser(code) Then
                lblmsg.Visible = False
                pnlstatus.Visible = True
                chkblock.Checked = False
                lblvaziyat.ForeColor = Drawing.Color.Green
                lblvaziyat.Text = "کاربر مسدود نیست"
                txtdalilmasdoodi.Text = Utill.GetBlockResone(code)
            Else
                lblmsg.Visible = False
                pnlstatus.Visible = True
                chkblock.Checked = True
                lblvaziyat.ForeColor = Drawing.Color.Red
                lblvaziyat.Text = "کاربر مسدود است"
                txtdalilmasdoodi.Text = Utill.GetBlockResone(code)
            End If
        End If
    End Sub

    Protected Sub btnsabt_Click(sender As Object, e As EventArgs) Handles btnsabt.Click
        Dim code = Utill.Fa2En(txtcode.Text.Trim)
        If Utill.SetBlockStatus(code, chkblock.Checked) Then
            If Utill.SetBlockResone(code, txtdalilmasdoodi.Text.Trim) Then
                If chkblock.Checked Then
                    lblmsg.Text = "وضعیت فرد با شماره پرسنلی وارد شده مسدود شد"
                Else
                    lblmsg.Text = "فرد با شماره پرسنلی وارد شده از حالت انسداد خارج شد"
                End If

                lblmsg.Visible = True
                Utill.Set_Number_Of_Active_Govahie_By_Code(code)
            Else
                lblmsg.Text = "در ثبت دلیل انسداد خطا رخ داده است"
                lblmsg.Visible = True
            End If
        Else
            lblmsg.Text = "در فرایند تغییر وضعیت مسدودی خطا رخ داده است"
            lblmsg.Visible = True
        End If
        lblfullname.Text = ""
        pnlstatus.Visible = False
        lblvaziyat.Text = ""
        chkblock.Checked = False
        txtcode.Text = ""
        txtdalilmasdoodi.Text = ""
    End Sub
    Protected Sub btnreset_Click(sender As Object, e As EventArgs) Handles btnreset.Click
        lblfullname.Text = ""
        lblmsg.Visible = False
        lblmsg.Text = ""
        pnlstatus.Visible = False
        lblvaziyat.Text = ""
        chkblock.Checked = False
        txtcode.Text = ""
        txtdalilmasdoodi.Text = ""
    End Sub
End Class