﻿<%@ Page Title="تغییر کلمه عبور" Language="vb" AutoEventWireup="false" MasterPageFile="~/modiran/ModirMasterPage.Master" CodeBehind="ChangeModiranPassword.aspx.vb" Inherits="ZemanatNameh.vb.ChangePassword1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style type="text/css">
        .panel {
            margin-bottom: 10px;
            border-color: rgba(128, 120, 128, 0.53);
        }

        .panel-body {
            background-color: rgba(222, 217, 217, 0.5);
        }

        .RightAndLeftPadding {
            padding-right: 5px;
            padding-left: 5px;
        }
    </style>

</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="MainContent" runat="Server">
    <div class=" container">
        <div class="row" id="main" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">
            <div style="margin: 0 auto; width: 40%">
                <div class="panel  panel-info  ">
                    <div class="panel-heading text-center" style="padding: 10px; margin: 0px">
                        <h1 style="font-size: 1.2em; padding: 0px; margin: 0px">تغییر کلمه عبور</h1>
                    </div>
                    <div class="panel-body" style="padding: 10px 20px 10px 20px">
                        <div style="width: 70%; margin: 0 auto; text-align: right; padding: 0px 10px 0px 10px; margin-bottom: 5px; margin-top: 5px; line-height: 25px">
                            <asp:label runat="server" Text="" ForeColor="Red" ID="lblmsg" />
                            <asp:ValidationSummary runat="server" ForeColor="red" BackColor="LightYellow" />
                        </div>
                        <div class="form-group">
                            <label for="txtoldpassword">کلمه عبور قبلی</label>
                            <asp:RequiredFieldValidator SetFocusOnError="true" ErrorMessage="کلمه عبور قبلی را وارد کنید" Text="*" ControlToValidate="txtoldpassword" runat="server" ForeColor="Red" Display="Static" />
                            <asp:TextBox runat="server" ID="txtoldpassword" CssClass="form-control" placeholder="کلمه عبور قبلی" TextMode="Password"
                                onfocus="document.getElementById('MainContent_lblmsg').style.display='none'" MaxLength="16" />
                        </div>
                        <div class="form-group">
                            <label for="txtpassword">کلمه عبور جدید</label>
                            <asp:RequiredFieldValidator SetFocusOnError="true" ErrorMessage="کلمه عبور جدید را وارد کنید" Text="*" ControlToValidate="txtpassword" runat="server" ForeColor="Red" Display="Static" />
                            <asp:TextBox runat="server" ID="txtpassword" CssClass="form-control" placeholder="کلمه عبور جدید" TextMode="Password" MaxLength="16"  />
                        </div>
                        <div class="form-group">
                            <label for="txtrepassword">تکرار کلمه عبور</label>
                            <asp:RequiredFieldValidator SetFocusOnError="true" ErrorMessage="تکرار کلمه عبور جدید را وارد کنید" Text="*" ControlToValidate="txtrepassword" runat="server" ForeColor="Red" Display="Static" />
                            <asp:TextBox runat="server" ID="txtrepassword" CssClass="form-control" placeholder="تکرار کلمه عبور جدید" TextMode="Password" MaxLength="16"  />
                        </div>
                        <asp:CompareValidator SetFocusOnError="true" ErrorMessage="کلمه عبور جدید و تکرار آن با هم یکسان نیستند" ControlToValidate="txtpassword" ControlToCompare="txtrepassword" Operator="Equal" Type="String" runat="server" Display="None" /> 
                        <asp:RegularExpressionValidator ID="RegularExpressionValidator1" SetFocusOnError="true" Display="None"
                            runat="server" ControlToValidate="txtpassword" ForeColor="Red"
                            ErrorMessage="حداقل طول کلمه عبور 6 کاراکتر است" Text="*"
                            ValidationExpression="^[\s\S]{6,1000}$">
                        </asp:RegularExpressionValidator>
                        <br />
                        <div class="form-group text-center">
                            <asp:Button Text="تغییر کلمه عبور" runat="server" CssClass="btn btn-default" ID="btnregister" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  
</asp:Content>
<asp:Content ID="Content4" ContentPlaceHolderID="EndOfPageContent" runat="Server">
</asp:Content>