﻿<%@ Page Title="بارگذاری اطلاعات ماهانه پرسنل" Language="vb" AutoEventWireup="false" MasterPageFile="~/modiran/ModirMasterPage.Master"
    CodeBehind="UploadpersonnelInformation.aspx.vb" Inherits="ZemanatNameh.vb.UploadpersonnelInformation" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style>
        .x {
            text-align: left;
        }

        .ruBrowse {
            background-position: 0 -46px !important;
            width: 122px !important;
            height: 30px !important;
            vertical-align: central !important;
            align-content: center !important;
        }


        .MyModalPanel {
            position: absolute;
            z-index: 30;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            /* background: #ffa url(../Images/loader.gif) center center no-repeat;*/
        }
    </style>
    <script type="text/javascript">
        function RequestStart(sender, args) {
            var loadingPanel = $get("<%= loading1.ClientID %>");
            var pageHeight = document.documentElement.scrollHeight;
            var viewportHeight = document.documentElement.clientHeight;
            if (pageHeight > viewportHeight) {
                loadingPanel.style.height = pageHeight + "px";
            }
            var pageWidth = document.documentElement.scrollWidth;
            var viewportWidth = document.documentElement.clientWidth;
            if (pageWidth > viewportWidth) {
                loadingPanel.style.width = pageWidth + "px";
            }
            if ($telerik.isSafari) {
                var scrollTopOffset = document.body.scrollTop;
                var scrollLeftOffset = document.body.scrollLeft;
            }
            else {
                var scrollTopOffset = document.documentElement.scrollTop;
                var scrollLeftOffset = document.documentElement.scrollLeft;
            }

            var loadingImageWidth = 55;
            var loadingImageHeight = 55;

            loadingPanel.style.backgroundPosition = (parseInt(scrollLeftOffset) + parseInt(viewportWidth / 2) - parseInt(loadingImageWidth / 2)) + "px " + (parseInt(scrollTopOffset) + parseInt(viewportHeight / 2) - parseInt(loadingImageHeight / 2)) + "px";
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <asp:Panel ID="pnlcontainer" runat="server" class=" container">
        <div class="row" id="Dashbord" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">
            
            <div class=" panel panel-default">
                <asp:Panel ID="pnlheading" runat="server" class="panel-heading text-center" Style="padding: 10px; margin: 0px">
                    بارگذاری اطلاعات ماهانه پرسنل
                </asp:Panel>
                <asp:Label runat="server" ID="lbl"></asp:Label>
                <div class="panel-body" style="padding: 10px 20px 10px 20px">
                    <asp:Panel runat="server" Visible="false" ID="pnlmsg" BackColor="Yellow" ForeColor="Red" CssClass="text-center" Style="padding-bottom: 3px; padding-top: 3px; margin-bottom: 10px;">
                        <asp:Label Text="" ID="lblmsg" runat="server" />
                    </asp:Panel>
                    <label for="cbformat">نوع فایل ارسالی:</label>
                    <asp:DropDownList runat="server" ID="cbformat" ValidationGroup="upload">
                        <asp:ListItem Text="انتخاب کنید" Value="0" />
                        <asp:ListItem Text="Dos Text File" Value="1" />
                        <asp:ListItem Text="Excel" Value="2" />
                    </asp:DropDownList>
                    <asp:CompareValidator ErrorMessage="نوع فایل ارسالی را انتخاب کنید" ValidationGroup="upload"
                        ControlToValidate="cbformat" runat="server" ForeColor="Red" ValueToCompare="0" Type="Integer" Operator="NotEqual" />
                    <br />
                    <label for="fupload">انتخاب فایل:</label>
                    <telerik:RadAsyncUpload ID="RadAsyncUpload1" runat="server" InitialFileInputsCount="1" MaxFileInputsCount="1" 
                        OverwriteExistingFiles="true" TargetFolder="~\modiran\upload" Height="45px"
                        HideFileInput="true" InputSize="100" ManualUpload="false" Localization-Select="انتخاب فایل" Localization-Remove="حذف" Localization-Cancel="لغو"
                        Font-Names="yekan">
                    </telerik:RadAsyncUpload>
                    <br />
                    <asp:Button Text="ارسال فایل" runat="server" ID="btnfileupload" CssClass="btn btn-default" ValidationGroup="upload" />
                </div>

            </div>
            <asp:Panel runat="server" ID="pnloutput" Visible="false">
                <div class=" panel panel-info">
                    <div class="panel-heading text-center" style="padding: 10px; margin: 0px">
                        اطلاعات پردازش فایل ارسال شده
                    </div>
                    <div class="panel-body" style="padding: 10px 20px 10px 20px">
                        <asp:Label Text="" ID="lblfileinfotype" runat="server" />
                        <br />
                        <asp:Label Text="" ID="lbltotalrecord" runat="server" />
                        <br />
                        <asp:Label Text="" ID="lblinsert" runat="server" />
                        <br />
                        <asp:Label Text="" ID="lblupdate" runat="server" />
                        <br />
                        <asp:Label Text="" ID="lblerror" runat="server" />
                        <br />
                        <asp:Label ID="lblerrortitle" Text="شماره پرسنلی افرادی که در پردازش اطلاعات آنها خطا بوجود آمده است" runat="server" Visible="false" ForeColor="red" />
                        <br />
                        <asp:TextBox ID="txtcode" runat="server" TextMode="MultiLine" ReadOnly="true" Height="200px" Text="" Visible="false" Width="50%" />

                    </div>
                </div>

            </asp:Panel>
        </div>

        <div class="row" id="Status" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="padding-top: 10px">
                <div class="panel panel-primary">
                    <div class="panel-heading text-center" style="padding: 10px; margin: 0px">
                        <h1 style="font-size: 1.1em; padding: 0px; margin: 0px">وضعیت جاری سایت</h1>
                    </div>
                    <div class="panel-body" style="padding: 10px 20px 10px 20px">
                        <label>وضعیت جاری سایت: </label>
                        <asp:Label Text="" ForeColor="green" runat="server" ID="lblstatus" />
                        <p />
                        <div class="text-center">
                            <asp:Button Text="تغییر وضعیت" runat="server" ID="btnchangestatus" CssClass="btn btn-primary" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </asp:Panel>

    <telerik:RadAjaxManager ID="ajax1" runat="server" DefaultLoadingPanelID="loading1">
        <ClientEvents OnRequestStart="RequestStart" />
        <AjaxSettings>
            <telerik:AjaxSetting AjaxControlID="btnfileupload">
                <UpdatedControls>
                    <telerik:AjaxUpdatedControl ControlID="pnlcontainer" />
                </UpdatedControls>
            </telerik:AjaxSetting>
        </AjaxSettings>
    </telerik:RadAjaxManager>
    <telerik:RadAjaxLoadingPanel ID="loading1" runat="server" IsSticky="true" CssClass="MyModalPanel" Skin="Telerik"></telerik:RadAjaxLoadingPanel>
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">
</asp:Content>
