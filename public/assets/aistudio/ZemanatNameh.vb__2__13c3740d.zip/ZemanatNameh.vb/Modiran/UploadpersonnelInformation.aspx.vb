﻿Imports System.IO
Imports System.Linq
Imports IranSystemConvertor
Imports System.Data.SqlClient
Imports System.Data.OleDb
Public Class UploadpersonnelInformation
    Inherits System.Web.UI.Page
    Private utill As New Utility()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'If Not IsPostBack Then
        '    Dim script As String = "$(document).ready(function () { $('[id*=btnfileupload]').click(); });"
        '    ClientScript.RegisterStartupScript(Me.GetType, "load", script, True)
        'End If
        pnlmsg.Visible = False
        lblstatus.Text = utill.Labelupdate()
    End Sub
    Protected Sub btnfileupload_Click(sender As Object, e As EventArgs) Handles btnfileupload.Click
        If Me.Page.IsValid Then
            If RadAsyncUpload1.UploadedFiles.Count = 0 Then
                pnlmsg.Visible = True
                lblmsg.Text = "فایلی برای ارسال اتنخاب نشده است و یا فرمت فایل ارسالی صحیح نیست"
                Return
            End If
            utill.ChangeWebsiteStatusToUpdate(True)

            lblstatus.Text = utill.Labelupdate()

            Dim fullpath As String = Server.MapPath("~/modiran/upload/" & RadAsyncUpload1.UploadedFiles(0).GetNameWithoutExtension() & ".txt")

            '''''''''''''''''''''''''''''''''''''''''''''''

            Dim dtUsers As New DataTable()
            Dim dtGovahies As New DataTable()
            Dim strselectusers As String = "SELECT [Code] FROM [Users_table]"
            Dim strselectGovahies As String = "SELECT [code],[StateId] FROM [Govahies]"

            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselectusers, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    Using sda As New SqlDataAdapter(command)
                        Try
                            dtUsers.Clear()
                            sda.Fill(dtUsers)
                        Catch ex As Exception
                            Throw
                        End Try
                    End Using
                End Using
            End Using

            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselectGovahies, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    Using sda As New SqlDataAdapter(command)
                        Try
                            dtGovahies.Clear()
                            sda.Fill(dtGovahies)
                        Catch ex As Exception
                            Throw
                        End Try
                    End Using
                End Using
            End Using
            '''''''''''''''''''''''''''''''''''''''''''''''
            If cbformat.SelectedValue = "1" Then
                'اگر فایل ورودی با فرمت فایل داس باشد
                'خواندن فایل آپلود شده و تبدیل کدپیج ایران سیستم به یونیکد
                Dim str As String = ConvertTo.UnicodeFormFile(fullpath)
                File.Delete(fullpath)
                ' جدا کردن خطوط خوانده شده و ذخیره هر خط در یک عنصر آرایه
                Dim lines As String() = str.Split(New Char() {ControlChars.Lf}, StringSplitOptions.RemoveEmptyEntries)

                Dim totalrecord As Integer = lines.Length
                Dim insertedrecord As Integer = 0
                Dim updatedrecord As Integer = 0
                Dim listcode As New List(Of String)()
                'برعکس نمودن اعداد برای برگشت به حالت صحیح اولیه
                ' تشخیص اعدا منفی و اصلاح آنها و ذخیره به صورت عدد منفی صحیح
                'معکوس کردن کل رشته برای تبدیل رشته به حالت صحیح اولیه
                'ذخیره تمامی خطوط اصلاح شده در لیستی به نام Records
                Dim Records As New List(Of String)()
                For Each item As String In lines
                    Dim field As String = ""
                    Dim record As String = ""
                    Dim n As Double = 0.0
                    Dim query = From val In item.Split(","c)
                                Select (val.Trim())
                    For Each itm As String In query
                        field = itm.Replace("-", "").Trim()
                        If Double.TryParse(field, n) Then
                            field = utill.Reverse(field)
                            If itm.Contains("-") Then
                                field = "-" & field.Trim()
                            End If
                        Else
                            field = itm
                        End If
                        record = field & "," & record
                    Next
                    record = record.Substring(0, record.LastIndexOf(","))
                    record = record.Replace(")", "").Replace("(", "").Replace("ي", "ی")
                    Records.Add(record)
                Next
                ' پایان عملیات اصلاح رشته
                lines = Nothing

                Dim rec As String() = Nothing
                For Each record As String In Records
                    If record.Length > 0 Then
                        rec = record.Split(","c)
                        Exit For
                    End If
                Next
                utill.Set_Users_To_Inactive(rec(8)) 'سلول 8 این آرایه عدد مربوط به نوع اشتغال زا ذخیره می کند


                For Each record As String In Records
                    'به دست آوردن کد پرسنلی - نام کاربری - هر رکورد
                    Dim code As String = record.Substring(0, record.IndexOf(","))

                    Dim drusers As DataRow()
                    Dim strcondition As String = "code='" & code & "'"
                    drusers = dtUsers.Select(strcondition)

                    Dim drActiveGovahies As DataRow()
                    drActiveGovahies = dtGovahies.Select(strcondition & " AND StateId=1")

                    If drusers.Count = 0 Then
                        ' اگر اطلاعات کاربر قبلا ثبت نشده باشد کاربر جدید به بانک اطلاعاتی اضافه می شود
                        Dim c As String = utill.InsertNewUser(record, drActiveGovahies.Count)
                        If c.Length > 0 Then
                            'اظافه کردن کدهای کاربرانی که درج اطلاعات آنها با خطا مواجه شده است به لیست خطاها 
                            listcode.Add(c)
                        Else
                            insertedrecord += 1
                            utill.Set_Number_Of_Active_Govahie_By_Code(code)
                        End If
                    Else
                        ' اگر اطلاعات کاربر از قبل در بانک اطلاعاتی وجود دارد اطلاعات به روز رسانی شود
                        Dim c As String = utill.UpdateUser(record, drActiveGovahies.Count)
                        If c.Length > 0 Then
                            'اظافه کردن کدهای کاربرانی که درج اطلاعات آنها با خطا مواجه شده است به لیست خطاها 
                            listcode.Add(c)
                        Else
                            updatedrecord += 1
                            utill.Set_Number_Of_Active_Govahie_By_Code(code)
                        End If
                    End If

                Next

                Dim ftype As String = ""
                Select Case rec(8)
                    Case "1"
                        ftype = "شاغل"
                    Case "2"
                        ftype = "بازنشسته"
                End Select
                lblfileinfotype.Text = "نوع اطلاعات فایل ارسالی : اطلاعات پرسنل " & ftype
                rec = Nothing

                ' محاسبه و نمایش رکورد های درج شده و بروزرسانی شده و خطاها
                Dim numberoferror As Integer = listcode.Count
                pnloutput.Visible = True
                lbltotalrecord.Text = "تعداد کل رکوردها: " & totalrecord.ToString()
                lblinsert.Text = "تعداد رکورد های درج شده: " & insertedrecord.ToString()
                lblupdate.Text = "تعداد رکورد های بروزرسانی شده : " & updatedrecord.ToString()
                lblerror.Text = "تعداد رکورد های خطا: " & numberoferror.ToString()
                If numberoferror > 0 Then
                    lblerrortitle.Visible = True
                    txtcode.Visible = True
                    For Each itm As String In listcode
                        txtcode.Text += itm & vbLf
                    Next
                Else
                    lblerrortitle.Visible = False
                    txtcode.Visible = False
                End If


            ElseIf cbformat.SelectedValue = "2" Then
                'اگر فایل ورودی با فرمت فایل اکسل باشد

                lbl.Text = ""
                Dim ExcelFile As String = Server.MapPath("~/modiran/upload/" & RadAsyncUpload1.UploadedFiles(0).FileName())
                Dim Records = ProcessExcelRowsToArray(ExcelFile)
                File.Delete(ExcelFile)
                Dim totalrecord As Integer = Records.Count
                Dim insertedrecord As Integer = 0
                Dim updatedrecord As Integer = 0
                Dim listcode As New List(Of String)()



                'تنظیم نوع اشتغال همه ی افراد به مقدار 2 بازنشسته
                'چون در فایل اکسل فقط افراد شاغل حضور دارند وضعیت همه به بازنشسته تغییر یابد و فقط افراد داخل فایل اکسل شاغل شوند

                utill.Set_EshteghalID(2)
                'غير فعال كردن همه ي كاربران
                utill.Set_isActive(0)

                For Each record As String In Records
                    'به دست آوردن کد پرسنلی - نام کاربری - هر رکورد
                    Dim code As String = record.Substring(0, record.IndexOf(","))
                    Dim drusers As DataRow()
                    Dim strcondition As String = "code='" & code & "'"
                    drusers = dtUsers.Select(strcondition)

                    Dim drActiveGovahies As DataRow()
                    drActiveGovahies = dtGovahies.Select(strcondition & " AND StateId=1")
                    If drusers.Count = 0 Then
                        ' اگر اطلاعات کاربر قبلا ثبت نشده باشد کاربر جدید به بانک اطلاعاتی اضافه می شود
                        Dim c As String = utill.InsertNewUser(record, drActiveGovahies.Count)
                        If c.Length > 0 Then
                            'اظافه کردن کدهای کاربرانی که درج اطلاعات آنها با خطا مواجه شده است به لیست خطاها 
                            listcode.Add(c)
                        Else
                            insertedrecord += 1
                            utill.Set_Number_Of_Active_Govahie_By_Code(code)
                        End If
                    Else
                        ' اگر اطلاعات کاربر از قبل در بانک اطلاعاتی وجود دارد اطلاعات به روز رسانی شود
                        Dim c As String = utill.UpdateUser(record, drActiveGovahies.Count)
                        If c.Length > 0 Then
                            'اظافه کردن کدهای کاربرانی که درج اطلاعات آنها با خطا مواجه شده است به لیست خطاها 
                            listcode.Add(c)
                        Else
                            updatedrecord += 1
                            utill.Set_Number_Of_Active_Govahie_By_Code(code)
                        End If
                    End If
                Next

                Dim numberoferror As Integer = listcode.Count
                pnloutput.Visible = True
                lbltotalrecord.Text = "تعداد کل رکوردها: " & totalrecord.ToString()
                lblinsert.Text = "تعداد رکورد های درج شده: " & insertedrecord.ToString()
                lblupdate.Text = "تعداد رکورد های بروزرسانی شده : " & updatedrecord.ToString()
                lblerror.Text = "تعداد رکورد های خطا: " & numberoferror.ToString()
                If numberoferror > 0 Then
                    lblerrortitle.Visible = True
                    txtcode.Visible = True
                    For Each itm As String In listcode
                        txtcode.Text += itm & vbLf
                    Next
                Else
                    lblerrortitle.Visible = False
                    txtcode.Visible = False
                End If

            End If
            utill.Set_RowValidationCode_For_All_Rows_In_Govaheis_Table()
            utill.Set_Number_Of_Active_Govahie_For_ALL_Users()
            utill.ChangeWebsiteStatusToUpdate(False)
            lblstatus.Text = utill.Labelupdate()
            dtUsers.Clear()
            dtGovahies.Clear()

        End If
        ' end of Page.IsValid

    End Sub
    'end of method
    Protected Sub btnchangestatus_Click1(sender As Object, e As EventArgs) Handles btnchangestatus.Click
        utill.ChangeWebsiteStatus()
        lblstatus.Text = utill.Labelupdate()
    End Sub

    ' تابع برای تبدیل حروف "ی" و "ک" عربی به معادل فارسی آنها
    Private Function ConvertArabicToPersian(ByVal inputString As String) As String
        If String.IsNullOrEmpty(inputString) Then
            Return inputString
        End If

        ' کاراکترهای عربی:
        ' ی عربی (U+064A) به ی فارسی (U+06CC)
        ' ک عربی (U+0643) به ک فارسی (U+06A9)
        Return inputString.Replace(ChrW(&H64A), ChrW(&H6CC)).Replace(ChrW(&H643), ChrW(&H6A9))
    End Function

    ' تابع جدید برای تبدیل مقدار ستون جنسیت به کد عددی
    Private Function GetGenderCode(ByVal genderString As String) As String
        ' ابتدا اطمینان حاصل می کنیم که ورودی به فارسی تبدیل شده باشد تا مقایسه صحیح باشد
        Dim convertedGender As String = ConvertArabicToPersian(genderString.Trim()) ' Trim برای حذف فضاهای خالی اضافی

        Select Case convertedGender
            Case "مرد"
                Return "1"
            Case "زن"
                Return "2"
            Case Else
                Return "" ' یا می توانید مقدار پیش فرض دیگری را برگردانید، مثلاً "0" یا همان رشته اصلی
        End Select
    End Function


    Public Function ProcessExcelRowsToArray(excelFilePath As String) As List(Of String)
        Dim excelConn As OleDbConnection = Nothing
        Dim processedRowsList As New List(Of String)() ' لیستی برای ذخیره رشته های پردازش شده هر سطر


        Try
            ' --- 1. خواندن داده ها از اکسل ---
            Dim excelConnectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & excelFilePath & ";Extended Properties=""Excel 12.0 Xml;HDR=YES;IMEX=1;"""
            excelConn = New OleDbConnection(excelConnectionString)
            excelConn.Open()
            ' گرفتن نام شیت اول
            Dim sheetTable As DataTable = excelConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
            Dim sheetName As String = sheetTable.Rows(0)("TABLE_NAME").ToString()

            ' خواندن داده‌ها از شیت
            Dim cmd As New OleDbCommand("SELECT * FROM [" & sheetName & "]", excelConn)
            Dim da As New OleDbDataAdapter(cmd)
            Dim dtExcel As New DataTable()
            da.Fill(dtExcel) ' پر کردن DataTable با داده های اکسل

            Console.WriteLine("تعداد " & dtExcel.Rows.Count & " سطر با موفقیت از اکسل خوانده شد.")

            ' --- 2. پردازش هر سطر و ذخیره در آرایه ---
            For Each row As DataRow In dtExcel.Rows
                Dim rowStringBuilder As New StringBuilder()
                Dim isFirstColumn As Boolean = True

                For Each column As DataColumn In dtExcel.Columns
                    If Not isFirstColumn Then
                        rowStringBuilder.Append(",") ' اضافه کردن جداکننده کاما بین ستون ها
                    End If

                    Dim cellValue As Object = row(column)
                    Dim formattedValue As String = String.Empty

                    If Not IsDBNull(cellValue) Then
                        ' ابتدا مقدار را به رشته تبدیل می کنیم
                        Dim originalStringValue As String = cellValue.ToString()
                        formattedValue = ConvertArabicToPersian(originalStringValue)
                    End If

                    ' اگر مقدار نهایی (پس از تبدیل) حاوی کاما یا کاراکترهای خاص است، آن را داخل کوتیشن قرار دهید
                    If formattedValue.Contains(",") OrElse formattedValue.Contains(Environment.NewLine) OrElse formattedValue.Contains("""") Then
                        formattedValue = """" & formattedValue.Replace("""", """""") & """" ' اضافه کردن "" برای کوتیشن های داخلی
                    End If
                    formattedValue = formattedValue.Replace("مرد", "1").Replace("زن", "2")
                    formattedValue = formattedValue.Replace("رسمی", "1").Replace("آزمایشی", "2").Replace("پیمانی", "3")
                    formattedValue = formattedValue.Replace("شاغل", "1").Replace("بازنشسته", "2")

                    rowStringBuilder.Append(formattedValue)
                    isFirstColumn = False
                Next

                ' اضافه کردن رشته نهایی سطر به لیست
                processedRowsList.Add(rowStringBuilder.ToString())
            Next

            lbl.Text = ("عملیات خواندن و پردازش سطرها به پایان رسید. تعداد " & processedRowsList.Count & " سطر به آرایه اضافه شد.")

        Catch ex As OleDbException
            lbl.Text = ("خطا در خواندن فایل اکسل: " & ex.Message)
            If ex.ErrorCode = -2147467259 Then ' خطای رایج برای نصب نبودن درایور ACE OLEDB
                lbl.Text = ("احتمالاً درایور Microsoft Access Database Engine 2010 Redistributable نصب نشده است.")
            End If
        Catch ex As Exception
            lbl.Text = ("خطای عمومی: " & ex.Message)
        Finally
            ' اطمینان از بسته شدن اتصال
            If excelConn IsNot Nothing AndAlso excelConn.State = ConnectionState.Open Then
                excelConn.Close()
                excelConn.Dispose()
            End If
        End Try

        Return processedRowsList ' بازگرداندن لیستی از رشته های پردازش شده
    End Function
End Class