﻿Imports System.Data.SqlClient
Public Class ModirMasterPage
    Inherits System.Web.UI.MasterPage
    Private Utill As New Utility()
    Private adminmember As New AdminMembership()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Session.Add("returl", "modir")
        lbluserfullname.Text = adminmember.GetAdminFullname(HttpContext.Current.User.Identity.Name)
        Using sqlCon As New SqlConnection(Utill.connectionstring)
            Dim sqlSelectstring As String = "SELECT [Value]  FROM [AppSettings] where [name]=@orgtitle"
            Using selectCommand As New SqlCommand(sqlSelectstring, sqlCon)
                selectCommand.CommandType = CommandType.Text
                selectCommand.Parameters.AddWithValue("@orgtitle", "orgtitle")
                Try
                    sqlCon.Open()
                    Using sqldr As SqlDataReader = selectCommand.ExecuteReader()
                        If sqldr.HasRows Then
                            sqldr.Read()
                            'this.Page.Header.Title = orgtitle.Text;
                            orgtitle.Text = sqldr.Item("value").ToString()
                        End If

                    End Using
                Catch ex As Exception
                    Utill.RegisterError(ex.Message, "ModirMasterPage", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                End Try

            End Using
        End Using

    End Sub

End Class