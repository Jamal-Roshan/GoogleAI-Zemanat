﻿Imports Stimulsoft.Report
Imports System.Drawing
Imports System.IO
Public Class Gozaresh_Estelam
    Inherits System.Web.UI.Page
    Private Const signFilename = "\reports\sign.png"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("Bankname") Is Nothing OrElse Session("Shomarehnamehbank") Is Nothing OrElse Session("Tarikhnamehbank") Is Nothing OrElse Session("shomareh_Govahei") Is Nothing OrElse
            Session("Tarikh_Sodur_Govahei") Is Nothing OrElse Session("Fullname") Is Nothing OrElse Session("name_Vamgirandeh") Is Nothing OrElse Session("Vamgirandeh_Pedar") Is Nothing OrElse
            Session("Vamgirandeh_Pedar") Is Nothing OrElse Session("mablagh") Is Nothing OrElse Session("SignerName") Is Nothing OrElse Session("SignerPost") Is Nothing Then
            Response.Redirect("./Estelam")
        End If
        Dim utill As New Utility

        Dim serverlocation As String = HttpContext.Current.Server.MapPath(String.Empty)
        Dim myreport As New StiReport()
        myreport.Load(serverlocation + "\reports\Estelam.mrt")
        myreport.Dictionary.Variables.Clear()
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "BankTitle", Session("Bankname")))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "ShomarehNamehBank", utill.En2Fa(Session("Shomarehnamehbank").ToString)))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "TarikhNamehBank", utill.En2Fa(Session("Tarikhnamehbank").ToString)))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "ShomarehGovahie", utill.En2Fa(Session("shomareh_Govahei").ToString)))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "TarikhGovahi", Session("Tarikh_Sodur_Govahei")))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Fullname", Session("Fullname")))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Eshteghal", Session("Eshteghal")))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Vamgirandeh", Session("name_Vamgirandeh")))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "VamgirandehPedar", Session("Vamgirandeh_Pedar")))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "SignerName", Session("SignerName")))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "SignerPost", Session("SignerPost")))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Mablagh", Session("mablagh")))
        myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Tarikh", utill.En2Fa(utill.DateToString(Today))))

        If File.Exists(serverlocation & signFilename) Then
            myreport.Dictionary.Variables.Add(New Stimulsoft.Report.Dictionary.StiVariable("Category_Information", "Sign", Image.FromFile(serverlocation & signFilename)))
        End If

        myreport.Dictionary.Synchronize()
        myreport.Compile()
        myreport.Render(True)

        StiWebViewer1.Report = myreport


        ' myreport.Dictionary.Variables.Clear()


        ' 
        ' myreport.Show()

    End Sub

End Class