﻿Imports System.Data.SqlClient
Imports Telerik.Web.UI
Public Class viewEstelamha
    Inherits System.Web.UI.Page
    Public utill As New Utility
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If RadGrid1.MasterTableView.Items.Count = 0 Then
            pnlgrid.Visible = False
            btnExportToexcel.Visible = False
        Else
            pnlgrid.Visible = True
            btnExportToexcel.Visible = True
        End If
    End Sub
    Protected Sub RadGrid1_ItemDataBound(sender As Object, e As Telerik.Web.UI.GridItemEventArgs) Handles RadGrid1.ItemDataBound
        If (TypeOf e.Item Is GridDataItem) Then
            ' AndAlso e.Item.OwnerTableView.DataSource = "Sqldr"
            Dim lbl As Label = CType(e.Item.FindControl("Grid_RowNumber_Label"), Label)
            lbl.Text = (((e.Item.OwnerTableView.CurrentPageIndex * e.Item.OwnerTableView.PageSize) + (e.Item.ItemIndex + 1)).ToString())
            'Dim refChk As CheckBox = DirectCast(e.Item.FindControl("chkRowSelectCheckBox"), CheckBox)
            'ClientScript.RegisterArrayDeclaration("chk_Array_IDs", String.Concat("'", refChk.ClientID, "'"))
        End If
    End Sub

    Protected Sub btnfilter_Click(sender As Object, e As EventArgs) Handles btnfilter.Click
        bindgrid()
        If RadGrid1.MasterTableView.Items.Count = 0 Then
            pnlgrid.Visible = False
            btnExportToexcel.Visible = False
            pnlinfo.Visible = False
            pnlmsg.Visible = True
        Else
            pnlgrid.Visible = True
            btnExportToexcel.Visible = True
            pnlinfo.Visible = True
            pnlmsg.Visible = False
        End If
    End Sub

    Protected Sub btnclearfilter_Click(sender As Object, e As EventArgs) Handles btnclearfilter.Click
        txtcode.Text = ""
        txtnid.Text = ""
        RadGrid1.DataBind()
        pnlgrid.Visible = False
        btnExportToexcel.Visible = False
        pnlinfo.Visible = False
        pnlmsg.Visible = False
    End Sub
    Protected Function getcolor(typeid As Integer) As System.Drawing.Color
        Dim ret As System.Drawing.Color
        Select Case typeid
            Case 1
                ret = System.Drawing.Color.Red
            Case 2
                ret = System.Drawing.Color.Blue
            Case 3
                ret = System.Drawing.Color.Green
        End Select
        Return ret
    End Function
    Protected Sub bindgrid()
        Dim strCondition As String = ""
        Dim code = utill.Fa2En(txtcode.Text.Trim)
        Dim NID = utill.Fa2En(txtnid.Text.Trim)
        If code.Length > 0 Then
            strCondition = "Users_table.Code=@code"
        End If
        If NID.Length > 0 Then
            strCondition = "Users_table.NationalID=@nid"
        End If
        If code.Length = 0 AndAlso NID.Length = 0 Then
            Exit Sub
        End If
        Dim strselect As String = "SELECT Govahies.RowID, Users_table.Code,Users_table.Firstname, Users_table.Lastname, Govahies.Shomareh," _
                                & " Govahies.GovahiTypeID, Govahies.BankFullname, Govahies.LoanAmount,Govahies.LoanOwner_FirstName, Govahies.LoanOwner_LastName," _
                                & " Govahies.LoanOwner_FatherName, Govahies.StateId, Govahies.DateOfCreate,Users_table.Fathername," _
                                & " Govahies.Shomareh_Nameh_Estelam_Bank,Govahies.Tarikh_Nameh_Estelam_Bank,Govahies.Sader_Konnandeh_Estelam,Govahies.Tarikh_Sodur_Estelam " _
                                & " FROM Users_table INNER JOIN Govahies On Users_table.Code = Govahies.Code " _
                                & " where Govahies.Tarikh_Sodur_Estelam Is Not NULL AND	" & strCondition & " ORDER BY Govahies.DateOfCreate DESC"

        Dim ActiveGovahies As Long = 0
        Using connection As New SqlConnection(utill.Connectionstring)
            Using command As New SqlCommand(strselect, connection)
                command.CommandType = CommandType.Text
                command.Parameters.Clear()

                If code.Length > 0 Then
                    command.Parameters.AddWithValue("@Code", code)
                End If
                If NID.Length > 0 Then
                    command.Parameters.AddWithValue("@nid", NID)
                End If
                Using sda As New SqlDataAdapter(command)
                    Dim dt As New DataTable()
                    Try
                        dt.Clear()
                        sda.Fill(dt)
                        RadGrid1.DataSource = dt
                        RadGrid1.DataBind()
                    Catch ex As Exception
                        dt.Clear()
                        Return
                    End Try

                    Try
                        lblfullname.Text = dt.Rows(0).Item("Firstname").ToString + " " + dt.Rows(0).Item("Lastname").ToString
                        lblfather.Text = dt.Rows(0).Item("Fathername").ToString
                    Catch ex As Exception
                        lblfullname.Text = ""
                        lblfather.Text = ""
                        Server.ClearError()
                    End Try

                    Try
                        ActiveGovahies = CType(dt.Compute("Count(Code)", "StateId=1"), Long)
                    Catch ex As Exception
                        ActiveGovahies = 0
                        Server.ClearError()
                    End Try
                End Using
            End Using
        End Using
        lblactive.Text = "تعداد استعلام های صادر شده:" & " " & ActiveGovahies.ToString
    End Sub

    Protected Sub btnExportToexcel_Click(sender As Object, e As ImageClickEventArgs) Handles btnExportToexcel.Click
        If RadGrid1.MasterTableView.Items.Count = 0 Then
            Return
        End If
        'RadGrid1.MasterTableView.GetColumn("chkRow").Visible = False
        bindgrid()
        RadGrid1.ExportSettings.Excel.Format = DirectCast([Enum].Parse(GetType(GridExcelExportFormat), "Xlsx"), GridExcelExportFormat)
        RadGrid1.ExportSettings.IgnorePaging = True
        RadGrid1.ExportSettings.ExportOnlyData = False
        RadGrid1.ExportSettings.OpenInNewWindow = True
        RadGrid1.ExportSettings.FileName = "Moshaedeh_Estelam"
        RadGrid1.MasterTableView.ExportToExcel()
        '  RadGrid1.MasterTableView.GetColumn("chkRow").Visible = True
    End Sub
    Protected Sub RadGrid1_GroupsChanging(sender As Object, e As GridGroupsChangingEventArgs) Handles RadGrid1.GroupsChanging
        bindgrid()
    End Sub
    Protected Sub RadGrid1_ColumnsReorder(sender As Object, e As GridColumnsReorderEventArgs) Handles RadGrid1.ColumnsReorder
        bindgrid()
    End Sub
    Protected Sub RadGrid1_PageIndexChanged(sender As Object, e As GridPageChangedEventArgs) Handles RadGrid1.PageIndexChanged ', RadGrid2.PageIndexChanged
        bindgrid()
    End Sub
    Protected Sub RadGrid1_PageSizeChanged(sender As Object, e As GridPageSizeChangedEventArgs) Handles RadGrid1.PageSizeChanged ', RadGrid2.PageSizeChanged
        bindgrid()
    End Sub
    Protected Sub RadGrid1_SortCommand(sender As Object, e As GridSortCommandEventArgs) Handles RadGrid1.SortCommand
        bindgrid()
    End Sub

End Class