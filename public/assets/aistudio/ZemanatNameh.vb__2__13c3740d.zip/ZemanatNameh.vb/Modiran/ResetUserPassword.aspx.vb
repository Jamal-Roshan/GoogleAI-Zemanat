﻿Public Class ResetUserPassword
    Inherits System.Web.UI.Page
    Private Utill As New Utility()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        If Me.Page.IsValid Then
            Dim code = Utill.Fa2En(txtcode.Text.Trim)
            If Not Utill.UserExist(code) Then
                lblmsg.Text = "کاربری با این شماره پرسنلی موجود نیست"
                lblmsg.Visible = True
                pnlstatus.Visible = False
                Return
            End If
            Dim m As New UserMembership
            lblfullname.Text = m.GetUserFullname(code)
            lblmsg.Visible = False
            pnlstatus.Visible = True

        End If
    End Sub
    Protected Sub btnresetform_Click(sender As Object, e As EventArgs) Handles btnresetform.Click
        lblfullname.Text = ""
        lblmsg.Visible = False
        lblmsg.Text = ""
        pnlstatus.Visible = False
        txtcode.Text = ""
    End Sub

    Protected Sub btnresetpass_Click(sender As Object, e As EventArgs) Handles btnresetpass.Click
        Dim m As New UserMembership
        ' <returns> 0 = User Not Found - 1= Password Rest Successful - (-1)= Error in Finding User - (-2)= Error in Reset Password</returns>
        Dim code = Utill.Fa2En(txtcode.Text.Trim).ToLower
        Select Case m.ResetUserPassword(code)
            Case 0
                lblmsg.Text = "کاربری با این شماره پرسنلی موجود نیست"
                lblmsg.Visible = True
            Case 1
                lblmsg.Text = "رمز عبور فرد مورد نظر با موفقیت بازنشانی شد"
                lblmsg.Visible = True
            Case -1
                lblmsg.Text = "در عملیات جستجوی فرد مورد نظر خطا رخ داده است"
                lblmsg.Visible = True
            Case -2
                lblmsg.Text = "در عملیات بازنشانی رمز عبور کاربر خطا رخ داده است"
                lblmsg.Visible = True
        End Select

        lblfullname.Text = ""
        pnlstatus.Visible = False
        txtcode.Text = ""
    End Sub
End Class