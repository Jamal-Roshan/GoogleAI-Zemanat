﻿Imports System.Data.SqlClient
Imports Telerik.Web.UI
Public Class Estelamha
    Inherits System.Web.UI.Page

    Public utill As New Utility
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If RadGrid1.MasterTableView.Items.Count = 0 Then
            pnlgrid.Visible = False
            btnExportToexcel.Visible = False
        Else
            pnlgrid.Visible = True
            btnExportToexcel.Visible = True
        End If
    End Sub
    Protected Sub RadGrid1_ItemDataBound(sender As Object, e As Telerik.Web.UI.GridItemEventArgs) Handles RadGrid1.ItemDataBound
        If (TypeOf e.Item Is GridDataItem) Then
            ' AndAlso e.Item.OwnerTableView.DataSource = "Sqldr"
            Dim lbl As Label = CType(e.Item.FindControl("Grid_RowNumber_Label"), Label)
            lbl.Text = (((e.Item.OwnerTableView.CurrentPageIndex * e.Item.OwnerTableView.PageSize) + (e.Item.ItemIndex + 1)).ToString())
            Dim refChk As CheckBox = DirectCast(e.Item.FindControl("chkRowSelectCheckBox"), CheckBox)
            ClientScript.RegisterArrayDeclaration("chk_Array_IDs", String.Concat("'", refChk.ClientID, "'"))
        End If
    End Sub

    Protected Sub btnfilter_Click(sender As Object, e As EventArgs) Handles btnfilter.Click
        bindgrid()
        If RadGrid1.MasterTableView.Items.Count = 0 Then
            pnlgrid.Visible = False
            btnExportToexcel.Visible = False
            pnlinfo.Visible = False
            pnlmsg.Visible = True
        Else
            pnlgrid.Visible = True
            btnExportToexcel.Visible = True
            pnlinfo.Visible = True
            pnlmsg.Visible = False
        End If
    End Sub

    Protected Sub btnclearfilter_Click(sender As Object, e As EventArgs) Handles btnclearfilter.Click
        txtcode.Text = ""
        txtnid.Text = ""
        RadGrid1.DataBind()
        pnlgrid.Visible = False
        lblsum.Text = ""
        btnestelam.Visible = False
        btnExportToexcel.Visible = False
        pnlinfo.Visible = False
        pnlmsg.Visible = False
    End Sub
    Protected Function getcolor(typeid As Integer) As System.Drawing.Color
        Dim ret As System.Drawing.Color
        Select Case typeid
            Case 1
                ret = System.Drawing.Color.Red
            Case 2
                ret = System.Drawing.Color.Blue
            Case 3
                ret = System.Drawing.Color.Green
        End Select
        Return ret
    End Function
    Protected Sub bindgrid()
        Dim strCondition As String = ""
        Dim code As String = utill.Fa2En(txtcode.Text.Trim)
        Dim NID As String = utill.Fa2En(txtnid.Text.Trim)
        Dim ShomarehGovahie As String = utill.Fa2En(txtshomarehgovahi.Text.Trim)
        If code.Length > 0 Then
            strCondition = "Users_table.Code=@code"
        End If
        If NID.Length > 0 Then
            strCondition = "Users_table.NationalID=@nid"
        End If
        If ShomarehGovahie.Length > 0 Then
            strCondition = "Govahies.Shomareh=@Shomareh"
        End If
        If code.Length = 0 AndAlso NID.Length = 0 AndAlso ShomarehGovahie.Length = 0 Then
            Exit Sub
        End If

        Dim strselect As String = "SELECT Govahies.RowID, Users_table.Code, Users_table.NationalID, Users_table.Firstname, Users_table.Lastname, Users_table.Fathername, Govahies.Shomareh," _
                                & " Govahies.GovahiTypeID, Govahies.BankFullname, Govahies.LoanAmount, Govahies.MablaghKhalesDaryafti, Govahies.LoanOwner_FirstName, Govahies.LoanOwner_LastName," _
                                & " Govahies.LoanOwner_FatherName, Govahies.StateId, Govahies.DateOfCreate, Govahies.Tasviyehby, ISNULL(Govahies.TasviyehDate, 0) AS TasviyehDate, Users_table.EshteghalID," _
                                & " Genders.Prefix FROM Users_table INNER JOIN Govahies ON Users_table.Code = Govahies.Code INNER JOIN Genders ON Users_table.GenderId = Genders.Genders_ID" _
                                & " where " & strCondition & " and Govahies.StateId=1  ORDER BY Govahies.DateOfCreate DESC"

        Dim sum As Double = 0
        Dim totalRecord As Long = 0
        Dim TasviyehRecords As Long = 0
        Dim ActiveGovahies As Long = 0
        Using connection As New SqlConnection(utill.Connectionstring)
            Using command As New SqlCommand(strselect, connection)
                command.CommandType = CommandType.Text
                command.Parameters.Clear()

                If code.Length > 0 Then
                    command.Parameters.AddWithValue("@Code", code)
                End If
                If NID.Length > 0 Then
                    command.Parameters.AddWithValue("@nid", NID)
                End If
                If ShomarehGovahie.Length > 0 Then
                    command.Parameters.AddWithValue("@Shomareh", ShomarehGovahie)
                End If
                Using sda As New SqlDataAdapter(command)
                    Dim dt As New DataTable()
                    Try
                        dt.Clear()
                        sda.Fill(dt)
                        RadGrid1.DataSource = dt
                        RadGrid1.DataBind()
                    Catch ex As Exception
                        dt.Clear()
                        Return
                    End Try


                    Try
                        lblfullname.Text = ""
                        lblfather.Text = ""
                        lblfullname.Text = dt.Rows(0).Item("Firstname").ToString & " " & dt.Rows(0).Item("Lastname").ToString
                        lblfather.Text = dt.Rows(0).Item("Fathername").ToString
                    Catch ex As Exception
                        lblfullname.Text = ""
                        lblfather.Text = ""
                        Server.ClearError()
                    End Try

                    Try
                        totalRecord = CType(dt.Compute("Count(Code)", ""), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        totalRecord = 0
                    End Try

                    Try
                        TasviyehRecords = CType(dt.Compute("Count(Code)", "StateId=3"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        TasviyehRecords = 0
                    End Try

                    Try
                        sum = CType(dt.Compute("sum(LoanAmount)", "StateId=1"), Long)
                    Catch ex As Exception
                        Server.ClearError()
                        sum = 0
                    End Try

                End Using
            End Using
        End Using
        If sum > 0 Then
            btnestelam.Enabled = True
            btnestelam.Visible = True
            lblsum.Visible = True
            lblsum.Text = "مجموع مبالغ تسویه نشده: " & utill.En2Fa(String.Format("{0:#,###,###}", sum))
        Else
            btnestelam.Enabled = False
            btnestelam.Visible = False
            lblsum.Visible = False
            lblsum.Text = ""
        End If
        lblactive.Text = "تعداد گواهی حقوقی و ضمانت نامه های فعال:" & " " & ActiveGovahies.ToString

    End Sub

    Protected Sub btnestelam_Click(sender As Object, e As EventArgs) Handles btnestelam.Click
        Dim strID As String = ""
        Dim shomareh_Nameh_Estelam_Bank As String = txtshomareh.Text.Trim
        Dim tarikh_Nameh_Estelam_Bank As String = txttarikh.Text.Trim
        Dim shomareh_Govahei As String = ""
        Dim Tarikh_Sodur_Govahei As String = ""
        Dim Fullname As String = lblfullname.Text
        Dim name_Vamgirandeh As String = ""
        Dim Vamgirandeh_Pedar As String = ""
        Dim mablagh As String = ""
        Dim EshteghalType As String = ""
        Dim OrgTitle As String = ""
        Dim SignerName As String = ""
        Dim SignerPost As String = ""
        Dim Bankname As String = ""
        Dim MaliCode As String = ""
        Dim Jensiyat As String = ""


        For Each dataItem As GridDataItem In RadGrid1.SelectedItems
            strID = dataItem.GetDataKeyValue("RowID").ToString
            Dim lblshomarehgovahei As Label = DirectCast(dataItem.FindControl("lblshomarehgovahei"), Label)
            shomareh_Govahei = lblshomarehgovahei.Text
            Dim lblDateOfCreate As Label = DirectCast(dataItem.FindControl("lblDateOfCreate"), Label)
            Tarikh_Sodur_Govahei = lblDateOfCreate.Text
            name_Vamgirandeh = dataItem("LoanOwner_FirstName").Text.ToString + " " + dataItem("LoanOwner_LastName").Text.ToString
            Vamgirandeh_Pedar = dataItem("LoanOwner_FatherName").Text.ToString
            Dim lblLoanAmount As Label = DirectCast(dataItem.FindControl("lblLoanAmount"), Label)
            mablagh = lblLoanAmount.Text
            Bankname = dataItem("BankFullname").Text.ToString
            Select Case Val(dataItem("EshteghalID").Text.ToString)
                Case 1
                    EshteghalType = "شاغل در"
                Case 2
                    EshteghalType = "بازنشسته"
                Case Else

            End Select
            Jensiyat = dataItem("Prefix").Text.ToString
        Next
        If strID = "" Then
            Return
        End If
        Using sqlCon As New SqlConnection(utill.Connectionstring)
            Dim sqlSelectstring As String = "SELECT [Value],[name]  FROM [AppSettings] where [name]='orgtitle' OR  [name]='SignerPost' OR [name]='SignerName' OR [name]='MaliCode'   "
            Using selectCommand As New SqlCommand(sqlSelectstring, sqlCon)
                selectCommand.CommandType = CommandType.Text
                Try
                    sqlCon.Open()
                    Using sqldr As SqlDataReader = selectCommand.ExecuteReader()
                        If sqldr.HasRows Then
                            Do While sqldr.Read
                                Select Case sqldr("name").ToString.ToLower
                                    Case "orgtitle"
                                        OrgTitle = sqldr("Value").ToString
                                    Case "signerpost"
                                        SignerPost = sqldr("Value").ToString
                                    Case "signername"
                                        SignerName = sqldr("Value").ToString
                                    Case "malicode"
                                        MaliCode = sqldr("Value").ToString
                                End Select
                            Loop
                        End If

                    End Using
                Catch ex As Exception
                    utill.RegisterError(ex.Message, "Estelamha.aspx", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                End Try
            End Using
        End Using

        Session.Add("Bankname", Bankname)
        Session.Add("Shomarehnamehbank", txtshomareh.Text.Trim)
        Session.Add("Tarikhnamehbank", txttarikh.Text.Trim)
        Session.Add("shomareh_Govahei", shomareh_Govahei + "/" + MaliCode)
        Session.Add("Tarikh_Sodur_Govahei", Tarikh_Sodur_Govahei)
        ' Session.Add("FullTitle", "" + " " + Jensiyat & " " & Fullname & " " & "کارمند" & " " & EshteghalType & " " & "آموزش و پرورش ملایر")
        Session.Add("Fullname", Jensiyat & " " & Fullname)
        Session.Add("Eshteghal", EshteghalType)

        If name_Vamgirandeh.Contains("&nbsp;") Then
            name_Vamgirandeh = Fullname
        End If
        If Vamgirandeh_Pedar.Contains("&nbsp;") Then
            Vamgirandeh_Pedar = lblfather.Text
        End If

        Session.Add("name_Vamgirandeh", name_Vamgirandeh)
        Session.Add("Vamgirandeh_Pedar", Vamgirandeh_Pedar)
        Session.Add("mablagh", mablagh)
        Session.Add("SignerName", SignerName)
        Session.Add("SignerPost", SignerPost)

        Dim strupdate As String = "UPDATE [Govahies] Set [Shomareh_Nameh_Estelam_Bank] = @Shomareh_Nameh_Estelam_Bank, " _
                                  & " [Tarikh_Nameh_Estelam_Bank] = @Tarikh_Nameh_Estelam_Bank, [Sader_Konnandeh_Estelam] = @Sader_Konnandeh_Estelam ," _
                                  & " [Tarikh_Sodur_Estelam]=(getdate())   WHERE (RowID=@RowID)"
        Using connection As New SqlConnection(utill.Connectionstring)
            Using command As New SqlCommand(strupdate, connection)
                Dim adminmember As New AdminMembership()
                command.CommandType = CommandType.Text
                command.Parameters.Clear()
                command.Parameters.AddWithValue("@Shomareh_Nameh_Estelam_Bank", txtshomareh.Text.Trim)
                command.Parameters.AddWithValue("@Tarikh_Nameh_Estelam_Bank", txttarikh.Text.Trim)
                command.Parameters.AddWithValue("@Sader_Konnandeh_Estelam", adminmember.GetAdminFullname(HttpContext.Current.User.Identity.Name))
                command.Parameters.AddWithValue("@RowID", strID)
                Try
                    connection.Open()
                    command.ExecuteNonQuery()
                Catch ex As Exception
                    utill.RegisterError(ex.Message, "صدور استعلام", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                    Throw
                End Try
            End Using
        End Using
        Response.Redirect("./EstelamReport")

    End Sub

    Protected Sub btnExportToexcel_Click(sender As Object, e As ImageClickEventArgs) Handles btnExportToexcel.Click
        If RadGrid1.MasterTableView.Items.Count = 0 Then
            Return
        End If
        RadGrid1.MasterTableView.GetColumn("chkRow").Visible = False
        bindgrid()
        RadGrid1.ExportSettings.Excel.Format = DirectCast([Enum].Parse(GetType(GridExcelExportFormat), "Xlsx"), GridExcelExportFormat)
        RadGrid1.ExportSettings.IgnorePaging = True
        RadGrid1.ExportSettings.ExportOnlyData = False
        RadGrid1.ExportSettings.OpenInNewWindow = True
        RadGrid1.ExportSettings.FileName = "Sodur_Estelam"
        RadGrid1.MasterTableView.ExportToExcel()
        '  RadGrid1.MasterTableView.GetColumn("chkRow").Visible = True
    End Sub
    Protected Sub RadGrid1_GroupsChanging(sender As Object, e As GridGroupsChangingEventArgs) Handles RadGrid1.GroupsChanging
        bindgrid()
    End Sub
    Protected Sub RadGrid1_ColumnsReorder(sender As Object, e As GridColumnsReorderEventArgs) Handles RadGrid1.ColumnsReorder
        bindgrid()
    End Sub
    Protected Sub RadGrid1_PageIndexChanged(sender As Object, e As GridPageChangedEventArgs) Handles RadGrid1.PageIndexChanged ', RadGrid2.PageIndexChanged
        bindgrid()
    End Sub
    Protected Sub RadGrid1_PageSizeChanged(sender As Object, e As GridPageSizeChangedEventArgs) Handles RadGrid1.PageSizeChanged ', RadGrid2.PageSizeChanged
        bindgrid()
    End Sub
    Protected Sub RadGrid1_SortCommand(sender As Object, e As GridSortCommandEventArgs) Handles RadGrid1.SortCommand
        bindgrid()
    End Sub



End Class