﻿<%@ Page Title="بازنشانی رمز ورود کاربران سایت" Language="vb" AutoEventWireup="false" MasterPageFile="~/modiran/ModirMasterPage.Master" CodeBehind="ResetUserPassword.aspx.vb" Inherits="ZemanatNameh.vb.ResetUserPassword" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style type="text/css">
        .panel {
            margin-bottom: 10px;
            border-color: rgba(128, 120, 128, 0.53);
        }

        .panel-body {
            background-color: rgba(222, 217, 217, 0.5);
        }

        .RightAndLeftPadding {
            padding-right: 5px;
            padding-left: 5px;
        }
    </style>
    <script type="text/javascript">
        function isNumber(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }
    </script>

</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="MainContent" runat="Server">
    <div class=" container">
        <div class="row" id="main" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; background-color: whitesmoke">
            <div style="margin: 0 auto; width: 80%">
                <div class="panel panel-primary">
                    <div class="panel-heading text-center" style="padding: 10px; margin: 0px">
                        <h1 style="font-size: 1.2em; padding: 0px; margin: 0px">بازنشانی رمز ورود کاربران سایت</h1>
                    </div>
                    <div class="panel-body" style="padding: 10px 20px 10px 20px">
                        <div class="panel-heading " style="padding: 10px; margin: 0px">
                            <div id="info" style="text-align: justify; direction: rtl; line-height: 3em; border: 1px solid lightblue; padding: 8px;">
                                برای بازنشانی رمز کاربران سایت ابتدا فرد مورد نظر را با استفاده از شماره پرسنلی جستجو و سپس اقدام به بازنشانی رمز کنید.<br />
                                بعد از بازنشانی رمز ، رمز کاربر برابر با شماره پرسنلی آن فرد خواهد بود.
                            </div>
                            <asp:Panel runat="server" Style="width: 90%; margin: 0 auto; padding: 0px 10px 0px 10px; margin-bottom: 5px; margin-top: 5px; line-height: 25px; background-color: LightYellow"
                                ID="pnlmsg" CssClass="text-center">
                                <asp:ValidationSummary ValidationGroup="first" runat="server" ForeColor="red" BackColor="LightYellow" />
                                <asp:RequiredFieldValidator ValidationGroup="first" SetFocusOnError="true" ErrorMessage="شماره پرسنلی را وارد کنید" Text="" ControlToValidate="txtcode" runat="server" ForeColor="Red" Display="none" />
                                <asp:Label Font-Bold="true" runat="server" Text="" ForeColor="Red" ID="lblmsg" Visible="false" />
                            </asp:Panel>
                        </div>
                        <div id="panelbody" style="width: 60%;  margin: 0 auto" class="text-center">
                            <div class="row" >
                                <div class=" col-lg-8 col-md-8 col-sm-8 col-xs-8">
                                    <asp:TextBox runat="server" ID="txtcode" CssClass="form-control" placeholder="شماره پرسنلی"
                                        onfocus="document.getElementById('MainContent_lblmsg').style.display='none'"
                                        onkeypress="return isNumber(event)"
                                         ValidationGroup="first" />
                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                                    <asp:Button Text="جستجو" runat="server" CssClass="btn btn-primary" ID="btnsearch" ValidationGroup="first" />
                                </div>
                            </div>
                            <asp:Panel runat="server" ID="pnlstatus" Style="padding: 10px; margin-top: 8px;" Visible="false">
                                <div class="row" style="background-color: antiquewhite; padding: 5px; margin-top: 10px">
                                    <asp:Label Text="نام ونام خانوادگی:" runat="server" />
                                    <asp:Label ID="lblfullname" Text="" runat="server" />

                                    <div style="padding-top: 10px; margin: 0 auto" class="text-center">
                                        <div class=" col-lg-6 col-md-6 col-sm-6 col-xs-6 text-center">
                                            <asp:Button Text="بازنشانی رمز" runat="server" ID="btnresetpass" CssClass="btn btn-primary" Width="100px" />
                                        </div>
                                        <div class=" col-lg-6 col-md-6 col-sm-6 col-xs-6 text-center">
                                            <asp:Button Text="پاک کردن فرم" runat="server" ID="btnresetform" CssClass="btn btn-primary" Width="100px" />
                                        </div>
                                    </div>
                                </div>
                            </asp:Panel>


                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

</asp:Content>
<asp:Content ID="Content4" ContentPlaceHolderID="EndOfPageContent" runat="Server">
</asp:Content>
