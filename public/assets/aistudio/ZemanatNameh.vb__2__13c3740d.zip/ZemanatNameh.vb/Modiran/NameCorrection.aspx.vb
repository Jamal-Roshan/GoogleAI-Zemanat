﻿Public Class NameCorrection
    Inherits System.Web.UI.Page
    Private Utill As New Utility()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        If Me.Page.IsValid Then
            Dim code = Utill.Fa2En(txtcode.Text.Trim)
            If Not Utill.UserExist(code) Then
                lblmsg.Text = "کاربری با این شماره پرسنلی موجود نیست"
                lblmsg.Visible = True
                txtfirstname.Text = ""
                txtlastname.Text = ""
                txtfathername.Text = ""
                pnlstatus.Visible = False
                Return
            End If
            Dim m As New UserMembership
            txtfirstname.Text = m.GetUserFirstname(code)
            txtlastname.Text = m.GetUserLastname(code)
            txtfathername.Text = m.GetUserFathername(code)
            pnlstatus.Visible = True
            lblmsg.Text = ""
        End If
    End Sub

    Protected Sub btnsabt_Click(sender As Object, e As EventArgs) Handles btnsabt.Click
        Dim code = Utill.Fa2En(txtcode.Text.Trim)
        If code.Length < 8 Then
            lblmsg.Text = "كد پرسنلي وارد شده صحيح نيست"
            lblmsg.Visible = True
            Return
        End If
        Dim firstname = txtfirstname.Text.Trim()
        Dim lastname = txtlastname.Text.Trim()
        Dim fathernam = txtfathername.Text.Trim()

        If firstname = "" Then
            lblmsg.Text = "مقدار نام را وارد كنيد"
            lblmsg.Visible = True
            txtfirstname.Focus()
            Return
        End If
        If lastname = "" Then
            lblmsg.Text = "مقدار نام خانوادگي را وارد كنيد"
            lblmsg.Visible = True
            txtlastname.Focus()
            Return
        End If
        If fathernam = "" Then
            lblmsg.Text = "مقدار نام پدر را وارد كنيد"
            lblmsg.Visible = True
            txtfathername.Focus()
            Return
        End If
        lblmsg.Text = ""
        If Utill.UpdateUser_Firstname_Lastname_Fathername(code, firstname, lastname, fathernam) Then
            lblmsg.Text = "به روز رساني با موفقيت انجام شد"
            Utill.Set_RowValidationCode_For_Users_Table_By_Code(code)
            lblmsg.Visible = True
        Else
            lblmsg.Text = "عمليات بروزرساني با خطا مواجه شده است"
            lblmsg.Visible = True
        End If

    End Sub
    Protected Sub btnreset_Click(sender As Object, e As EventArgs) Handles btnreset.Click
        txtfirstname.Text = ""
        txtlastname.Text = ""
        txtcode.Text = ""
        txtfathername.Text = ""
        lblmsg.Visible = False
        lblmsg.Text = ""
        pnlstatus.Visible = False
        txtcode.Text = ""
    End Sub
End Class