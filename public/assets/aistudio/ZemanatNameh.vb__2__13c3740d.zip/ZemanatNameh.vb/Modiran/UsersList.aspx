﻿<%@ Page Title="فهرست کاربران سایت" Language="vb" AutoEventWireup="false" MasterPageFile="~/modiran/ModirMasterPage.Master" CodeBehind="UsersList.aspx.vb" Inherits="ZemanatNameh.vb.UsersList" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class=" container">

        <div class="row" id="Dashbord" style="direction: rtl; border: 1px solid lightgray; margin: 2px 6px 0px 6px; padding-top: 8px; background-color: whitesmoke">
            <asp:Panel runat="server" ID="pnlsearch" class="panel panel-danger">
                <div class="panel-heading text-center">
                    جستجو
                </div>
                <div class="panel-body">
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-4 ">
                        <asp:TextBox ID="txtcode" runat="server" CssClass="form-control" placeholder="شماره پرسنلی" ClientIDMode="Static" onkeypress="return isNumber(event)" />
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-4 ">
                        <asp:TextBox ID="txtfirstname" runat="server" CssClass="form-control" placeholder="نام" ClientIDMode="Static" />
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-4 ">
                        <asp:TextBox ID="txtlastname" runat="server" CssClass="form-control" placeholder="نام خانوادگی" ClientIDMode="Static" />
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6 ">
                        <asp:Button ID="btnfilter" Text="جستجو" runat="server" CssClass="btn btn-info" Width="100%" />
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6 ">
                        <asp:Button ID="btnclearfilter" Text="پاک کردن جستجو" runat="server" CssClass="btn btn-info" Width="100%" />
                    </div>
                </div>
                <asp:Panel runat="server" ID="pnlmsg" BackColor="LightYellow" Style="padding: 8px" Visible="false" CssClass=" text-center">
                    <asp:Label Text="موردی با مشخصات وارد شده موجود نیست" ID="lblmessage" runat="server" ForeColor="Red" />
                </asp:Panel>
            </asp:Panel>

            <asp:Panel runat="server" ID="pnlgrid" CssClass=" panel panel-primary">
                <div class="panel-heading text-center" style="padding: 10px; margin: 0px;">
                    فهرست کاربران سایت
                </div>
                <div class="panel-body" style="padding: 5px">
                    <asp:ImageButton ImageUrl="Images/other/excel.png" ID="btnExportToexcel" runat="server" ToolTip="ارسال به فایل اکسل" Height="35px" Visible="false" CausesValidation="false" formnovalidate="formnovalidate" />

                    <telerik:RadGrid ID="RadGrid1" runat="server" AllowPaging="True" CssClass="table-responsive" AllowSorting="True" AutoGenerateColumns="False" ClientSettings-Scrolling-AllowScroll="true"
                        BorderStyle="Solid" PageSize="100" Skin="Outlook" Font-Names="yekan" ShowGroupPanel="True" AllowFilteringByColumn="false">
                        <GroupingSettings CollapseAllTooltip="Collapse all groups"></GroupingSettings>

                        <ClientSettings EnableRowHoverStyle="true" EnableAlternatingItems="true" AllowDragToGroup="True">
                        </ClientSettings>
                        <GroupingSettings GroupContinuedFormatString="... ادامه گروه از صفحه قبل" GroupContinuesFormatString="ادامه گروه در صفحه بعد"
                            UnGroupButtonTooltip="برای لغو گروه بندی اینجا کلیک کنید" UnGroupTooltip="برای لغو گروه بندی گروه مورد نظر رابا ماوس از اینجا به بیرون بکشید" />
                        <GroupHeaderItemStyle Font-Bold="true" Font-Names="tahoma,arial" Font-Size="11px" />
                        <GroupPanel Font-Bold="true" Font-Names="tahoma,arial" Font-Size="11px" Font-Strikeout="False"
                            Text="برای گروه بندی بر اساس نام خانوادگی و محل خدمت  عنوان ستون مورد نظر را کشیده و در اینجا رها کنید"
                            Width="100%">
                            <PanelStyle Font-Bold="true" Font-Names="tahoma,arial" Font-Size="11px" Height="35px"
                                HorizontalAlign="Center" Width="100%" />
                            <PanelItemsStyle Font-Bold="true" Font-Names="tahoma,arial" Font-Size="11px" HorizontalAlign="Center" />
                        </GroupPanel>
                        <MasterTableView CssClass="table-responsive" DataKeyNames="code">
                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                <HeaderStyle Font-Bold="true" Width="20px" />
                            </RowIndicatorColumn>
                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                <HeaderStyle Font-Bold="true" Width="20px" />
                            </ExpandCollapseColumn>
                            <EditFormSettings>
                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                </EditColumn>
                            </EditFormSettings>
                            <Columns>

                                <telerik:GridTemplateColumn AllowFiltering="false" Groupable="False" HeaderText="ردیف" ReadOnly="True" UniqueName="radif" AllowSorting="true">
                                    <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Width="10px" Font-Names="yekan" VerticalAlign="Middle" />
                                    <ItemTemplate>
                                        <center>
                                            <asp:Label ID="Grid_RowNumber_Label" runat="server"  />
                                        </center>
                                    </ItemTemplate>
                                    <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="30px" />
                                    <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="Center" Width="10px" Font-Names="yekan" VerticalAlign="Middle" />
                                </telerik:GridTemplateColumn>

                                <telerik:GridTemplateColumn AllowFiltering="true" Groupable="False" HeaderText="شماره پرسنلی" ReadOnly="True" DataField="code" SortExpression="code">
                                    <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                    <ItemTemplate>
                                        <asp:Label Text='<%# Eval("code") %>' runat="server" />
                                    </ItemTemplate>
                                    <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="90px" />
                                    <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="center" Font-Names="yekan" VerticalAlign="Middle" />
                                </telerik:GridTemplateColumn>

                                <telerik:GridTemplateColumn AllowFiltering="true" Groupable="False" HeaderText="شماره ملی" ReadOnly="True" DataField="NationalID" SortExpression="NationalID">
                                    <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                    <ItemTemplate>
                                        <asp:Label Text='<%# Eval("NationalID") %>' runat="server" />
                                    </ItemTemplate>
                                    <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="40px" />
                                    <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="left" Font-Names="yekan" VerticalAlign="Middle" />
                                </telerik:GridTemplateColumn>

                                <telerik:GridBoundColumn DataField="Firstname" FilterControlAltText="Filter firstname column" HeaderText="نام" ReadOnly="True" UniqueName="firstname" Groupable="false" AllowSorting="true">
                                    <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="80px" Font-Bold="true" />
                                    <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                                </telerik:GridBoundColumn>

                                <telerik:GridBoundColumn DataField="Lastname" FilterControlAltText="Filter lastname column" HeaderText="نام خانوادگی" ReadOnly="True" UniqueName="lastname" Groupable="true" AllowSorting="true">
                                    <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="100px" Font-Bold="true" />
                                    <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                                </telerik:GridBoundColumn>

                                <telerik:GridBoundColumn DataField="Fathername" FilterControlAltText="Filter column1 column" HeaderText="نام پدر" ReadOnly="True" UniqueName="father" Groupable="false" AllowSorting="true" AllowFiltering="False">
                                    <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="80px" Font-Bold="true" />
                                    <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                                </telerik:GridBoundColumn>

                                <telerik:GridTemplateColumn AllowFiltering="false" Groupable="false" HeaderText="وضعیت اشتغال" ReadOnly="True" DataField="EshteghalID" UniqueName="eshteghaltype" AllowSorting="true" DataType="System.Int16" SortExpression="EshteghalID">
                                    <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                    <ItemTemplate>
                                        <asp:Label runat="server" Text='<%# Eshteghal(Eval("EshteghalID")) %>'></asp:Label>
                                    </ItemTemplate>
                                    <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="70px" />
                                    <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="right" Font-Names="yekan" VerticalAlign="Middle" />
                                </telerik:GridTemplateColumn>

                                <telerik:GridBoundColumn DataField="WorkPlace" FilterControlAltText="Filter WorkPlace column" HeaderText="محل خدمت" ReadOnly="True" UniqueName="WorkPlace" Groupable="true" AllowSorting="true" AllowFiltering="False">
                                    <HeaderStyle Font-Names="yekan" HorizontalAlign="Center" VerticalAlign="Middle" Width="100px" Font-Bold="true" />
                                    <ItemStyle CssClass="cellstyle" Font-Names="yekan" HorizontalAlign="Right" VerticalAlign="Middle" />
                                </telerik:GridBoundColumn>

                                <telerik:GridTemplateColumn AllowFiltering="false" Groupable="False" HeaderText="مبلغ خالص دریافتی" ReadOnly="True" DataField="MablaghKhales" SortExpression="MablaghKhales">
                                    <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                    <ItemTemplate>
                                        <asp:Label Text='<%# KhalesDryafti(Eval("MablaghKhales")) %>' runat="server" />
                                    </ItemTemplate>
                                    <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="50px" />
                                    <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="left" Font-Names="yekan" VerticalAlign="Middle" />
                                </telerik:GridTemplateColumn>

                                <telerik:GridTemplateColumn AllowFiltering="false" Groupable="False" HeaderText="شماره حساب" ReadOnly="True" DataField="AccountNumber" SortExpression="AccountNumber">
                                    <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                    <ItemTemplate>
                                        <asp:Label ID="acc" Text='<%# utill.En2Fa(Eval("AccountNumber")) %>' runat="server" />
                                    </ItemTemplate>
                                    <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="50px" />
                                    <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="left" Font-Names="yekan" VerticalAlign="Middle" />
                                </telerik:GridTemplateColumn>

                                <telerik:GridTemplateColumn AllowFiltering="false" Groupable="False" HeaderText="تعداد گواهی تسویه نشده" ReadOnly="True" DataField="NumberOfActiveGovahi" SortExpression="NumberOfActiveGovahi">
                                    <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                    <ItemTemplate>
                                        <asp:Label Text='<%# Eval("NumberOfActiveGovahi") %>' runat="server" />
                                    </ItemTemplate>
                                    <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="40px" />
                                    <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="center" Font-Names="yekan" VerticalAlign="Middle" />
                                </telerik:GridTemplateColumn>

                                <telerik:GridTemplateColumn AllowFiltering="false" Groupable="False" HeaderText="وضعیت مسدودی" ReadOnly="True" DataField="IsBlock" SortExpression="IsBlock" DataType="System.Boolean">
                                    <HeaderStyle Font-Bold="false" HorizontalAlign="Center" Font-Names="yekan" VerticalAlign="Middle" />
                                    <ItemTemplate>
                                        <asp:Label runat="server" Text='<%# GetBlockStatus(Eval("isblock")) %>' ForeColor='<%# getcolor(Eval("isblock")) %>' />
                                    </ItemTemplate>
                                    <HeaderStyle CssClass="TelerikRadgridItemStyle" Font-Bold="true" Width="70px" />
                                    <ItemStyle CssClass="TelerikRadgridItemStyle" HorizontalAlign="right" Font-Names="yekan" VerticalAlign="Middle" />
                                </telerik:GridTemplateColumn>
                            </Columns>
                        </MasterTableView>
                        <PagerStyle FirstPageToolTip="اولین صفحه"
                            Font-Strikeout="False" HorizontalAlign="Center" LastPageToolTip="آخرین صفحه"
                            NextPagesToolTip="صفحه بعد" NextPageToolTip="صفحه بعد" PageSizeLabelText="تعداد سطر های هر صفحه:"
                            PrevPagesToolTip="صفحه قبل" PrevPageToolTip="صفحه قبل" />
                        <FilterMenu EnableImageSprites="False">
                        </FilterMenu>
                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                        </HeaderContextMenu>
                    </telerik:RadGrid>

                </div>
            </asp:Panel>
        </div>
    </div>

    <telerik:RadAjaxManager ID="RadAjaxManager1" runat="server">
        <ClientEvents OnResponseEnd="TraceNodes(document);" />
        <AjaxSettings>
            <telerik:AjaxSetting AjaxControlID="RadGrid1">
                <UpdatedControls>
                    <telerik:AjaxUpdatedControl ControlID="RadGrid1" LoadingPanelID="RadAjaxLoadingPanel1"></telerik:AjaxUpdatedControl>
                </UpdatedControls>
            </telerik:AjaxSetting>
        </AjaxSettings>
    </telerik:RadAjaxManager>
    <telerik:RadAjaxLoadingPanel ID="RadAjaxLoadingPanel1" runat="server" BackgroundPosition="Top"></telerik:RadAjaxLoadingPanel>

    <%--<asp:SqlDataSource ID="SqlDataSource_for_grid" runat="server" SelectCommand="SELECT  [Code],[NationalID],  [Firstname], [Lastname], [Fathername], [EshteghalID], [WorkPlace], [MablaghKhales], [AccountNumber], 
        [IsBlock], [NumberOfActiveGovahi] FROM [Users_table] ORDER BY [Lastname],[Firstname],[Fathername]"></asp:SqlDataSource>--%>
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">
    <script>
        String.prototype.toPersianDigit = function (a) {
            return this.replace(/\d+/g, function (digit) {
                var enDigitArr = [], peDigitArr = [];
                for (var i = 0; i < digit.length; i++) {
                    enDigitArr.push(digit.charCodeAt(i));
                }
                for (var j = 0; j < enDigitArr.length; j++) {
                    peDigitArr.push(String.fromCharCode(enDigitArr[j] + ((!!a && a === true) ? 1584 : 1728)));
                }
                return peDigitArr.join('');
            });
        };

        function TraceNodes(Node) {
            if (Node.nodeType === 3 && Node.parentNode.localName !== "style" && Node.parentNode.localName !== "script")  //TextNode
                Node.nodeValue = Node.nodeValue.toPersianDigit();
            else
                for (var i = 0; i < Node.childNodes.length; i++)
                    TraceNodes(Node.childNodes[i]);
        }

        TraceNodes(document);
    </script>
    
    <script type="text/javascript">
        $(function () {
            $("#txtfirstname,#txtlastname").farsiInput();
        });
        function isNumber(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }
    </script>
</asp:Content>
