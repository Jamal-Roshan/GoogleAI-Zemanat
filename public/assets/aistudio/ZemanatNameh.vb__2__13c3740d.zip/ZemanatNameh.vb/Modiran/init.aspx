﻿<%@ Page Title="" Language="vb" AutoEventWireup="false" MasterPageFile="~/Modir/ModirMasterPage.Master" CodeBehind="init.aspx.vb" Inherits="ZemanatNameh.vb.init" %>
<%@ Register assembly="Stimulsoft.Report.Web" namespace="Stimulsoft.Report.Web" tagprefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
        <asp:Button Text="init" ID="gg" runat="server" />
    <br />
    <asp:Button Text="calc active govahie" ID="Button1" runat="server" />

</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="EndOfPageContent" runat="server">
    </asp:Content>
