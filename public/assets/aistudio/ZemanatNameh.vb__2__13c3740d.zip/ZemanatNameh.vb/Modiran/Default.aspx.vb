﻿Public Class _Default1
    Inherits System.Web.UI.Page
    Dim utill As New Utility()

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblstatus.Text = Utill.Labelupdate()
    End Sub

    Protected Sub btnchangestatus_Click(sender As Object, e As EventArgs) Handles btnchangestatus.Click
        Utill.ChangeWebsiteStatus()
        lblstatus.Text = Utill.Labelupdate()
    End Sub

End Class