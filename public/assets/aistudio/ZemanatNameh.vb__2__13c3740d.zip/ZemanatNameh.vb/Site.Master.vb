﻿Public Class Site
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim utill As New Utility
        If utill.IsUpdating Then
            Response.Redirect("./Updating", True)
        End If
    End Sub

End Class