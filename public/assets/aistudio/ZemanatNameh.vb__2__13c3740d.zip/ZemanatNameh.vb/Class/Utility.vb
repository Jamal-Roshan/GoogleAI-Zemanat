﻿Imports System.Data.SqlClient
Imports System.Globalization
Imports System.IO
Imports System.Linq
Imports System.Security.Cryptography
Public Class Utility
    Public Function Connectionstring() As String
        If HttpContext.Current.Application("ConnString") Is Nothing OrElse HttpContext.Current.Application("ConnString").ToString.Trim = "" Then
            Dim constr As String = ConfigurationManager.ConnectionStrings.Item("ZemanatnamehConnectionString").ToString
            Dim orgcode As String = System.Web.Configuration.WebConfigurationManager.AppSettings.Item("orgcode")
            Dim decconstr As String = Decrypt(constr, orgcode)
            HttpContext.Current.Application.Add("ConnString", decconstr)
        End If
        Return HttpContext.Current.Application("ConnString").ToString
    End Function
    ' "Data Source=.;Initial Catalog=Zemanatnameh;Persist Security Info=True; User ID=RayanRoshan;Password='Rayan_2017_1395@Case#0k_!$$'"
    Public Function IsUpdating() As Boolean
        Dim strselect As String = "SELECT [SiteIsUpdating]  FROM [Site_Status_Table] WHERE [rowid]=1"
        Dim ret As Boolean = False
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        While reader.Read()
                            If Convert.ToByte(reader.Item("SiteIsUpdating")) = 0 Then
                                ret = False
                            Else
                                ret = True
                            End If
                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ret
    End Function
    Public Function Labelupdate() As String
        If IsUpdating() Then
            Return "<span style='color:red;'>در حال به روزرسانی</span>"
        Else
            Return "<span style='color:Green;'>عادی</span>"
        End If
    End Function
    Public Sub ChangeWebsiteStatus()
        Using sqlCon As New SqlConnection(Connectionstring)
            Dim strsqlupdate As String = "UPDATE [Site_Status_Table] SET [SiteIsUpdating] = @SiteIsUpdating WHERE [rowid]=1"
            Using updatecommand As New SqlCommand(strsqlupdate, sqlCon)
                updatecommand.Parameters.Clear()
                If IsUpdating() Then
                    updatecommand.Parameters.AddWithValue("@SiteIsUpdating", 0)
                Else
                    updatecommand.Parameters.AddWithValue("@SiteIsUpdating", 1)
                End If
                Try
                    sqlCon.Open()
                    updatecommand.ExecuteNonQuery()
                Catch ex As Exception
                    RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                End Try
            End Using
        End Using
    End Sub
    Public Sub ChangeWebsiteStatusToUpdate(status As Boolean)
        Using sqlCon As New SqlConnection(Connectionstring)
            Dim strsqlupdate As String = "UPDATE [Site_Status_Table] SET [SiteIsUpdating] = @SiteIsUpdating WHERE [rowid]=1"
            Using updatecommand As New SqlCommand(strsqlupdate, sqlCon)
                updatecommand.Parameters.Clear()
                If status Then
                    updatecommand.Parameters.AddWithValue("@SiteIsUpdating", 1)
                Else
                    updatecommand.Parameters.AddWithValue("@SiteIsUpdating", 0)
                End If
                Try
                    sqlCon.Open()
                    updatecommand.ExecuteNonQuery()
                Catch ex As Exception
                    RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                End Try
            End Using
        End Using
    End Sub
    Public Function UserExist(ByVal code As String) As Boolean
        Dim strselect As String = "SELECT [Code] FROM [Users_table] WHERE [Code]=@Code"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", code)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            Return True
                        Else
                            Return False
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return False
    End Function

    Public Function InsertNewUser(record As String, ByVal NumberOfActiveGovahi As Integer) As String
        Dim strsqlinsert As String = "INSERT INTO [Users_table] ([Code],[NationalID],[Firstname],[Lastname],[Fathername],[GenderId],[CurrentMonth],[EstekhdamID],[EshteghalID]," _
        & " [WorkPlace],[MablaghHokm],[MablaghKhales],[Password],[RecordOperationID],[AccountNumber],[Role],[NumberOfActiveGovahi],[isActive]) VALUES(@Code,@NationalID,@Firstname,@Lastname,@Fathername,@GenderId,@CurrentMonth," _
        & " @EstekhdamID,@EshteghalID,@WorkPlace,@MablaghHokm,@MablaghKhales,@Password,@RecordOperationID,@AccountNumber,@Role,@NumberOfActiveGovahi,1)"
        Dim code As String = ""
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strsqlinsert, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    Dim parameters As String() = {"@Code", "@NationalID", "@Firstname", "@Lastname", "@Fathername", "@GenderId",
                        "@CurrentMonth", "@EstekhdamID", "@EshteghalID", "@WorkPlace", "@MablaghHokm", "@MablaghKhales",
                        "@AccountNumber"}

                    Dim query = From val In record.Split(","c)
                                Select (val.Trim())
                    Dim i As Integer = 0
                    For Each itm As String In query
                        If parameters(i).Contains("@Mablag") Then
                            Try
                                command.Parameters.AddWithValue(parameters(i), Double.Parse(itm))

                            Catch ex As Exception

                            End Try
                        ElseIf parameters(i).Contains("@CurrentMonth") Then
                            If itm.Length > 2 Then
                                command.Parameters.AddWithValue(parameters(i), itm.Substring(2))
                            Else
                                command.Parameters.AddWithValue(parameters(i), itm)
                            End If
                        ElseIf parameters(i).Contains("@GenderId") AndAlso itm.Contains("مرد") Then
                            command.Parameters.AddWithValue(parameters(i), 1)
                        ElseIf parameters(i).Contains("@GenderId") AndAlso itm.Contains("زن") Then
                            command.Parameters.AddWithValue(parameters(i), 2)
                        Else
                            command.Parameters.AddWithValue(parameters(i), itm)
                        End If
                        If parameters(i).Contains("@EstekhdamID") AndAlso Not IsNumeric(itm) Then
                            Dim co = record.Substring(0, record.IndexOf(",")).ToString()
                            Dim estekhdam = itm.ToString()

                            Return "شماره پرسنلی : " & co & " - نوع استخدام : " & estekhdam & "  نامعتبر"
                        End If
                        i += 1
                    Next
                    code = record.Substring(0, record.IndexOf(","))
                    command.Parameters.AddWithValue("@Password", BCrypt.Net.BCrypt.HashPassword(code, 4))
                    command.Parameters.AddWithValue("@RecordOperationID", 1)
                    command.Parameters.AddWithValue("@Role", Encrypt("user", code))
                    command.Parameters.AddWithValue("@NumberOfActiveGovahi", NumberOfActiveGovahi)

                    connection.Open()
                    command.ExecuteNonQuery()
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return record.Substring(0, record.IndexOf(","))
        End Try
        Return ""
    End Function

    Public Function UpdateUser(record As String, ByVal NumberOfActiveGovahi As Integer) As String
        Dim strsqlupdate As String = "UPDATE [Users_table] SET [NationalID] = @NationalID,[Firstname] = @Firstname,[Lastname] = @Lastname,[Fathername] = @Fathername,[GenderId] = @GenderId," _
            & " [CurrentMonth] = @CurrentMonth,[EstekhdamID] = @EstekhdamID,[EshteghalID] = @EshteghalID,[WorkPlace] = @WorkPlace,[MablaghHokm] = @MablaghHokm,[MablaghKhales] = @MablaghKhales," _
            & " [AccountNumber] = @AccountNumber,[RecordOperationID] = @RecordOperationID , [NumberOfActiveGovahi]=@NumberOfActiveGovahi," _
            & " [OperationDate] = getdate(), [isActive] = 1  WHERE [Code] = @Code"
        Dim code As String = ""
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strsqlupdate, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    Dim parameters As String() = {"@Code", "@NationalID", "@Firstname", "@Lastname", "@Fathername", "@GenderId",
                        "@CurrentMonth", "@EstekhdamID", "@EshteghalID", "@WorkPlace", "@MablaghHokm", "@MablaghKhales",
                        "@AccountNumber"}

                    Dim query = From val In record.Split(","c)
                                Select (val.Trim())
                    Dim i As Integer = 0
                    For Each itm As String In query
                        If parameters(i).Contains("@Mablag") Then
                            Try
                                command.Parameters.AddWithValue(parameters(i), Double.Parse(itm))

                            Catch ex As Exception

                            End Try
                        ElseIf parameters(i).Contains("@CurrentMonth") Then
                            If itm.Length > 2 Then
                                command.Parameters.AddWithValue(parameters(i), itm.Substring(2))
                            Else
                                command.Parameters.AddWithValue(parameters(i), itm)
                            End If
                        ElseIf parameters(i).Contains("@GenderId") AndAlso itm.Contains("مرد") Then
                            command.Parameters.AddWithValue(parameters(i), 1)
                        ElseIf parameters(i).Contains("@GenderId") AndAlso itm.Contains("زن") Then
                            command.Parameters.AddWithValue(parameters(i), 2)
                        Else
                            command.Parameters.AddWithValue(parameters(i), itm)
                        End If

                        i += 1
                    Next
                    code = record.Substring(0, record.IndexOf(","))
                    'command.Parameters.AddWithValue("@Code", code.ToString());
                    command.Parameters.AddWithValue("@RecordOperationID", 2)
                    command.Parameters.AddWithValue("@NumberOfActiveGovahi", NumberOfActiveGovahi)
                    'command.Parameters.AddWithValue("@Role", ("user"))
                    connection.Open()
                    command.ExecuteNonQuery()
                End Using
            End Using

        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return record.Substring(0, record.IndexOf(","))
        Finally
        End Try
        Return ""
    End Function

    Public Function Set_EshteghalID(EshteghalID As Integer) As String
        Dim strsqlupdate As String = "UPDATE [Users_table] SET [EshteghalID] = @EshteghalID" '  WHERE [Code] = @Code"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strsqlupdate, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@EshteghalID", EshteghalID)
                    connection.Open()
                    command.ExecuteNonQuery()
                End Using
            End Using

        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return ex.Message
        Finally
        End Try
        Return ""
    End Function
    Public Function Set_isActive(isActive As Integer) As String
        Dim strsqlupdate As String = "UPDATE [Users_table] SET [isActive] = @isActive" '  WHERE [Code] = @Code"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strsqlupdate, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@isActive", isActive)
                    connection.Open()
                    command.ExecuteNonQuery()
                End Using
            End Using

        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return ex.Message
        Finally
        End Try
        Return ""
    End Function


    Public Function UpdateUser_Firstname_Lastname_Fathername(code As String, firstname As String, lastname As String, fathername As String) As Boolean
        Dim strsqlupdate As String = "UPDATE [Users_table] SET [Firstname] = @Firstname,[Lastname] = @Lastname,[Fathername] = @Fathername  WHERE [Code] = @Code"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strsqlupdate, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Firstname", firstname.Replace("ي", "ی").Replace("ك", "ک"))
                    command.Parameters.AddWithValue("@Lastname", lastname.Replace("ي", "ی").Replace("ك", "ک"))
                    command.Parameters.AddWithValue("@Fathername", fathername.Replace("ي", "ی").Replace("ك", "ک"))
                    command.Parameters.AddWithValue("@Code", code)

                    connection.Open()
                    command.ExecuteNonQuery()
                End Using
            End Using

        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return False
        Finally
        End Try
        Return True
    End Function
    Public Sub RegisterError(ByVal ErrorMessage As String, ByVal PageName As String, ByVal MethodName As String)
        Dim strsqlinsert As String = "INSERT INTO [Error_Table] ([ErrorMessage],[PageName],[MethodName])  VALUES (@ErrorMessage,@PageName,@MethodName)"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strsqlinsert, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()

                    command.Parameters.AddWithValue("@ErrorMessage", ErrorMessage.Trim)
                    command.Parameters.AddWithValue("@PageName", PageName.Trim)
                    command.Parameters.AddWithValue("@MethodName", MethodName.Trim)
                    connection.Open()
                    command.ExecuteNonQuery()
                End Using
            End Using
        Catch ex As Exception

        End Try
    End Sub


    Public Function En2Fa(ByVal sStr As String) As String
        Dim sFrStr As String = ""
        If sStr.Length > 0 Then
            For Each ch As Char In sStr
                If Asc(ch) >= 48 And Asc(ch) <= 57 Then
                    ch = ChrW(Asc(ch) + 1728)
                End If
                sFrStr = sFrStr + ch
            Next
        End If
        Return sFrStr
    End Function

    Public Function Fa2En(ByVal sStr As String) As String
        Dim sFrStr As String = ""
        If sStr.Length > 0 Then
            For Each ch As Char In sStr
                If AscW(ch) >= 1776 And AscW(ch) <= 1785 Then
                    ch = ChrW(AscW(ch) - 1728)
                End If
                sFrStr = sFrStr + ch
            Next
        End If
        Return sFrStr
    End Function

    Public Function DateToString(dt As DateTime, Optional maybenulldate As Boolean = False) As String
        If maybenulldate Then
            If dt.ToString.Contains("1278") OrElse dt.ToString.Contains("1900") Then
                Return ""
            End If
        End If
        Dim pc As New PersianCalendar()
        Try
            Return (pc.GetYear(dt) & "/" & pc.GetMonth(dt) & "/" & pc.GetDayOfMonth(dt))
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return ""
        End Try

    End Function
    Public Function Encrypt(clearText As String, code As String) As String
        Dim EncryptionKey As String = code & "JAMAL2SPBNI92017"
        Dim clearBytes As Byte() = Encoding.Unicode.GetBytes(clearText)
        Using encryptor As Aes = Aes.Create()
            Dim pdb As New Rfc2898DeriveBytes(EncryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D,
         &H65, &H64, &H76, &H65, &H64, &H65,
         &H76})
            encryptor.Key = pdb.GetBytes(32)
            encryptor.IV = pdb.GetBytes(16)
            Using ms As New MemoryStream()
                Using cs As New CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write)
                    cs.Write(clearBytes, 0, clearBytes.Length)
                    cs.Close()
                End Using
                clearText = Convert.ToBase64String(ms.ToArray())
            End Using
        End Using
        Return clearText
    End Function
    Public Function Decrypt(cipherText As String, code As String) As String
        Dim EncryptionKey As String = code & "JAMAL2SPBNI92017"
        cipherText = cipherText.Replace(" ", "+")
        Dim cipherBytes As Byte() = Convert.FromBase64String(cipherText)
        Using encryptor As Aes = Aes.Create()
            Dim pdb As New Rfc2898DeriveBytes(EncryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D,
         &H65, &H64, &H76, &H65, &H64, &H65,
         &H76})
            encryptor.Key = pdb.GetBytes(32)
            encryptor.IV = pdb.GetBytes(16)
            Using ms As New MemoryStream()
                Using cs As New CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write)
                    cs.Write(cipherBytes, 0, cipherBytes.Length)
                    cs.Close()
                End Using
                cipherText = Encoding.Unicode.GetString(ms.ToArray())
            End Using
        End Using
        Return cipherText
    End Function

    Public Function Reverse(s As String) As String
        Dim charArray As Char() = s.ToCharArray()
        Array.Reverse(charArray)
        Return New String(charArray)
    End Function

    Public Function IsBlockedUser(ByVal code As String) As Boolean
        Dim strselect As String = "Select [IsBlock] FROM [Users_table] WHERE [Code]=@Code"
        Dim Result As Boolean = False
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", code)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            Dim b As Boolean = Boolean.Parse(reader.Item("IsBlock").ToString)
                            If Boolean.Parse(reader.Item("IsBlock").ToString) = False Then
                                Result = False
                            Else
                                Result = True
                            End If
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return Result
    End Function

    Public Function ActiveUser(ByVal code As String) As Boolean
        Dim strselect As String = "Select [IsActive] FROM [Users_table] WHERE [Code]=@Code"
        Dim Result As Boolean = False
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", code)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            If CType(reader.Item("IsActive"), Boolean) = False Then
                                Result = False
                            Else
                                Result = True
                            End If
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return Result
    End Function

    Public Function GetBlockResone(ByVal code As String) As String
        Dim strselect As String = "Select [BlockTip] FROM [Users_table] WHERE [Code]=@Code"
        Dim Result As String = ""
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", code)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            Result = reader.Item("BlockTip").ToString()
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return Result
    End Function
    Public Function SetBlockResone(ByVal code As String, ByVal BlockTip As String) As Boolean
        Dim strupdate As String = "UPDATE [Users_table]  Set [BlockTip] = @BlockTip WHERE [Code]=@code"
        Dim Result As Boolean = True
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strupdate, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", code)
                    command.Parameters.AddWithValue("@BlockTip", BlockTip)
                    connection.Open()
                    command.ExecuteNonQuery()
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Result = False
        End Try
        Return Result
    End Function
    Public Function SetBlockStatus(ByVal code As String, ByVal IsBlock As Boolean) As Boolean
        Dim strupdate As String = "UPDATE [Users_table]  Set [IsBlock] = @IsBlock WHERE [Code]=@code"
        Dim Result As Boolean = True
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strupdate, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", code)
                    command.Parameters.AddWithValue("@IsBlock", IsBlock)
                    connection.Open()
                    command.ExecuteNonQuery()
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Result = False
        End Try
        Return Result
    End Function

    Public Sub Set_Users_To_Inactive(ByVal eshteghalID As String)
        Dim strupdate As String = "UPDATE [Users_table]  Set [IsActive] = 0 WHERE [EshteghalID]=" & eshteghalID
        Dim Result As Boolean = True
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strupdate, connection)
                    command.CommandType = CommandType.Text
                    connection.Open()
                    command.ExecuteNonQuery()
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
    End Sub


    Public Sub Tasviyeh(ByVal RowID As String, ByVal username As String)
        Dim rid As Long = CType(RowID, Long)
        Dim strupdate As String = "UPDATE [Govahies]  Set [StateId] = 3,[Tasviyehby] = @Tasviyehby,[TasviyehDate] = GETDATE() WHERE (RowID = @RowID) AND ([StateId] <> 3)"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strupdate, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Tasviyehby", username)
                    command.Parameters.AddWithValue("@RowID", rid)
                    connection.Open()
                    command.ExecuteNonQuery()
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
    End Sub





    Public Function Calculate_Number_Of_Active_Govahie_By_Code(ByVal code As String) As Integer
        Dim active As Integer = 0
        Dim strselect As String = "Select count(code) As active  FROM [Govahies]  where code=@code  And StateId=1"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@code", code)
                    connection.Open()
                    active = CType((command.ExecuteScalar), Integer)
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return active
    End Function


    Public Function Get_Saved_RowValidationCode_For_Users_Table_By_Code(code As String) As Long
        Dim ret As Long = 0
        Dim strselect As String = "Select [RowValidationCode] FROM  [Users_table]   WHERE [Code]=@code"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@code", code)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            ret = CType(reader.Item("RowValidationCode"), Long)
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message & " - " & GetClientComputername(), "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ret
    End Function

    Public Function Get_Saved_RowValidationCode_For_Govaheis_Tabel_By_RowID(ByVal RowID As String) As Long
        Dim ret As Long = 0
        Dim strselect As String = "Select [RowValidationCode] FROM  [Govahies] WHERE [RowID]=@RowID"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@RowID", RowID)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            If Not IsDBNull(reader.Item("RowValidationCode")) Then
                                ret = CType(reader.Item("RowValidationCode"), Long)
                            End If

                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message & " - " & GetClientComputername(), "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ret
    End Function
    'Public Function Calculate_Hashed_RowValidationCode_For_Govaheis_Tabel_By_RowID(ByVal RowID As String) As String
    '    Dim strselect As String = "Select [Code],[LoanAmount],[StateId] FROM [Govahies] WHERE [RowID]=@RowID"
    '    Dim RowValidationCode As String = ""
    '    Try
    '        Using connection As New SqlConnection(connectionstring)
    '            Using command As New SqlCommand(strselect, connection)
    '                command.CommandType = CommandType.Text
    '                command.Parameters.AddWithValue("@RowID", RowID)
    '                connection.Open()
    '                Using reader As SqlDataReader = command.ExecuteReader()
    '                    If reader.HasRows Then
    '                        reader.Read()
    '                        Dim hash As String = ""
    '                        hash = BCrypt.Net.BCrypt.HashPassword(reader("Code").ToString() + reader("LoanAmount").ToString() + reader("StateId").ToString(), 4)
    '                        RowValidationCode = hash
    '                    End If
    '                End Using
    '            End Using
    '        End Using
    '    Catch ex As Exception
    '        RegisterError(ex.Message, "Class Utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
    '        Return ""
    '    End Try
    '    Return RowValidationCode
    'End Function
    'Public Function Calculate_Plain_RowValidationCode_For_Govaheis_Tabel_By_RowID(ByVal RowID As String) As String
    '    Dim strselect As String = "Select [Code],[LoanAmount],[StateId] FROM [Govahies] WHERE [RowID]=@RowID"
    '    Dim RowValidationCode As String = ""
    '    Try
    '        Using connection As New SqlConnection(connectionstring)
    '            Using command As New SqlCommand(strselect, connection)
    '                command.CommandType = CommandType.Text
    '                command.Parameters.AddWithValue("@RowID", RowID)
    '                connection.Open()
    '                Using reader As SqlDataReader = command.ExecuteReader()
    '                    If reader.HasRows Then
    '                        reader.Read()
    '                        RowValidationCode = (reader("Code").ToString() + reader("LoanAmount").ToString() + reader("StateId").ToString())
    '                    End If
    '                End Using
    '            End Using
    '        End Using
    '    Catch ex As Exception
    '        RegisterError(ex.Message, "Class Utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
    '        Return ""
    '    End Try
    '    Return RowValidationCode
    'End Function
    Public Sub Set_RowValidationCode_For_Govaheis_Table_By_RowID(ByVal RowID As String)
        Dim strupdate As String = "UPDATE [Govahies]  Set [RowValidationCode] = @RowValidationCode WHERE [ROWID]=@ROWID"
        Try
            Dim RowValidationCode As Long = Calculate_RowValidationCode_For_Govaheis_Tabel_By_RowID(RowID)
            Using conn As New SqlConnection(Connectionstring)
                Using sqlcommand As New SqlCommand(strupdate, conn)
                    sqlcommand.CommandType = CommandType.Text
                    sqlcommand.Parameters.Clear()
                    sqlcommand.Parameters.AddWithValue("@ROWID", RowID)
                    sqlcommand.Parameters.AddWithValue("@RowValidationCode", RowValidationCode)
                    conn.Open()
                    sqlcommand.ExecuteNonQuery()
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message & " - " & GetClientComputername(), "Class Utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Throw
        End Try
    End Sub
    Public Sub Set_RowValidationCode_For_Govaheis_Table_By_Code(ByVal code As String)
        Dim strupdate As String = "UPDATE [Govahies]  Set [RowValidationCode] = @RowValidationCode WHERE [ROWID]=@ROWID"
        Dim strselect As String = "Select [ROWID] from [Govahies]  WHERE [code]=@code"
        Dim ListRowID As New List(Of String)

        Try
            ListRowID.Clear()
            Using conn As New SqlConnection(Connectionstring)
                Using sqlcommand As New SqlCommand(strselect, conn)
                    sqlcommand.CommandType = CommandType.Text
                    sqlcommand.Parameters.Clear()
                    sqlcommand.Parameters.AddWithValue("@code", code)
                    conn.Open()
                    Using reader As SqlDataReader = sqlcommand.ExecuteReader()
                        Do While reader.Read
                            ListRowID.Add(reader("ROWID").ToString)
                        Loop
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "Class Utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Throw
        End Try

        For Each RowID As String In ListRowID
            Try
                Dim RowValidationCode As Long = Calculate_RowValidationCode_For_Govaheis_Tabel_By_RowID(RowID)
                Using conn As New SqlConnection(Connectionstring)
                    Using command As New SqlCommand(strupdate, conn)
                        command.CommandType = CommandType.Text
                        command.Parameters.Clear()
                        command.Parameters.AddWithValue("@ROWID", RowID)
                        command.Parameters.AddWithValue("@RowValidationCode", RowValidationCode)
                        conn.Open()
                        command.ExecuteNonQuery()
                    End Using
                End Using
            Catch ex As Exception
                RegisterError(ex.Message & " - " & GetClientComputername(), "Class Utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                Throw
            End Try
        Next
        ListRowID.Clear()
    End Sub
    'Public Function Calculate_Plain_RowValidationCode_For_Users_Table_By_Code(ByVal Code As String) As String
    '    Dim strselect As String = "Select [Code],[Firstname],[Lastname],[Fathername],[CurrentMonth],[EstekhdamID],[EshteghalID],[MablaghKhales],[IsBlock],[NumberOfActiveGovahi] FROM [Users_table] WHERE [Code]=@Code"
    '    Dim RowValidationCode As String = ""
    '    Try
    '        Using connection As New SqlConnection(connectionstring)
    '            Using command As New SqlCommand(strselect, connection)
    '                command.CommandType = CommandType.Text
    '                command.Parameters.AddWithValue("@Code", Code)
    '                connection.Open()
    '                Using reader As SqlDataReader = command.ExecuteReader()
    '                    If reader.HasRows Then
    '                        reader.Read()
    '                        RowValidationCode = (reader("Code").ToString() + "-" + reader("Firstname").ToString() + "-" + reader("Lastname").ToString() + "-" +
    '                              reader("Fathername").ToString() + "-" + reader("CurrentMonth").ToString() + "-" + reader("EstekhdamID").ToString() + "-" +
    '                              reader("EshteghalID").ToString() + "-" + reader("MablaghKhales").ToString() + "-" +
    '                              reader("IsBlock").ToString() + "-" + reader("NumberOfActiveGovahi").ToString())
    '                    End If
    '                End Using
    '            End Using
    '        End Using
    '    Catch ex As Exception
    '        RegisterError(ex.Message, "Class Utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
    '        Return ""
    '    End Try
    '    Return RowValidationCode
    'End Function
    'Public Function Calculate_Hashed_RowValidationCode_For_Users_Table_By_Code(ByVal Code As String) As String
    '    Dim strselect As String = "Select [Code],[Firstname],[Lastname],[Fathername],[CurrentMonth],[EstekhdamID],[EshteghalID],[MablaghKhales],[IsBlock],[NumberOfActiveGovahi] FROM [Users_table] WHERE [Code]=@Code"
    '    Dim RowValidationCode As String = ""
    '    Try
    '        Using connection As New SqlConnection(connectionstring)
    '            Using command As New SqlCommand(strselect, connection)
    '                command.CommandType = CommandType.Text
    '                command.Parameters.AddWithValue("@Code", Code)
    '                connection.Open()
    '                Using reader As SqlDataReader = command.ExecuteReader()
    '                    If reader.HasRows Then
    '                        reader.Read()
    '                        RowValidationCode = (reader("Code").ToString() + "-" + reader("Firstname").ToString() + "-" + reader("Lastname").ToString() + "-" +
    '                              reader("Fathername").ToString() + "-" + reader("CurrentMonth").ToString() + "-" + reader("EstekhdamID").ToString() + "-" +
    '                              reader("EshteghalID").ToString() + "-" + reader("MablaghKhales").ToString() + "-" +
    '                              reader("IsBlock").ToString() + "-" + reader("NumberOfActiveGovahi").ToString())

    '                        RowValidationCode = BCrypt.Net.BCrypt.HashPassword(RowValidationCode)
    '                    End If
    '                End Using
    '            End Using
    '        End Using
    '    Catch ex As Exception
    '        RegisterError(ex.Message, "Class Utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
    '        Return ""
    '    End Try
    '    Return RowValidationCode
    'End Function
    Public Sub Set_Number_Of_Active_Govahie_By_Code(ByVal code As String)
        Dim strupdate As String = "UPDATE [Users_table]   Set [NumberOfActiveGovahi] = @NumberOfActiveGovahi WHERE [Code]=@Code"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strupdate, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@code", code)
                    command.Parameters.AddWithValue("@NumberOfActiveGovahi", Calculate_Number_Of_Active_Govahie_By_Code(code))
                    connection.Open()
                    command.ExecuteNonQuery()
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message & " - " & GetClientComputername(), "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Throw
        End Try
        Set_RowValidationCode_For_Users_Table_By_Code(code)
    End Sub
    Public Sub Set_Number_Of_Active_Govahie_For_ALL_Users()
        Dim active As Integer = 0
        Dim strselect As String = "Select [Code] FROM [Users_table]"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        Do While reader.Read
                            Dim code As String = reader.Item("Code").ToString()
                            Set_Number_Of_Active_Govahie_By_Code(code)
                        Loop
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message & " - " & GetClientComputername(), "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Throw
        End Try
    End Sub

    Public Sub Set_RowValidationCode_For_Users_Table_By_Code(ByVal Code As String)
        Dim strupdate As String = "UPDATE [Users_table]  Set [RowValidationCode] = @RowValidationCode WHERE [Code]=@code"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strupdate, connection)
                    command.CommandType = CommandType.Text
                    connection.Open()
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)

                    command.Parameters.AddWithValue("@RowValidationCode", Calculate_RowValidationCode_For_Users_Table_By_Code(Code))
                    'Calculate_Hashed_RowValidationCode_For_Users_Table_By_Code(Code))
                    command.ExecuteNonQuery()
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message & " - " & GetClientComputername(), "Class Utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Throw
        End Try
    End Sub
    Private Sub Set_RowValidationCode_For_All_User_In_Users_Table()
        Dim strselect As String = "Select [Code] FROM [Users_table]"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            Do While (reader.Read)
                                Set_RowValidationCode_For_Users_Table_By_Code(reader("Code").ToString())
                            Loop
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message & " - " & GetClientComputername(), "Class UserAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Throw
        End Try
    End Sub

    Public Sub Set_RowValidationCode_For_All_Rows_In_Govaheis_Table()
        Dim strselect As String = "Select [ROWID] FROM [Govahies]"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            Do While (reader.Read)
                                Set_RowValidationCode_For_Govaheis_Table_By_RowID(reader.Item("ROWID").ToString())
                            Loop
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message & " - " & GetClientComputername(), "Class Utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Throw
        End Try
    End Sub

    Public Function Calculate_RowValidationCode_For_Users_Table_By_Code(ByVal Code As String) As Long
        Dim strselect As String = "Select [Code],[Firstname],[Lastname],[Fathername],[CurrentMonth],[EstekhdamID],[EshteghalID],[MablaghKhales],[IsBlock],[IsActive],[NumberOfActiveGovahi] FROM [Users_table] WHERE [Code]=@Code"
        Dim RowValidationCode As String = ""
        Dim Result As Long = 0
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            RowValidationCode = (reader("Code").ToString() + "-" + reader("Firstname").ToString() + "-" + reader("Lastname").ToString() + "-" +
                                  reader("Fathername").ToString() + "-" + reader("CurrentMonth").ToString() + "-" + reader("EstekhdamID").ToString() + "-" +
                                  reader("EshteghalID").ToString() + "-" + reader("MablaghKhales").ToString() + "-" +
                                  reader("IsBlock").ToString() + "-" + reader("IsActive").ToString() + "-" + reader("NumberOfActiveGovahi").ToString())
                            For Each ch As Char In RowValidationCode
                                Result += AscW(ch)
                            Next
                            'RowValidationCode = BCrypt.Net.BCrypt.HashPassword(RowValidationCode)
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message & " - " & GetClientComputername(), "Class Utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return 0
        End Try
        Return Result
    End Function
    Public Function Calculate_RowValidationCode_For_Govaheis_Tabel_By_RowID(ByVal RowID As String) As Long
        Dim strselect As String = "Select [Code],[LoanAmount],[StateId] FROM [Govahies] WHERE [RowID]=@RowID"
        Dim RowValidationCode As String = ""
        Dim Result As Long = 0
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.AddWithValue("@RowID", RowID)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            RowValidationCode = (reader("Code").ToString() + "-" + reader("LoanAmount").ToString() + "-" + reader("StateId").ToString())
                            For Each ch As Char In RowValidationCode
                                Result += AscW(ch)
                            Next
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message & " - " & GetClientComputername(), "Class Utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return 0
        End Try
        Return Result
    End Function
    Public Function Is_User_Data_Correct(ByVal Code As String) As Boolean
        Dim savedRowValidationCode As Long = Get_Saved_RowValidationCode_For_Users_Table_By_Code(Code)
        Dim calculatedRowValidationCode As Long = Calculate_RowValidationCode_For_Users_Table_By_Code(Code)
        If calculatedRowValidationCode <> savedRowValidationCode Then
            SetBlockStatus(HttpContext.Current.User.Identity.Name, True)
            SetBlockResone(HttpContext.Current.User.Identity.Name, "اطلاعات شما به صورت غیر مجاز تغییر یافته است.شما مجاز به دریافت گواهی حقوقی و ضمانت نامه نیستید")
            Return False
        End If
        Return True
    End Function
    Public Function Is_Govahie_Data_Correct(ByVal Code As String) As Boolean
        Dim strselect As String = "Select [RowID] FROM  [Govahies] WHERE [Code]=@Code"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            Do While reader.Read
                                If (Get_Saved_RowValidationCode_For_Govaheis_Tabel_By_RowID(reader.Item("RowID").ToString) <> Calculate_RowValidationCode_For_Govaheis_Tabel_By_RowID(reader.Item("RowID").ToString)) Then
                                    SetBlockStatus(HttpContext.Current.User.Identity.Name, True)
                                    SetBlockResone(HttpContext.Current.User.Identity.Name, "اطلاعات شما به صورت غیر مجاز تغییر یافته است.شما مجاز به دریافت گواهی حقوقی و ضمانت نامه نیستید")
                                    Return False
                                End If
                            Loop
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message & " - " & GetClientComputername(), "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return True
    End Function

#Region "get_govahies_information"

    Public Function Get_Number_Of_Active_Govahies_By_Code(ByVal Code As String) As Long
        Dim strselect As String = "Select COUNT(LoanAmount) FROM [Govahies] WHERE Code=@Code And StateId=1 And GovahiTypeID=1"
        Dim ReturnValue As Long = 0
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Try
                        ReturnValue = CType(command.ExecuteScalar, Long)
                    Catch ex As Exception
                        ReturnValue = 0
                        Err.Clear()
                    End Try

                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function

    Public Function Get_Number_Of_Active_Zemanatnameh_By_Code(ByVal Code As String) As Long
        Dim strselect As String = "Select COUNT(LoanAmount) FROM [Govahies] WHERE Code=@Code And StateId=1 And GovahiTypeID=2"
        Dim ReturnValue As Long = 0
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Try
                        ReturnValue = CType(command.ExecuteScalar, Long)
                    Catch ex As Exception
                        ReturnValue = 0
                        Err.Clear()
                    End Try
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function

    Public Function Get_Sum_Of_Active_Govahies_By_Code(ByVal Code As String) As Long
        Dim strselect As String = "Select SUM(LoanAmount) FROM [Govahies] WHERE Code=@Code And StateId=1 And GovahiTypeID=1"
        Dim ReturnValue As Long = 0
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Try
                        ReturnValue = CType(command.ExecuteScalar, Long)
                    Catch ex As Exception
                        ReturnValue = 0
                        Err.Clear()
                    End Try
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function

    Public Function Get_Sum_Of_Active_Zemanatnameh_By_Code(ByVal Code As String) As Long
        Dim strselect As String = "Select SUM(LoanAmount) FROM [Govahies] WHERE Code=@Code And StateId=1 And GovahiTypeID=2"
        Dim ReturnValue As Long = 0
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Try
                        ReturnValue = CType(command.ExecuteScalar, Long)
                    Catch ex As Exception
                        ReturnValue = 0
                        Err.Clear()
                    End Try
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function

    Public Function Get_Sum_Of_Active_Govahies_And_Zemanatnameh_By_Code(ByVal Code As String) As Long
        Return Get_Sum_Of_Active_Zemanatnameh_By_Code(Code) + Get_Sum_Of_Active_Govahies_By_Code(Code)
    End Function
    Public Function Get_Number_Of_Active_Govahies_And_Zemanatnameh_By_Code(ByVal Code As String) As Long
        Return Get_Number_Of_Active_Govahies_By_Code(Code) + Get_Number_Of_Active_Zemanatnameh_By_Code(Code)
    End Function

    Public Function Get_Khalesdaryafti_By_Code(ByVal Code As String) As Long
        Dim strselect As String = "Select [MablaghKhales] FROM [Users_table] WHERE Code=@Code"
        Dim ReturnValue As Long = 0
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Try
                        ReturnValue = CType(command.ExecuteScalar, Long)
                    Catch ex As Exception
                        ReturnValue = 0
                        Err.Clear()
                    End Try
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function

    Public Function Get_CurrentMonth_By_Code(ByVal Code As String) As Byte
        Dim strselect As String = "Select [CurrentMonth] FROM [Users_table] WHERE Code=@Code"
        Dim ReturnValue As Byte = 0
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Try
                        ReturnValue = CType(command.ExecuteScalar, Byte)
                    Catch ex As Exception
                        ReturnValue = 0
                        Err.Clear()
                    End Try
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function
    Public Function Get_GenderId_By_Code(ByVal Code As String) As Byte
        Dim strselect As String = "Select [GenderId] FROM [Users_table] WHERE Code=@Code"
        Dim ReturnValue As Byte = 0
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Try
                        ReturnValue = CType(command.ExecuteScalar, Byte)
                    Catch ex As Exception
                        ReturnValue = 0
                        Err.Clear()
                    End Try
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function
    Public Function Get_EstekhdamID_By_Code(ByVal Code As String) As Byte
        Dim strselect As String = "Select [EstekhdamID] FROM [Users_table] WHERE Code=@Code"
        Dim ReturnValue As Byte = 0
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Try
                        ReturnValue = CType(command.ExecuteScalar, Byte)
                    Catch ex As Exception
                        ReturnValue = 0
                        Err.Clear()
                    End Try
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function
    Public Function Get_EshteghalID_By_Code(ByVal Code As String) As Byte
        Dim strselect As String = "Select [EshteghalID] FROM [Users_table] WHERE Code=@Code"
        Dim ReturnValue As Byte = 0
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Try
                        ReturnValue = CType(command.ExecuteScalar, Byte)
                    Catch ex As Exception
                        ReturnValue = 0
                        Err.Clear()
                    End Try
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function

    Public Function Get_Fullname_By_Code(ByVal Code As String) As String
        Dim strselect As String = "Select [Firstname],[Lastname] FROM [Users_table] WHERE Code=@Code"
        Dim ReturnValue As String = ""
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            Do While reader.Read
                                ReturnValue = reader("Firstname").ToString() & " " & reader("Lastname").ToString()
                            Loop
                        End If
                    End Using

                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function

    Public Function Get_Firstname_By_Code(ByVal Code As String) As String
        Dim strselect As String = "Select [Firstname] FROM [Users_table] WHERE Code=@Code"
        Dim ReturnValue As String = ""
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            Do While reader.Read
                                ReturnValue = reader("Firstname").ToString()
                            Loop
                        End If
                    End Using

                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function

    Public Function Get_Lastname_By_Code(ByVal Code As String) As String
        Dim strselect As String = "Select [Lastname] FROM [Users_table] WHERE Code=@Code"
        Dim ReturnValue As String = ""
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            Do While reader.Read
                                ReturnValue = reader("Lastname").ToString()
                            Loop
                        End If
                    End Using

                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function

    Public Function Get_Fathername_By_Code(ByVal Code As String) As String
        Dim strselect As String = "Select [Fathername] FROM [Users_table] WHERE Code=@Code"
        Dim ReturnValue As String = ""
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            Do While reader.Read
                                ReturnValue = reader("Fathername").ToString()
                            Loop
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function
    Public Function Get_WorkPlace_By_Code(ByVal Code As String) As String
        Dim strselect As String = "Select [WorkPlace] FROM [Users_table] WHERE Code=@Code"
        Dim ReturnValue As String = ""
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Try
                        ReturnValue = command.ExecuteScalar.ToString
                    Catch ex As Exception
                        ReturnValue = ""
                        Err.Clear()
                    End Try
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function
    Public Function Get_AccountNumber_By_Code(ByVal Code As String) As String
        Dim strselect As String = "Select [AccountNumber] FROM [Users_table] WHERE Code=@Code"
        Dim ReturnValue As String = ""
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Try
                        ReturnValue = command.ExecuteScalar.ToString
                    Catch ex As Exception
                        ReturnValue = ""
                        Err.Clear()
                    End Try
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function
    Public Function Get_OperationDate_By_Code(ByVal Code As String) As Date
        Dim strselect As String = "Select [OperationDate] FROM [Users_table] WHERE Code=@Code"
        Dim ReturnValue As Date
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Try
                        ReturnValue = CType(command.ExecuteScalar, Date)
                    Catch ex As Exception

                        Err.Clear()
                    End Try
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function
    Public Function Get_NationalID_By_Code(ByVal Code As String) As String
        Dim strselect As String = "Select [NationalID] FROM [Users_table] WHERE Code=@Code"
        Dim ReturnValue As String = ""
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Code)
                    connection.Open()
                    Try
                        ReturnValue = command.ExecuteScalar.ToString
                    Catch ex As Exception
                        ReturnValue = ""
                        Err.Clear()
                    End Try
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function


    Public Function GetGovahiType(id As Integer) As String
        Dim ret As String = ""
        Dim strselect As String = "Select [Title] FROM [GovahiTypes] where [Id]=@id"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@id", id)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            ret = reader.Item("Title").ToString()
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ret
    End Function
    Public Function GetGovahiStatus(id As Integer) As String
        Dim ret As String = ""
        Dim strselect As String = "Select  [Title]  FROM [Govahistatus] where [Status_ID]=@id"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@id", id)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            ret = reader.Item("Title").ToString()
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ret
    End Function
    Public Function Get_GenderID_Prefix_Title_By_GenderID(ByVal Genders_ID As Integer, ByRef Title As String) As String
        Dim strselect As String = "Select [Prefix],[Title] FROM [Genders] WHERE [Genders_ID]=@Genders_ID"
        Dim ReturnValue As String = ""
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Genders_ID", Genders_ID)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            Do While reader.Read
                                Title = reader("Title").ToString()
                                ReturnValue = reader("Prefix").ToString()
                            Loop
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function

    Public Function Get_GovahiTypes_By_GovahiTypeID(ByVal GovahiTypeID As Integer) As String
        Dim strselect As String = "Select [Title] FROM [GovahiTypes] WHERE [Id]=@GovahiTypeID"
        Dim ReturnValue As String = ""
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@GovahiTypeID", GovahiTypeID)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            Do While reader.Read
                                ReturnValue = reader("Title").ToString()
                            Loop
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function

    Public Function Get_EstekhdamType_By_EstekhdamID(ByVal EstekhdamID As Integer) As String
        Dim strselect As String = "Select [Title] FROM [EmployeeTypes] WHERE [Type_ID]=@EstekhdamID"
        Dim ReturnValue As String = ""
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@EstekhdamID", EstekhdamID)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            Do While reader.Read
                                ReturnValue = reader("Title").ToString()
                            Loop
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function

    Public Function Get_EshteghalType_By_EshteghalID(ByVal EshteghalID As Integer) As String
        Dim strselect As String = "Select [Title] FROM [Vaziyat_Eshteghal] WHERE [EshteghalID]=@EshteghalID"
        Dim ReturnValue As String = ""
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@EshteghalID", EshteghalID)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            Do While reader.Read
                                ReturnValue = reader("Title").ToString()
                            Loop
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function

    Public Function Get_Relatives_By_RelativesID(ByVal Relatives_ID As Integer) As String
        Dim strselect As String = "Select [Title] FROM [Relatives] WHERE [Relatives_ID]=@Relatives_ID"
        Dim ReturnValue As String = ""
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Relatives_ID", Relatives_ID)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            Do While reader.Read
                                ReturnValue = reader("Title").ToString()
                            Loop
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ReturnValue
    End Function
    Function Get_Application_Settings(ByVal settingname As String) As String
        Dim ReturnValue As String = ""
        Using sqlCon As New SqlConnection(Connectionstring)
            Dim sqlSelectstring As String = "Select [Value],[name]  FROM [AppSettings] where [name]=@name "
            Using selectCommand As New SqlCommand(sqlSelectstring, sqlCon)
                selectCommand.CommandType = CommandType.Text
                selectCommand.Parameters.Clear()
                selectCommand.Parameters.AddWithValue("@name", settingname)
                Try
                    sqlCon.Open()
                    Using sqldr As SqlDataReader = selectCommand.ExecuteReader()
                        If sqldr.HasRows Then
                            Do While sqldr.Read
                                ReturnValue = sqldr("Value").ToString
                            Loop
                        End If
                    End Using
                Catch ex As Exception
                    RegisterError(ex.Message, "Utility Class", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                End Try
            End Using
        End Using
        Return ReturnValue
    End Function

    Function Get_OrgCode() As String
        Dim Returnvalue As String = ""
        Using sqlCon As New SqlConnection(Connectionstring)
            Dim sqlSelectstring As String = "Select [Value]  FROM [AppSettings] where [name]='OrgCode' "
            Using selectCommand As New SqlCommand(sqlSelectstring, sqlCon)
                selectCommand.CommandType = CommandType.Text
                Try
                    sqlCon.Open()
                    Using sqldr As SqlDataReader = selectCommand.ExecuteReader()
                        If sqldr.HasRows Then
                            Do While sqldr.Read
                                Returnvalue = sqldr("Value").ToString
                            Loop
                        End If
                    End Using
                Catch ex As Exception
                    RegisterError(ex.Message, "Utility Class", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                End Try
            End Using
        End Using
        Return Returnvalue
    End Function
    Function Get_Latest_Shomareh() As Long
        Dim Returnvalue As Long = 0
        Using sqlCon As New SqlConnection(Connectionstring)
            Dim sqlSelectstring As String = "Select [Value]  FROM [AppSettings] where [name]='Shomareh' "
            Using selectCommand As New SqlCommand(sqlSelectstring, sqlCon)
                selectCommand.CommandType = CommandType.Text
                Try
                    sqlCon.Open()
                    Using sqldr As SqlDataReader = selectCommand.ExecuteReader()
                        If sqldr.HasRows Then
                            Do While sqldr.Read
                                Returnvalue = CType(sqldr("Value"), Long)
                            Loop
                        End If
                    End Using
                Catch ex As Exception
                    RegisterError(ex.Message, "Utility Class", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                End Try
            End Using
        End Using
        Return Returnvalue
    End Function

    Sub Set_Shomareh(ByVal shomareh As Long)
        Using sqlCon As New SqlConnection(Connectionstring)
            Dim sqlUpdatestring As String = "UPDATE [AppSettings] SET [Value] = @Value WHERE [Name]='Shomareh' "
            Using UpdateCommand As New SqlCommand(sqlUpdatestring, sqlCon)
                UpdateCommand.CommandType = CommandType.Text
                UpdateCommand.Parameters.Clear()
                UpdateCommand.Parameters.AddWithValue("@Value", shomareh)
                Try
                    sqlCon.Open()
                    UpdateCommand.ExecuteNonQuery()
                Catch ex As Exception
                    RegisterError(ex.Message, "Utility Class", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                End Try
            End Using
        End Using
    End Sub

    Function Get_Last_Saved_RowID_By_Code(ByVal Code As String) As String
        Dim Returnvalue As String = ""
        Using sqlCon As New SqlConnection(Connectionstring)
            Dim sqlSelectstring As String = "SELECT TOP (1) [RowID] FROM [Govahies] WHERE Code=@Code ORDER BY DateOfCreate DESC "
            Using selectCommand As New SqlCommand(sqlSelectstring, sqlCon)
                selectCommand.CommandType = CommandType.Text
                selectCommand.Parameters.Clear()
                selectCommand.Parameters.AddWithValue("@Code", Code)
                Try
                    sqlCon.Open()
                    Using sqldr As SqlDataReader = selectCommand.ExecuteReader()
                        If sqldr.HasRows Then
                            Do While sqldr.Read
                                Returnvalue = sqldr("RowID").ToString
                            Loop
                        End If
                    End Using
                Catch ex As Exception
                    RegisterError(ex.Message, "Utility Class", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                End Try
            End Using
        End Using
        Return Returnvalue
    End Function

#End Region
    Function Get_PersianMonthName(ByVal month As Integer) As String
        Dim ReturnValue As String = ""
        Select Case month
            Case 1
                ReturnValue = "فروردین"
            Case 2
                ReturnValue = "اردیبهشت"
            Case 3
                ReturnValue = "خرداد"
            Case 4
                ReturnValue = "تیر"
            Case 5
                ReturnValue = "مرداد"
            Case 6
                ReturnValue = "شهریور"
            Case 7
                ReturnValue = "مهر"
            Case 8
                ReturnValue = "آبان"
            Case 9
                ReturnValue = "آذر"
            Case 10
                ReturnValue = "دی"
            Case 11
                ReturnValue = "بهمن"
            Case 12
                ReturnValue = "اسفند"
        End Select
        Return ReturnValue
    End Function

    Function GetPersianDate(ByVal dt As Date) As String
        Dim pc As New PersianCalendar()
        Try
            Return (pc.GetYear(dt) & "/" & pc.GetMonth(dt) & "/" & pc.GetDayOfMonth(dt))
        Catch ex As Exception
            RegisterError(ex.Message & "** " & dt.ToString() & " ** - " & GetclientComputername(), "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return ""
        End Try
    End Function
    Function GetPersianYear(ByVal dt As Date) As String
        Dim pc As New PersianCalendar()
        Try
            Return pc.GetYear(dt).ToString
        Catch ex As Exception
            RegisterError(ex.Message & "** " & dt.ToString() & " ** - " & GetclientComputername(), "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return ""
        End Try
    End Function
    Function GetPersianMonth(ByVal dt As Date) As Integer
        Dim pc As New PersianCalendar()
        Try
            Return pc.GetMonth(dt)
        Catch ex As Exception
            RegisterError(ex.Message & "** " & dt.ToString() & " ** - " & GetclientComputername(), "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return 0
        End Try
    End Function
    Function AllowedToGetGovahie(ByVal code As String) As Boolean
        Dim ReturnValue As Boolean = False

        Dim maxzemanat As Long = Get_Khalesdaryafti_By_Code(Code:=code) * CType(Get_Application_Settings(AppSettings.zarib.ToString), Long)
        Dim mazad As Byte = CType(Get_Application_Settings(AppSettings.mazad.ToString), Byte)
        Dim mincredit As Long = CType(Get_Application_Settings(AppSettings.mincredit.ToString), Long)
        Dim Sum_Of_Active_Govahies_And_Zemanatnameh As Long = Get_Sum_Of_Active_Govahies_And_Zemanatnameh_By_Code(code)
        Dim khalesdaryafti As Long = Get_Khalesdaryafti_By_Code(code)
        Dim mablaghmojaz As Long = maxzemanat - Sum_Of_Active_Govahies_And_Zemanatnameh

        If mablaghmojaz <= 0 Then
            If mazad = 0 Then
                ReturnValue = False
            Else
                ReturnValue = True
            End If

        ElseIf khalesdaryafti < mincredit Then
            ReturnValue = False
        Else
            ReturnValue = True
        End If
        Return ReturnValue
    End Function
    Function AllowedToGetGovahie_For_User(ByVal code As String) As Boolean
        Dim ReturnValue As Boolean = False

        Dim maxzemanat As Long = Get_Khalesdaryafti_By_Code(Code:=code) * CType(Get_Application_Settings(AppSettings.zarib.ToString), Long)
        Dim mincredit As Long = CType(Get_Application_Settings(AppSettings.mincredit.ToString), Long)
        Dim Sum_Of_Active_Govahies_And_Zemanatnameh As Long = Get_Sum_Of_Active_Govahies_And_Zemanatnameh_By_Code(code)
        Dim khalesdaryafti As Long = Get_Khalesdaryafti_By_Code(code)
        Dim mablaghmojaz As Long = maxzemanat - Sum_Of_Active_Govahies_And_Zemanatnameh

        If mablaghmojaz <= 0 Then
            ReturnValue = False
        ElseIf khalesdaryafti < mincredit Then
            ReturnValue = False
        Else
            ReturnValue = True
        End If
        Return ReturnValue
    End Function

    Public Function GetBankname() As DataTable
        Dim dt As New DataTable()

        Dim sqlSelectstring As String = "SELECT [Bankfullname] FROM [Banks] order by [Bankfullname] "
        Using connection As New SqlConnection(Connectionstring)
            Using command As New SqlCommand(sqlSelectstring, connection)
                command.CommandType = CommandType.Text
                Using sda As New SqlDataAdapter(command)
                    Try
                        dt.Clear()
                        sda.Fill(dt)
                    Catch ex As Exception

                    End Try
                End Using
            End Using
        End Using
        Return dt
    End Function
    Public Function Vaziyat_Soudur(ByVal code As String) As Byte
        Dim maxzemanat As Long = Get_Khalesdaryafti_By_Code(Code:=code) * CType(Get_Application_Settings(AppSettings.zarib.ToString), Long)
        Dim Sum_Of_Active_Govahies_And_Zemanatnameh As Long = Get_Sum_Of_Active_Govahies_And_Zemanatnameh_By_Code(code)
        Dim khalesdaryafti As Long = Get_Khalesdaryafti_By_Code(code)
        Dim mablaghmojaz As Long = maxzemanat - Sum_Of_Active_Govahies_And_Zemanatnameh
        If mablaghmojaz <= 0 Then
            Return 2 'مازاد
        Else
            Return 1 'مجاز
        End If
    End Function
    Public Function Vaziyat_Soudur_To_String(ByVal Vaziyat_Soudur As Byte) As String
        Dim ret As String = ""
        Select Case Vaziyat_Soudur
            Case 1
                ret = "مجاز"
            Case 2
                ret = "مازاد"
        End Select
        Return ret
    End Function
    Public Function Get_Name_Of_SaderKonandeh(ByVal RowID As Long) As String
        Dim ret As String = ""
        Dim strselect As String = "Select [Sader_Konandeh] FROM  [Govahies] WHERE [RowID]=@RowID"
        Try
            Using connection As New SqlConnection(Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@RowID", RowID)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            ret = CType(reader.Item("Sader_Konandeh"), String)
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            RegisterError(ex.Message & " - " & GetclientComputername(), "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return ret
    End Function
    Private Function GetClientComputername() As String
        Try
            Dim hName As String = ""
            Dim host As System.Net.IPHostEntry = New System.Net.IPHostEntry()
            host = System.Net.Dns.GetHostEntry(HttpContext.Current.Request.ServerVariables("REMOTE_HOST"))

            'Split out the host name from the FQDN
            'If host.HostName.Contains(".") Then
            '    Dim sSplit() As String = host.HostName.Split("."c)
            '    hName = sSplit(0).ToString()
            'Else
            '    hName = host.HostName.ToString()
            'End If
            hName = host.HostName.ToString()
            Return hName
        Catch ex As Exception
            RegisterError(ex.Message, "class utility", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return ""
        End Try

    End Function
End Class
