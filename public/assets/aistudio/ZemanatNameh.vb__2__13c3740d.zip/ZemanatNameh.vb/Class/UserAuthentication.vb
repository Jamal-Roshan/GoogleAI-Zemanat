﻿Imports System.Data.SqlClient
Imports System.Data
''' <summary>
''' Authenticates user agains the data source
''' </summary>
Public Class UserAuthentication
    Public Shared ReadOnly Property Instance() As UserAuthentication
        Get
            Return New UserAuthentication()
        End Get
    End Property
    Private Utill As New Utility()
    '
    ' TODO: Add constructor logic here
    '
    Public Sub New()
    End Sub

    ''' <summary>
    ''' Authenticates user agains a data source and populates the user roles
    ''' in the out parameter
    ''' </summary>
    ''' <param name="userName"></param>
    ''' <param name="password"></param>
    ''' <param name="commaSeperatedRoles"></param>
    ''' <returns></returns>
    Public Function AuthenticateUser(userName As String, password As String, ByRef commaSeperatedRoles As String) As Boolean
        Dim um As New UserMembership
        Dim Savedpassword As String = um.Get_user_saved_Password(userName)
        If Savedpassword.Length <= 0 Then
            Return False
        End If
        If Not (BCrypt.Net.BCrypt.Verify(password, Savedpassword)) Then
            Return False
        End If

        Dim success As Boolean = False
        commaSeperatedRoles = String.Empty
        Dim strselect As String = "SELECT [Role] FROM [Users_table] Where ([Code]=@Code)"
        Try
            Using connection As New SqlConnection(Utill.connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", userName)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            success = True
                            While reader.Read()
                                commaSeperatedRoles = Utill.Decrypt(reader("Role").ToString(), userName)
                            End While

                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            Utill.RegisterError(ex.Message, "Class UserAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            success = False
        End Try
        Return success
    End Function

    Public Function AuthenticateAdmin(userName As String, password As String, ByRef commaSeperatedRoles As String) As Boolean
        Dim AM As New AdminMembership
        Dim Savedpassword As String = AM.Get_Admin_saved_Password(userName)
        If Savedpassword.Length <= 0 Then
            Return False
        End If
        If Not (BCrypt.Net.BCrypt.Verify(password, Savedpassword)) Then
            Return False
        End If

        Dim success As Boolean = False
        commaSeperatedRoles = String.Empty
        Dim strselect As String = "SELECT [Role] FROM [Administrators] Where ([Code]=@Code)"
        Try
            Using connection As New SqlConnection(Utill.connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", userName)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            success = True
                            While reader.Read()
                                commaSeperatedRoles = Utill.Decrypt(reader("Role").ToString(), userName)
                            End While

                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            Utill.RegisterError(ex.Message, "Class UserAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            success = False
        End Try
        Return success
    End Function


End Class
