﻿Imports System.Data.SqlClient
Public Class UserMembership
    Dim utill As New Utility()
    ''' <summary>
    ''' دریافت نام کاربر
    ''' </summary>
    ''' <param name="userName"></param>
    ''' <returns> نام کاربر</returns>
    Public Function GetUserFirstname(ByVal Username As String) As String
        Dim Firstname As String = ""
        Dim strselect As String = "SELECT [Firstname] FROM [Users_table] Where ([Code]=@Code)"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Username)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            Firstname = reader("Firstname").ToString()
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class UserAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return Firstname
    End Function
    ''' <summary>
    ''' دریافت نام خانوادگی کاربر
    ''' </summary>
    ''' <param name="userName"></param>
    ''' <returns> نام خانوادگی کاربر</returns>
    Public Function GetUserLastname(ByVal Username As String) As String
        Dim LastName As String = ""
        Dim strselect As String = "SELECT [LastName] FROM [Users_table] Where ([Code]=@Code)"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Username)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            LastName = reader("LastName").ToString()
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class UserAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return LastName
    End Function
    ''' <summary>
    ''' دریافت نام پدر
    ''' </summary>
    ''' <param name="userName"></param>
    ''' <returns> نام پدر</returns>
    Public Function GetUserFathername(ByVal Username As String) As String
        Dim Fathername As String = ""
        Dim strselect As String = "SELECT [Fathername] FROM [Users_table] Where ([Code]=@Code)"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Username)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            Fathername = reader("Fathername").ToString()
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class UserAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return Fathername
    End Function
    ''' <summary>
    ''' دریافت نام و نام خانوادگی کاربر
    ''' </summary>
    ''' <param name="userName"></param>
    ''' <returns> نام و نام خانوادگی کاربر</returns>
    Public Function GetUserFullname(ByVal Username As String) As String
        Return GetUserFirstname(Username) + " " + GetUserLastname(Username)
    End Function
    ''' <summary>
    ''' دریافت رشته نقش کاربر به صورت کد گذاری شده
    ''' </summary>
    ''' <param name="userName"></param>
    ''' <returns> نقش کد گذاری شده کاربر</returns>
    Public Function GetUserEncryptedRole(ByVal Username As String) As String
        Dim Role As String = ""
        Dim strselect As String = "SELECT [Role] FROM [Users_table] Where ([Code]=@Code)"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Username)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            Role = reader("Role").ToString()
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class UserAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return Role
    End Function
    ''' <summary>
    ''' دریافت رشته نقش کاربر 
    ''' </summary>
    ''' <param name="userName"></param>
    ''' <returns> نقش  کاربر</returns>
    Public Function GetUserPlainRole(ByVal Username As String) As String
        Return utill.Decrypt(GetUserEncryptedRole(Username), Username)
    End Function

    ''' <summary>
    ''' ریست رمز کاربر
    ''' </summary>
    ''' <param name="userName"></param>
    ''' <returns> 0 = User Not Found - 1= Password Rest Successful - (-1)= Error in Finding User - (-2)= Error in Reset Password</returns>
    ''' 
    Public Function ResetUserPassword(ByVal Username As String) As Integer
        Dim result As Integer = 0
        Dim found As Boolean = False
        Dim strselect As String = "SELECT [code] FROM [Users_table] Where ([Code]=@Code)"
        Dim strupdate As String = "UPDATE [Users_table] SET [Password] = @Password  WHERE [Code]=@Code"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Username)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            found = True
                        Else
                            Return 0
                        End If

                    End Using
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class UserAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return -1
        End Try
        If found Then
            Try
                Using connection As New SqlConnection(utill.Connectionstring)
                    Using command As New SqlCommand(strupdate, connection)
                        command.CommandType = CommandType.Text
                        command.Parameters.Clear()
                        command.Parameters.AddWithValue("@Code", Username)
                        command.Parameters.AddWithValue("@Password", BCrypt.Net.BCrypt.HashPassword(Username, 4))
                        connection.Open()
                        command.ExecuteNonQuery()
                        result = 1
                    End Using
                End Using
            Catch ex As Exception
                utill.RegisterError(ex.Message, "Class UserAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                Return -2
            End Try
        End If
        Return result
    End Function

    ''' <summary>
    ''' بدست آوردن پسورد ذخیره شده
    ''' </summary>
    ''' <param name="userName"></param>
    ''' <returns> رشته هش شده پسورد</returns>
    Public Function Get_user_saved_Password(ByVal Username As String) As String
        Dim password As String = ""
        Dim strselect As String = "SELECT [password] FROM [Users_table] Where ([Code]=@Code)"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Username)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            password = reader("password").ToString()
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class UserAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return password
    End Function


    ''' <summary>
    ''' تغییر رمز کاربر
    ''' </summary>
    ''' <param name="userName"></param>
    ''' <returns> 0:OldPassword is not correct - 1:Password Change OK 2:Error on Changing Password </returns>
    Public Function ChangeUserPassword(ByVal Username As String, ByVal OldPassword As String, ByVal NewPassword As String) As Integer
        Dim result As Integer = 0
        Dim found As Boolean = False
        If Not (BCrypt.Net.BCrypt.Verify(OldPassword, Get_user_saved_Password(Username))) Then
            Return 0
        End If
        Dim strupdate As String = "UPDATE [Users_table] SET [Password] = @Password  WHERE [Code]=@Code"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strupdate, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Username)
                    command.Parameters.AddWithValue("@Password", BCrypt.Net.BCrypt.HashPassword(NewPassword, 4))
                    connection.Open()
                    command.ExecuteNonQuery()
                    result = 1
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class UserAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return 2
        End Try
        Return result
    End Function
End Class

