﻿Imports System.Data.SqlClient
Public Class AdminMembership
    Dim utill As New Utility()
    Public Function GetAdminFirstname(ByVal Username As String) As String
        Dim Firstname As String = ""
        Dim strselect As String = "SELECT [Firstname] FROM [Administrators] Where ([Code]=@Code)"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Username)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            Firstname = reader("Firstname").ToString()
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class AdminAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return Firstname
    End Function
    Public Function GetAdminLastname(ByVal Username As String) As String
        Dim LastName As String = ""
        Dim strselect As String = "SELECT [LastName] FROM [Administrators] Where ([Code]=@Code)"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Username)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            LastName = reader("LastName").ToString()
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class AdminAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return LastName
    End Function
    Public Function GetAdminFullname(ByVal Username As String) As String
        Return GetAdminFirstname(Username) + " " + GetAdminLastname(Username)
    End Function
    Public Function GetAdminEncryptedRole(ByVal Username As String) As String
        Dim Role As String = ""
        Dim strselect As String = "SELECT [Role] FROM [Administrators] Where ([Code]=@Code)"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Username)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            Role = reader("Role").ToString()
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class AdminAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return Role
    End Function

    Public Function GetAdminPlainRole(ByVal Username As String) As String
        Return utill.Decrypt(GetAdminEncryptedRole(Username), Username)
    End Function

    Public Function GetAdminEncryptedPassword(ByVal Username As String) As String
        Dim Password As String = ""
        Dim strselect As String = "SELECT [Password] FROM [Administrators] Where ([Code]=@Code)"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Username)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            Password = reader("Password").ToString()
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class AdminAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return ""
        End Try
        Return Password
    End Function
    Public Function GetAdminPlainPassword(ByVal Username As String) As String
        Return utill.Decrypt(GetAdminEncryptedPassword(Username), Username)
    End Function

    ''' <summary>
    ''' حذف حساب کاربری مدیر
    ''' </summary>
    ''' <param name="userName"></param>
    ''' <returns> 0 = User Not Found - 1= Account Delete Successful - (-1)= Error in Finding User - (-2)= Error in Account Delete</returns>
    Public Function DeleteAdmin(ByVal Username As String) As Integer
        Dim result As Integer = 0
        Dim found As Boolean = False
        Dim strselect As String = "SELECT [code] FROM [Administrators] Where ([Code]=@Code)"
        Dim strdelete As String = "delete from Administrators where [Code]=@code"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Username)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            found = True
                        Else
                            Return 0
                        End If

                    End Using
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class UserAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return -1
        End Try
        If found Then
            Try
                Using connection As New SqlConnection(utill.Connectionstring)
                    Using command As New SqlCommand(strdelete, connection)
                        command.CommandType = CommandType.Text
                        command.Parameters.Clear()
                        command.Parameters.AddWithValue("@Code", Username)
                        connection.Open()
                        command.ExecuteNonQuery()
                        result = 1
                    End Using
                End Using
            Catch ex As Exception
                utill.RegisterError(ex.Message, "Class AdminAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                Return -2
            End Try
        End If
        Return result
    End Function

    Public Function UpdateAdminRole(ByVal Username As String, ByVal commaSeperatedRoles As String) As Integer
        Dim result As Integer = 0
        Dim found As Boolean = False
        Dim strselect As String = "SELECT [code] FROM [Administrators] Where ([Code]=@Code)"
        Dim strupdate As String = "UPDATE [Administrators] SET [Role] = @Role  WHERE [Code]=@Code"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Username)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            found = True
                        Else
                            Return 0
                        End If

                    End Using
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class AdminAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return -1
        End Try
        If found Then
            Try
                Using connection As New SqlConnection(utill.Connectionstring)
                    Using command As New SqlCommand(strupdate, connection)
                        command.CommandType = CommandType.Text
                        command.Parameters.Clear()
                        command.Parameters.AddWithValue("@Code", Username)
                        command.Parameters.AddWithValue("@Role", utill.Encrypt(commaSeperatedRoles, Username))
                        connection.Open()
                        command.ExecuteNonQuery()
                        result = 1
                    End Using
                End Using
            Catch ex As Exception
                utill.RegisterError(ex.Message, "Class UserAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                Return -2
            End Try
        End If
        Return result
    End Function
    ''' <summary>
    ''' ریست رمز مدیر
    ''' </summary>
    ''' <param name="userName"></param>
    ''' <returns> 0 = User Not Found - 1= Password Rest Successful - (-1)= Error in Finding User - (-2)= Error in Reset Password</returns>
    ''' 
    Public Function ResetAdminPassword(ByVal Username As String) As Integer
        Dim result As Integer = 0
        Dim found As Boolean = False
        Dim strselect As String = "SELECT [code] FROM [Administrators] Where ([Code]=@Code)"
        Dim strupdate As String = "UPDATE [Administrators] SET [Password] = @Password  WHERE [Code]=@Code"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Username)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            found = True
                        Else
                            Return 0
                        End If

                    End Using
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class UserAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return -1
        End Try
        If found Then
            Try
                Using connection As New SqlConnection(utill.Connectionstring)
                    Using command As New SqlCommand(strupdate, connection)
                        command.CommandType = CommandType.Text
                        command.Parameters.Clear()
                        command.Parameters.AddWithValue("@Code", Username)
                        command.Parameters.AddWithValue("@Password", BCrypt.Net.BCrypt.HashPassword(Username, 4))
                        connection.Open()
                        command.ExecuteNonQuery()
                        result = 1
                    End Using
                End Using
            Catch ex As Exception
                utill.RegisterError(ex.Message, "Class AdminAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                Return -2
            End Try
        End If
        Return result
    End Function

    ''' <summary>
    ''' بدست آوردن پسورد ذخیره شده
    ''' </summary>
    ''' <param name="userName"></param>
    ''' <returns> رشته هش شده پسورد</returns>
    Public Function Get_Admin_saved_Password(ByVal Username As String) As String
        Dim password As String = ""
        Dim strselect As String = "SELECT [password] FROM [Administrators] Where ([Code]=@Code)"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strselect, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Username)
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            password = reader("password").ToString()
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class AdminAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
        End Try
        Return password
    End Function

    ''' <summary>
    ''' تغییر رمز کاربر
    ''' </summary>
    ''' <param name="userName"></param>
    ''' <returns> 0:OldPassword is not correct - 1:Password Change OK 2:Error on Changing Password </returns>
    Public Function ChangeAdminPassword(ByVal Username As String, ByVal OldPassword As String, ByVal NewPassword As String) As Integer
        Dim result As Integer = 0
        Dim found As Boolean = False
        If Not (BCrypt.Net.BCrypt.Verify(OldPassword, Get_Admin_saved_Password(Username))) Then
            Return 0
        End If
        Dim strupdate As String = "UPDATE [Administrators] SET [Password] = @Password  WHERE [Code]=@Code"
        Try
            Using connection As New SqlConnection(utill.Connectionstring)
                Using command As New SqlCommand(strupdate, connection)
                    command.CommandType = CommandType.Text
                    command.Parameters.Clear()
                    command.Parameters.AddWithValue("@Code", Username)
                    command.Parameters.AddWithValue("@Password", BCrypt.Net.BCrypt.HashPassword(NewPassword, 4))
                    connection.Open()
                    command.ExecuteNonQuery()
                    result = 1
                End Using
            End Using
        Catch ex As Exception
            utill.RegisterError(ex.Message, "Class AdminAuthentication", System.Reflection.MethodInfo.GetCurrentMethod().ToString())
            Return 2
        End Try
        Return result
    End Function

End Class
