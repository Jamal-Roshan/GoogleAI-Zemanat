﻿Class AppSettings

    Private Key As String
    Public Shared ReadOnly malicode As AppSettings = New AppSettings("malicode")
    Public Shared ReadOnly zarib As AppSettings = New AppSettings("zarib")
    Public Shared ReadOnly mincredit As AppSettings = New AppSettings("mincredit")
    Public Shared ReadOnly orgaddress As AppSettings = New AppSettings("orgaddress")
    Public Shared ReadOnly orgcode As AppSettings = New AppSettings("orgcode")
    Public Shared ReadOnly orgfax As AppSettings = New AppSettings("orgfax")
    Public Shared ReadOnly orgphone As AppSettings = New AppSettings("orgphone")
    Public Shared ReadOnly orgtitle As AppSettings = New AppSettings("orgtitle")
    Public Shared ReadOnly orgunittitle As AppSettings = New AppSettings("orgunittitle")
    Public Shared ReadOnly shomareh As AppSettings = New AppSettings("shomareh")
    Public Shared ReadOnly signername As AppSettings = New AppSettings("signername")
    Public Shared ReadOnly signerpost As AppSettings = New AppSettings("signerpost")
    Public Shared ReadOnly urladdress As AppSettings = New AppSettings("urladdress")
    Public Shared ReadOnly mazad As AppSettings = New AppSettings("mazad")

    Private Sub New(key As String)
        Me.Key = key
    End Sub

    Public Overrides Function ToString() As String
        Return Me.Key
    End Function
End Class