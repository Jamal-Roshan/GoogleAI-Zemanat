﻿<%@ Page Title="در بارگذاری سایت خطای رخ داده است" Language="vb" AutoEventWireup="false" MasterPageFile="~/Site.Master" CodeBehind="Error500.aspx.vb" Inherits="ZemanatNameh.vb.Error500" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <div class="panel-heading text-center" style="padding: 10px; margin: 0px">
        <h1 style="font-size: 1.2em; padding: 0px; margin: 0px">در بارگذاری سایت خطای رخ داده است</h1>
    </div>
    <div class="panel-body text-center" style="padding: 10px 20px 10px 20px">
        <img src="Images/error-500.jpg" style="margin: 0 auto" />
    </div>
</asp:Content>
