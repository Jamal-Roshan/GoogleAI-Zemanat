﻿Imports System.Data.SqlClient
Public Class Login
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim utill As New Utility()
        If Session("returl") IsNot Nothing AndAlso Session("returl").ToString <> "" Then
            Response.Redirect("~/" & Session("returl").ToString, True)
        End If


        Using sqlCon As New SqlConnection(utill.Connectionstring)
            Dim sqlSelectstring As String = "SELECT [Value]  FROM [AppSettings] where [name]=@orgtitle"
            Using selectCommand As New SqlCommand(sqlSelectstring, sqlCon)
                selectCommand.CommandType = CommandType.Text
                selectCommand.Parameters.AddWithValue("@orgtitle", "orgtitle")
                Try
                    sqlCon.Open()
                    Using sqldr As SqlDataReader = selectCommand.ExecuteReader()
                        If sqldr.HasRows Then
                            sqldr.Read()
                            orgtitle.Text = sqldr.Item("value").ToString()
                            Me.Page.Header.Title = orgtitle.Text
                        End If

                    End Using
                Catch ex As Exception
                    utill.RegisterError(ex.Message, Me.Page.Title, System.Reflection.MethodInfo.GetCurrentMethod().ToString())
                End Try
            End Using
        End Using
    End Sub
    Protected Sub btnsignin_Click(sender As Object, e As EventArgs) Handles btnsignin.Click
        If Page.IsValid Then
            Dim utill As New Utility()
            Dim ReturnUrl As String = Request.QueryString("ReturnUrl")
            If Not [String].IsNullOrEmpty(ReturnUrl) Then
                ReturnUrl = ReturnUrl.ToLower
                If RedirectToAdminOrModir(ReturnUrl) Then
                    Authenticate(utill.Fa2En(txtprsid.Value).ToLower, txtpassword.Value, IsAdmin:=True)
                Else
                    Authenticate(utill.Fa2En(txtprsid.Value).ToLower, txtpassword.Value.ToString())
                End If
            Else
                Authenticate(utill.Fa2En(txtprsid.Value).ToLower, txtpassword.Value)
            End If
        End If
    End Sub
    Private Sub Authenticate(userName As String, password As String, Optional IsAdmin As Boolean = False)
        Dim commaSeperatedRoles As String = String.Empty
        If IsAdmin Then
            If Not UserAuthentication.Instance.AuthenticateAdmin(userName, password, commaSeperatedRoles) Then
                lblerrormessage.Visible = True
                'If Session("userName") IsNot Nothing Then
                '    Session.Remove("userName")
                'End If
                Session.Remove("returl")
                Return
            End If
        Else
            If Not UserAuthentication.Instance.AuthenticateUser(userName, password, commaSeperatedRoles) Then
                lblerrormessage.Visible = True
                'If Session("userName") IsNot Nothing Then
                '    Session.Remove("userName")
                'End If
                Session.Remove("returl")
                Return
            End If
        End If
        'Session.Add("userName", userName)
        Dim ReturnUrl As String = Request.QueryString("ReturnUrl")
        If Not [String].IsNullOrEmpty(ReturnUrl) Then
            ReturnUrl = ReturnUrl.ToLower
            Session.Add("returl", ReturnUrl)
        End If
        FormsAuthenticationUtil.RedirectFromLoginPage(userName, commaSeperatedRoles, True)
    End Sub
    Private Function RedirectToAdminOrModir(ByVal returnurl As String) As Boolean
        returnurl = returnurl.Substring(returnurl.IndexOf("/") + 1, returnurl.Length - 1)
        If returnurl.Contains("admin") OrElse returnurl.Contains("modir") Then
            Return True
        End If
        Select Case returnurl
            Case "admin", "setting", "addadmin", "deladmin", "resetadminpass", "verror", "modir", "block", "resetuserpass", "list", "govahi", "estelam",
                 "viewestelam", "estelamreport", "upload", "init"
                Return True
            Case Else
                Return False
        End Select
    End Function

End Class