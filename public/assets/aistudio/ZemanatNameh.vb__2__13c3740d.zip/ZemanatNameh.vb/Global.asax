﻿<%@ Application Codebehind="Global.asax.vb" Inherits="ZemanatNameh.vb.Global_asax" Language="vb" %>
