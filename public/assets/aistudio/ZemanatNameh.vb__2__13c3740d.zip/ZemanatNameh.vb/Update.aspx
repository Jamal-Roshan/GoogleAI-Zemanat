﻿<%@ Page Title="سایت در حال به روزرسانی است" Language="vb" AutoEventWireup="false" MasterPageFile="~/Site.Master" CodeBehind="Update.aspx.vb" Inherits="ZemanatNameh.vb.Update" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <div class="panel-heading text-center" style="padding: 10px; margin: 0px">
        <h1 style="font-size: 1.2em; padding: 0px; margin: 0px">سایت در حال به روزرسانی است</h1>
    </div>
    <div class="panel-body text-center" style="padding: 10px 20px 10px 20px">
        <img src="Images/updating.png" style="margin: 0 auto" class="img-responsive" />
    </div>
</asp:Content>
