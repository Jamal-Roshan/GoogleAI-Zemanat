﻿Imports System.Web.Security
Public Class logout
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Session.Abandon()
        FormsAuthentication.SignOut()
        Session.Abandon()
        Response.Redirect("./Signin")
    End Sub

End Class