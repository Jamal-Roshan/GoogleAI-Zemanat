﻿<%@ Page Title="صفحه مورد نظر شما موجود نیست" Language="vb" AutoEventWireup="false" MasterPageFile="~/Site.Master" CodeBehind="error404.aspx.vb" Inherits="ZemanatNameh.vb.error4041" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <div class="panel-heading text-center" style="padding: 10px; margin: 0px">
        <h1 style="font-size: 1.2em; padding: 0px; margin: 0px">صفحه مورد نظر شما موجود نیست</h1>
    </div>
    <div class="panel-body text-center" style="padding: 10px 20px 10px 20px">
        <img src="Images/error404.png" style="margin: 0 auto" />
    </div>
</asp:Content>
